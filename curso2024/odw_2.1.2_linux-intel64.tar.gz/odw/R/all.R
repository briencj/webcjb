#' Optimal design
#'
#' Generate optimal designs for comparative experiments under a
#' general linear mixed model.
#'
#' The mixed model equations are formed from the terms in the
#' \code{fixed}, \code{random} and \code{residual} formulae, and the
#' variance parameters pre-specified in \code{G.param} and
#' \code{R.param}. The design criterion is calculated for the
#' objective treatment term given in the \code{permute} formula. The
#' objective function (eg \code{avalue}) is optimized under the
#' supervision of the \code{search} strategy for pairwise exchanges of
#' the rows of the design matrix, subject to the conditions set by the
#' terms in \code{swap}, until \code{maxit} is exceeded.
#'
# If the option \code{search.threads} is specified, the search strategy
# (\code{random} or \code{tabu}) is divided across multiple cores to
# reduce processing time. \bold{This should be considered
# experimental as limited testing suggests that the multi-threaded
# strategies may terminate at a slightly less optimal design than the
# sequential methods.}
#'
#' Special functions may be used in model formulae; currently those
#' recognised are from the \code{id()}, \code{ar1()} and \code{cor()}
#' families, \code{at()}, \code{vm()}, \code{ide()}, and \code{xpr()}.
#'
#' @param fixed
#'
#' A formula specifying the fixed model terms.
#'
#' @param random
#'
#' A formula specifying the random model terms.
#'
#' @param residual
#'
#' A formula specifying the residual variance structure.
#'
#' @param permute
#'
#' A formula containing a single term specifying the
#' (\emph{objective}) factor in the \code{fixed} or \code{random} set
#' that is to be permuted. The \code{"|"} operator can be used to
#' associate this factor with other terms in the model that should be
#' permuted in parallel. This includes the \code{vm} and \code{ide}
#' special functions for genetic models.
#'
#' @param swap
#'
#' A formula nominating which factor(s) define legal treatment
#' exchanges during the optimisation process. Rows of the design
#' matrix \eqn{W = [X Z]} (see \cite{Butler, 2013}), for the
#' \code{permute} term(s) columns, are only interchanged within levels
#' of the swap factor (or the intersection of levels if \code{swap} is
#' of the form \code{'~ A:B'}). If \code{~NULL} (the default) a factor
#' \code{"..one"} with one level is added to the data frame.
#'
#' @param G.param
#'
#' A list or data frame object containing preset values for the random
#' components, typically generated from a prior call to \code{odw} with
#' \code{start.values=TRUE}.
#'
#' @param R.param
#'
#' A list or data frame object containing preset values for the
#' residual components, typically generated from a prior call to
#' \code{odw} with \code{start.values=TRUE}.
#'
#' @param optimize
#'
#' May be a character string containing either \code{"data"} (the
#' default) or \code{"ginv"}, or a character vector of levels from the
#' \code{permute} factor. This argument permutes the relationship
#' matrix if the \code{permute} factor is a
#' \code{vm()} term, or reorders the levels of the permute term such
#' that those in the \code{optimize} set come first.
#'
#' @param group
#'
#' A named list where each component is a numeric vector specifying
#' contiguous fields in \code{data} that are to be considered as a
#' single term. The component names can then appear in odw model
#' formulae using the \code{grp()} special function. The default is an
#' empty list.
#'
#' @param equate.levels
#'
#' A character vector of factor names whose levels are to be
#' \emph{equated}. If factor \code{A} has levels \emph{a,b,c,d} and
#' factor \code{B} has levels \emph{a,b,c,e}, the effect of
#' \code{equate.levels(A, B)} is that both \code{A} and \code{B} have
#' 5 levels, with \code{as.numeric(A)} = \emph{1,2,3,4} and
#' \code{as.numeric(B)} = \emph{1,2,3,5.} This may be necessary if
#' using the \code{xpr} model function to overlay columns of the
#' model's design matrix in forming a compound term. The default is a
#' zero length character vector.
#'
#' @param data
#'
#' The initial design as a dataframe in which to resolve the terms in
#' the model formulae.
#'
#' @param search
#'
#' A character string specifying the search strategy. The choices are
#' \describe{
#'   \item{random}{A greedy local hill climbing search that chooses pairwise
#'   exchanges at random and always accepts an improving move.}
#'
#'   \item{tabu}{Initiates a robust TABU search (\cite{Taillard, 1991}) that
#'   involves a greedy deterministic search of all possible neighbours of 
#'   the starting design that can be reached by pairwise exchanges of the 
#'   experimental units. There is a maximum of
#'   \eqn{n(n-1)/2} such exchanges before any swap block reductions.}
#'
#'   \item{randomwalk}{Similar to greedy hill climbing except that non-improving
#'   designs are accepted with probability \eqn{P} in an effort to diversify the search.}
#'
#'   \item{tabu+rw}{A robust TABU search with a random walk as the local search 
#'   strategy. In this case \code{"maxit"} specifies the number of TABU loops and
#'   the option \code{"localSearch"} specifies the number of steps in the 
#'    random walk.}
#' }
#' The default is \code{"random"}.
#'
#' @param maxit
#'
#' The number of TABU loops if the search method is one of the tabu
#' options,
#' otherwise the number of random exchanges. Note that for each \code{maxit}
#' iteration, tabu search does a scavenging exploration of the
#' neighbourhood of the current solution, with a maximum of
#' \eqn{n(n-1)/2} exchanges (hence evaluations) in the absence of any
#' restrictions. If \code{search="tabu+rw"} the option \code{localSearch}
#' determines the number of objective evaluations in a tabu cycle.
#'
#' @param reorder
#'
#' A numeric or character vector identifying any columns in
#' \code{data} that are to be permuted (at the termination of the
#' search) in design order, parallel to the objective factor given in
#' \code{permute}.
#'
#' @param start.values
#'
#' If \code{TRUE}, \code{odw} exits prior to generating a design and
#' returns a list of length 3: the \code{G.param} and \code{R.param}
#' lists, and a data frame \emph{vparameters.table} containing
#' variance parameter names and initial values. Initial values may
#' then be set in either the list or data frame objects.
#'
#' If a character string, then a file of that name is created and the
#' data frame object containing initial parameter values is written
#' out in comma separated form. This file can be edited externally and
#' subsequently specified in the \code{G.param} or \code{R.param}
#' arguments.
#' 
#' @param resolve
#' 
#' A character string identifying a column in the data of type \code{logical}
#' that specifies whether an experimental unit can be exchanged only with 
#' others in the same swap block. If \code{resolve=""} (the default)
#' then all experimental units are constrained withing their respective
#' swap blocks.
#'
#' @param ...
#'
#' Additional arguments from the options list: \code{search.threads},
#' \code{criterion}, \code{trace} and \code{debug}.
#'
#' @return
#'
#' A list object of class \code{odw} with the following components:
#' \describe{
#'  \item{call}{the \code{odw()} function call.}
#'  \item{design}{the data frame with the terms given in the
#'    \code{permute} formula and \code{reorder} argument in design order.}
#'  \item{criterion}{the final value of the optimality criterion.}
#'  \item{permutation}{a numeric vector containing the permutation, or
#'    design order, of the rows of \code{data}.}
#'  \item{G.param}{a list containing the preset values for terms in \code{random}.}
#'  \item{R.param}{a list containing the preset values for terms in \code{residual}.}
#' }
#'
#' @examples
#'
#' \dontrun{
#' # A row-column design with 400 treatments in a rectangular grid
#' # of 20 columns and 40 rows with 2 complete resolvable blocks.
#' # 1000 iterations of a greedy hill climb search.
#' data(rc400)
#' rc400.odw <- odw(fixed = ~ 1, random = ~ Variety+Rep+Column+Row,
#'                permute = ~ Variety, swap = ~ Rep, search='random',
#'                residual = ~ ar1(Column):ar1(Row),
#'                data=rc400, maxit=1000)
#' }
#'
#' @references
#'
#' % bibentry: Butler:2013
#' % bibentry: Taillard:1991
#'

odw <- function(fixed = ~ 1, random = ~NULL, residual = ~NULL,
               permute = ~NULL, swap = ~NULL,
               G.param = list(), R.param = list(),
               optimize = "data", search="random", maxit=1, 
               group = list(), equate.levels = character(0), 
               reorder = NULL, start.values=FALSE, resolve = "", 
               data = sys.parent(), ...)
{
  data.object <- NULL
  if(!missing(data)) {
    data.object <- data #as.character(substitute(data))
    data.names <- names(data)
  }

  ## check reorder before we do any work
  if(!is.null(reorder)) {
    if(is.numeric(reorder)) {
      if(!all(reorder > 0 & reorder <= length(names(data))))
        stop("Elements of 'reorder' out of bounds")
      reorder <- names(data)[reorder]
    }
    if(any(is.na(match(reorder,names(data)))))
      stop("Elements of 'reorder' not in 'data'")
  }


  ## Set na.action to fail
  na.action = na.method(x='fail')
  ## Global missing value constant as for SA asreml
  dpmv <- -1e-37
  ##
  ddd <- list(...)
  options <- odw.options()

  ## return this in the object
  tt <- list(fixed = trimSpc(Terms(fixed, keep.order=TRUE)),
             random = trimSpc(Terms(random, keep.order=TRUE)),
             residual = trimSpc(Terms(residual, keep.order=TRUE)),
             permute = trimSpc(Terms(permute, keep.order=TRUE)),
             swap = trimSpc(Terms(swap, keep.order=TRUE)))
  ## return call as well
  call <- match.call()

  ##
  debug <- ifelse(is.null(ddd$debug), options$debug, ddd$debug)
  options$maxit <- maxit
  options$trace <- ifelse(is.null(ddd$trace), options$trace, ddd$trace)
  options$search.threads <- ifelse(is.null(ddd$search.threads), 
    options$search.threads, ddd$search.threads)
  options$criterion <- ifelse(is.null(ddd$criterion), options$criterion, ddd$criterion)
  if(!is.element(options$criterion, c("avalue", "pev"))) {
    stop("Only 'criterion=avalue or pev' is currently supported.")
  }
  options$search <- search
  if(!is.element(options$search, c("random","tabu","randomwalk","tabu+rw"))) {
    stop("'search' must be one of 'random', 'tabu', 'randomwalk', 'tabu+rw'")
  }

  if(options$debug) {
    cat("   Checking args... ","\n")
    ptime <- proc.time()[1]
  }

  if(is.na(options$tol)) {
    options$tol <- -1.0
  }
  
  if(missing(data))
    data <- data.table()
  else if(!inherits(data, "data.table"))
    data <- as.data.table(data)

  ## Make a unitary factor "..one" if swap is null
  if(is.null(swap[[2]])) {
    data[, "..one":= factor(rep(1,nrow(data)))]
    tt$swap <- trimSpc(Terms(formula("~ ..one"), keep.order=TRUE))
  }

  giv.internal(optimize, permute, data)
  ## Things that must be done to make a model.(data)frame:
  ##
  ## 0. check for any vm PSD to invert and add nsing to levels
  ## 1. process 'group' and 'mbf' before data is potentially mangled
  ## 2. resolve variable names from special functions
  ## 3. add 'units' if necessary
  ## 4. honour 'na.action' rules
  ## 5. add factor(s) for 2-d power models
  ## 6. multivariate analysis:
  ##    if no "residual" given then
  ##       assume Arthur's std multivariate analysis IxUS
  ##       do not fit missing value (mv) factor
  ##    else
  ##       proceed as for !ASUV in standalone and fit mv
  ##       this is the default behaviour of release 3
  ##    endif
  ##    data to be expanded in either case.
  ##    "asmv" assumes the data is already expanded
  ##                      and identifies the "trait" factor;
  ##                      the above "residual" rules still apply.
  ## 7. add missing value factor (mv) to sparse.
  ## 8. 'offset' for glm in fixed form
  ## 9. weights
  ## 10. xfa terms from any struc calls
  ##
  ##    Add 'total' to family functions where appropriate
  ##    & extract them before model.frame.

  ## model frame

  if(options$debug) cat("   Making model.frame... ",proc.time()[1]-ptime,"\n")
  data <- modelFrame(tt, call, options, data, na.action)
  attr(data,"dpmv") <- as.double(dpmv)

  if(options$debug) cat("   Making R structure... ",proc.time()[1]-ptime,"\n")
  ## Set up Gcov & Residual (using model frame)
  ##

  if(length(R.param) == 0) {
    R.param <- Rparam(data) #.Call("rparam", data)
  }
  else {
    Rdflt <- Rparam(data)
    cf <- attr(Rdflt, "conditioning.factor")
    R.param <- updateV(Rdflt, R.param, which="R")
    attr(R.param, "conditioning.factor") <- cf
  }

  if(options$debug) cat("   Making G structure... ",proc.time()[1]-ptime,"\n")

  if(length(G.param) == 0)
    G.param <- Gparam(data)
  else {
    Gdflt <- Gparam(data)
    G.param <- updateV(Gdflt, G.param, which="G")
   }

  if((is.logical(start.values) && start.values==TRUE) || is.character(start.values)) {
    sv.list <- list(G.param=G.param, R.param=R.param,
                    vparameters.table=gammas2df(list(G.param=G.param, R.param=R.param)))
    if(is.character(start.values))
      write.table(sv.list$vparameters.table,start.values,row.names=FALSE,sep=",")
    return(sv.list)
  }

  if(options$debug) cat((proc.time()[1]-ptime),"seconds\n")

  ## set up call to odw
  ## Are we in batch mode?
  options$BATCH <- !is.na(Sys.getenv("R_BATCH", NA))
  if(options$BATCH) {
    options$trace <- FALSE
  }

  ## Ginverse
  ##if(length(ran <- attr(attr(data,"model.terms")$mixed, "random"))) {
  mxd <- attr(data,"model.terms")$mixed
  ginverse <- findGinv(mxd)
  ## levels of vm (ped/giv/ide) terms
  if(length(ginverse)) {
    for(i in names(data)) {
      if(!is.null(attr(data[[i]], "rowNames"))) {
        rn <- attr(data[[i]],"rowNames")
        data[[i]] <- factor(as.character(data[[i]]),levels=rn)
        if(length(optimize) == 1 && optimize == "data") {
          attr(data[[i]], "inAval") <- sum(as.integer(is.element(rn, as.character(data[[i]]))))
        } else if(length(optimize) == 1 && optimize == "ginv") {
          attr(data[[i]], "inAval") <- length(rn)
        } else {
          attr(data[[i]], "inAval") <- sum(as.integer(is.element(rn, as.character(optimize))))
        }
      }
    }
  }
  ## optimize option for non vm permute
  if(length(ginverse) == 0) {
    if((is.character(optimize) && optimize[1] != "data") || is.numeric(optimize)) {
      pp <- fpipe(permute)[[1]]
      pp <- dimnames(attr(Terms(pp, keep.order=TRUE), "factors"))[[2]]
      ll <- levels(data[[pp]])
      if(is.character(optimize)) {
        if(any(is.na(w <- match(optimize, ll)))) {
          stop("optimize has levels not in the data")
        }
      } else {
        if(any((optimize < 1) | (optimize > length(levels(data[[pp]]))))) {
          stop("A numeric element of optimize is out of bounds")
        }
        w <- optimize
        data[[pp]] <- factor(as.character(data[[pp]]),levels=c(ll[optimize], ll[-optimize]))
      }
      data[[pp]] <- factor(as.character(data[[pp]]),levels=c(ll[w], ll[-w]))
      attr(data[[pp]], "inAval") <- length(w)
    }
  }
  ## odw
  options$debug <- debug
  if(is.logical(debug) && debug) {
    rl <- list(R.param=R.param,G.param=G.param,ginverse=ginverse,
               options=options, terms=tt, call=call,
                 formulae=tt, mf=data)
    if(length(ginverse) > 0)
        rl$ginverse=list(info=ginverse, obj=odw_grm(ginverse))
    return(rl)
  }
  else if(length(ginverse) > 0) { # Save a memory copy/duplication??
    opt <- .Call("od_data", data, list(info=ginverse, obj=odw_grm(ginverse)),
                 R.param, G.param, options, PACKAGE="odw")
  }
  else {
    opt <- .Call("od_data", data, list(info=NULL,obj=NULL),
                 R.param, G.param, options, PACKAGE="odw")
  }
  ## return the design in a data frame, with attributes 'Criterion', 'permutation' etc

  ## permute the rows for base factors in permuteL & permuteR
  MT <- attr(data, "model.terms")$permuteL
  pterms <- NULL
  for(i in dimnames(attr(MT$Terms.obj, "factors"))[[1]]) {
    if(MT$Vars[[i]]$Fun == "grp") {
      pterms <- c(pterms, MT$Vars[[i]]$Lvls)
    } else if(MT$Vars[[i]]$Fun == "xpr") {
      pterms <- c(pterms, MT$Vars[[i]]$Argv)
    } else {
      pterms <- c(pterms, MT$Vars[[i]]$Obj)
    }
  }
  if(length(MT <- attr(data, "model.terms")$permuteR)) {
    for(i in dimnames(attr(MT$Terms.obj, "factors"))[[1]]) {
      if(MT$Vars[[i]]$Fun == "grp") {
        pterms <- unique(c(pterms, MT$Vars[[i]]$Lvls))
      } else if(MT$Vars[[i]]$Fun == "xpr") {
        pterms <- unique(c(pterms, MT$Vars[[i]]$Argv))
      } else {
        pterms <- unique(c(pterms, MT$Vars[[i]]$Obj))
      }
    }
  }
  if(!is.null(reorder)) {
    pterms <- unique(c(pterms, reorder))
  }
  if(nchar(resolve) > 0) {
    pterms <- c(pterms, resolve)
  }
  if(!is.null(data.object)) {
    ##dataEnv <- where.env(data.object)
    design <- as.data.frame(data.object, stringsAsFactors=TRUE) ##as.data.frame(mget(data.object, envir=dataEnv))
    names(design) <- data.names
  }
  else {
    design <- as.data.frame(data, stringsAsFactors=TRUE)
  }
  design[, pterms] <- design[opt[[1]], pterms]
  opt$design <- design
  opt$call <- call
  opt$formulae <- tt
  opt$mf <- data
  opt$R.param <- R.param
  opt$G.param <- G.param
  if(options$design) {
    opt$W1 <- sparseMatrix(i = opt$w1[,1], j = opt$w1[,2], x = opt$w1[,3])
    opt$W2 <- sparseMatrix(i = opt$w2[,1], j = opt$w2[,2], x = opt$w2[,3])
  }
  class(opt) <- "odw"
  return(opt)
}
gammas2df <- function(object)
{
  ## Return a default parameter values data frame

  if(mode(object) != "list")
    stop("\n object must be of mode list\n")
  if(is.na(match("G.param",names(object))))
    stop("\n object must have a component named G.param\n")
  if(is.na(match("R.param",names(object))))
    stop("\n object must have a component named R.param\n")

  gammas <- vector(mode="numeric")

  gcov.list <- object[["G.param"]]
  rcov.list <- object[["R.param"]]

  if(length(gcov.list) > 0)  {
    nterm <- length(gcov.list)
    for(n in seq(1,nterm)) {
      nfact <- length(gcov.list[[n]])
      for(j in 1:nfact) {
        gammas <- c(gammas,gcov.list[[n]][[j]]$initial)
      }
    }
  }

  if(length(rcov.list) > 0) {
    nsect <- length(rcov.list)
     for(n in seq(1,nsect)) {
      ndim <- length(rcov.list[[n]])
      for(j in 1:ndim) {
        gammas <- c(gammas,rcov.list[[n]][[j]]$initial)
      }
    }
  }

  if(length(gammas)==0)
    stop("\n No variance components found - missing G & R lists?\n")

  not.id <- !is.na(gammas)
  gammas <- gammas[not.id]

  x <- data.frame(Component=names(gammas),
                  Value=gammas,
                  row.names=NULL,stringsAsFactors=FALSE)
  return(x)
}
odw_grm <- function(ginverse) {
  ## ginverse is list object from asreml of the attributes
  ## from the call to vm()

  ## Set storage.mode to double
  ## Convert Matrix objects to coordinate form

  ginv.obj <- as.character(sapply(ginverse,function(x)x$Source))
  odwEnv <- where.env(ginv.obj[1])
  obj <- mget(ginv.obj, envir=odwEnv)

  for(i in seq(1,length(obj))) {
    if(inherits(obj[[i]], "Matrix")) {
      if(is.null(rn <- attr(obj[[i]], "rowNames"))) {
        if(is.null(rn <- rownames(obj[[i]])))
          stop("'rownames' or 'dimnames' not found.\n")
      }
      rn <- dimnames(obj[[i]])[[1]]
      if(inherits(obj[[i]],"TsparseMatrix")) {
        obj[[i]] <- cbind(obj[[i]]@i+1, obj[[i]]@j+1, obj[[i]]@x)
        obj[[i]] <- obj[[i]][base::order(obj[[i]][,1],obj[[i]][,2]),]
      }
      else if(inherits(obj[[i]],"dsparseMatrix")) {
        obj[[i]] <- as(obj[[i]], "dgTMatrix")
        obj[[i]] <- cbind(obj[[i]]@i+1, obj[[i]]@j+1, obj[[i]]@x)
        obj[[i]] <- obj[[i]][(obj[[i]][,1] >= obj[[i]][,2]),] #lower tri
        obj[[i]] <- obj[[i]][base::order(obj[[i]][,1],obj[[i]][,2]),]
      }
      else if(inherits(obj[[i]],"ddenseMatrix")) {
        if(inherits(obj[[i]],"dgeMatrix")) {
          obj[[i]] <- as.matrix(obj[[i]])
        }
        else if(inherits(obj[[i]],"dsyMatrix") || inherits(obj[[i]],"dspMatrix")) {
          if(obj[[i]]@uplo == "U")
            obj[[i]] <- as.vector(obj[[i]])[!lower.tri(obj[[i]],diag=FALSE)]
          else
            obj[[i]] <- as.vector(t(obj[[i]]))[!lower.tri(obj[[i]],diag=FALSE)]
        }
        else {
          stop("Objects from 'ddenseMatrix' must be ",
               "'dgeMatrix', 'dspMatrix' or 'dsyMatrix'")
        }
      }
      else {
        stop("Objects from the Matrix class must be ",
             "'TsparseMatrix', 'dsparseMatrix','dgeMatrix', 'dspMatrix' or 'dsyMatrix'")
      }
      storage.mode(obj[[i]]) <- "double"
    }
    else if(is.data.frame(obj[[i]])) {
      rn <- attr(obj[[i]], "rowNames")
      for(col in 1:3) storage.mode(obj[[i]][, col]) <- "double"
    }
    else {
      storage.mode(obj[[i]]) <- "double"
      if(is.matrix(obj[[i]])) {
        if(ncol(obj[[i]]) == 3) {
          rn <- attr(obj[[i]], "rowNames")
        }
        else {
          rn <- dimnames(obj[[i]])[[1]]
        }
      }
      else {
        rn <- attr(obj[[i]], "rowNames")
      }
    }
    attr(odwEnv[[ginv.obj[i]]],"rowNames") <- rn
  }
  obj
}
findGinv <- function(mxd) {
  if(length(mxd)) {
    ginverse <- lapply(mxd$Vars,function(x){
      if(x$Fun=="vm" || x$Fun=="ric" || x$Fun == "tric")
        attributes(x$Call)
      else
        NULL})
    ginverse <- ginverse[sapply(ginverse,function(x)!is.null(x))]
  }
  else {
    ginverse <- list()
  }
  ran <- attr(mxd, "random")
  if (length(ran)) {
    ginverse <- lapply(ran$Vars, function(x) {
      if (x$Fun == "vm" || x$Fun == "ric" || x$Fun == "tric") {
        attributes(x$Call)
      } else if (x$Fun == "str") {
        cal <- x$Call # cal is a list
        for (i in 1:length(cal)) {
          if (cal[[i]]$Fun == "vm" || cal[[i]]$Fun == "ric" || cal[[i]]$Fun == "tric") {
            a <- attributes(cal[[i]]$Call)
            return(a)
          }
        }
      } else {
        NULL
      }
    })
    # name it
    nana <- NULL
    if(length(mxd)) {
      for(i in 1:length(mxd$Vars)) {
        if(mxd$Vars[[i]]$Fun=="vm" || mxd$Vars[[i]]$Fun=="ric" || mxd$Vars[[i]]$Fun == "tric") {
          nana <- c(nana, mxd$Vars[[i]]$FacNam)
        }
      }
    }
    if(length(ran)) {
      for(i in 1:length(ran$Vars)) {
        if(ran$Vars[[i]]$Fun == "str") {
          for(j in 1:length(ran$Vars[[i]]$Call)) {
            if (ran$Vars[[i]]$Call[[j]]$Fun == "vm" || ran$Vars[[i]]$Call[[j]]$Fun == "ric" || ran$Vars[[i]]$Call[[j]]$Fun == "tric") {
              nana <- c(nana, ran$Vars[[i]]$Call[[j]]$FacNam)
            }
          }
        }
      }
    }
    ginverse <- ginverse[sapply(ginverse, function(x) !is.null(x))]
    names(ginverse) <- nana
  }
  return(ginverse)
}
## Document tha data
#'
#' A row-column design
#'
#' Example field trial with 400 treatments (varieties) in a 20 column by 40 row grid
#' of plots with 2 resolvable blocks.
#'
#' @format A data frame with 4 columns and 800 rows:
#' \describe{
#' \item{Rep}{Complete field replicates, factor with 2 levels}
#' \item{Row}{Row blocks, factor with 40 levels}
#' \item{Column}{Column blocks, factor with 20 levels}
#' \item{Variety}{Treatment identifiers, factor with 400 levels}
#' }
"rc400"#' Permute a ginverse
#'
#' Reorder a ginverse from the set of individuals in the A-value.
#'
#' The relationship matrix is permuted such that individuals to be
#' included in the A-value calculation come first. This avoids some
#' expensive indexing.
#'
#' @param giv
#'
#' The (inverse) relationship matrix as a name, not a character string.
#'
#' @param data
#'
#' A character vector of levels of the permute factor that appear in
#' the data.
#'
#' @param set
#'
#' May be a character string containing either \code{"data"} (the
#' default) or \code{"ginv"}, or a character vector of levels from the
#' \code{permute} factor. The default uses the set of levels of the
#' \code{permute} factor present in the data, while \code{"ginv"} uses
#' the (super)set given by the ginverse matrix. If a vector, the
#' elements are a subset of the factor levels from the full set.
#'
#' @return
#'
#' The reordered relationship matrix.
#'
giv.order <- function(giv, data, set = "data") {
  if(length(set) == 1 && set == "ginv") {
    return(giv)
  }
  ## what have we?
  if(inherits(giv, "ginv")) {
    rn <- attr(giv, "rowNames")
  } else if(is.matrix(giv)) {
    if(ncol(giv) == 3) {
      rn <- attr(giv, "rowNames")
    } else {
      rn <- dimnames(giv)[[1]]
    }
  }
  if(is.null(rn)) {
    stop("No rowNames or dimnames found for ",giv)
  }
  if(length(set) == 1) {
    if(set == "data") {
      inAval <- is.element(rn, data)
    } else {
      stop("set must be one of 'data' or 'ginv'")
    }
  } else {
    "inAval" <- is.element(rn, as.character(set))
  }
  idx <- rep(0, length(inAval))
  neqA <- sum(inAval)
  idx[1:neqA] <- which(inAval)
  idx[seq(neqA+1, length(inAval))] <- which(!inAval)
  if(inherits(giv, "ginv") || ncol(giv) == 3) {
    ## too hard
    ##exch <- vector(length=length(rn))
    ##i <- seq(1,length(rn))
    ##exch[idx[i]] <- i
    atr <- attributes(giv)
    giv <- sparse2mat(giv)[idx,idx]
    dimnames(giv) <- list(rn[idx],rn[idx])
    attr(giv, "INVERSE") <- atr$INVERSE
    attr(giv, "inbreeding") <- atr$inbreeding
    attr(giv, "logdet") <- atr$logdet
    attr(giv, "geneticGroups") <- atr$geneticGroups
    class(giv) <- c(class(giv), "ginv")
    giv <- mat2sparse(giv)
  } else {
    atr <- attributes(giv)
    giv <- giv[idx,idx]
    attr(giv, "INVERSE") <- atr$INVERSE
  }

  return(giv)
}
evalWithData <- function(expr,data=NULL,env=NULL,evaluate=TRUE)
{
  ## add 'data' arg to a special function call
  makeExpr <- function(ee,data) {

    if(is.character(ee))
      ee <- parse(text=ee)
    switch(mode(ee[[1]]),
           "call" = {
             ee11 <- as.character(ee[[1]][[1]])
              if(!is.na(match(ee11, c(Spcls$Fun,"sections")))) {
               if(!is.null(data) && !is.element("data",names(ee[[1]]))) {
                 ll <- length(ee[[1]])+1
                 nn <- names(ee[[1]])
                 if(is.null(nn)) nn <- rep("",(ll-1))
                 ee[[1]][[ll]] <- as.name(data)
                 names(ee[[1]]) <- c(nn,"data")
               }
               ee[[1]][[1]] <- as.name(paste("odw_", ee[[1]][[1]],sep = ""))
              }
             else
               ee[1] <- ee[1]
             ## trap formulae args to struc here
             if((ee11 != "~") && (length(ee[[1]]) > 1)) {
               for(i in 2:length(ee[[1]])) {
                 ee[[1]][i] <-makeExpr(ee[[1]][i],data)
               }
             }
           },
           "numeric" = {
             ee[1] <- ee[1]
           },
           "name" = {
             ee[1] <- ee[1]
           },
           "character" = {
             ee[1] <- ee[1]
           },
           "logical" = {
             ee[1] <- ee[1]
           },
           ee[1] <- ee[1])
    ee
  }

  z <- as.character(substitute(data))
  expr <- makeExpr(expr,z)
  if(length(expr[[1]]) == 1 & mode(expr[[1]]) == "name")
    expr <- as.character(expr[1])
  if(evaluate) {
    if(is.null(env)) {
      return(eval(expr))
    }
    else {
      assign("expr",expr,envir=env)
      return(eval(expr, envir=env))
    }
  }
  else
    return(expr)
}
formula.variables <- function(form,data,prefix=NULL) {
  ## intended to be called with a (constructed) formula
  ## that may be a special function, or an interaction with one,
  ## used as a nested argument in an outer special function call.
  ##
  ## form is the formula object
  ## prefix may be set to "asr_" if form is from an "fa(x):y" construct
  ##        inside a special like 'and'
  tt <- terms(form,specials=paste(prefix,Spcls$Fun,sep=""))
  vars <- sapply(attr(tt,"variables"),function(x)my.dparse(x))[-1]
  ## eval any specials
  which <- numeric(0)
  vv <- NULL
  if(!is.null(ss <- attr(tt,"specials"))) {
    which <- unique(unlist(ss))
    vv <- sapply(vars[which],function(x, data)
                 {
                   evalWithData(x,data)$Argv
                 },data)
  }
  if(length(which) == 0)
    vv <- vars
  else if(length(which) < length(vars))
    vv <- c(vv,vars[-which])

  unlist(vv)
}
formula.specialCalls <- function(form,data,prefix=NULL) {
  ## intended to be called with a (constructed) formula
  ## that may be a special function, or an interaction with one,
  ## used as a nested argument in an outer special function call.
  ##
  ## form is the formula object
  ## prefix may be set to "asr_" if form is from an "fa(x):y" construct
  ##        inside a special like 'and'
  tt <- terms(form,specials=paste(prefix,Spcls$Fun,sep=""))
  vars <- sapply(attr(tt,"variables"),function(x)my.dparse(x))[-1]
  ## eval any specials
  which <- numeric(0)
  if(!is.null(ss <- attr(tt,"specials")))
    which <- unique(unlist(ss))
  vv <- vector(mode="list", length=length(vars))
  for(i in seq(along=vv)) {
    if(is.element(i, which))
      vv[[i]] <- evalWithData(vars[i], data)
    else
      vv[[i]] <- vars[i]
  }
  names(vv) <- sapply(vars,function(x)as.character(recurse.del(x)))
  if(length(vv)==1 && length(which)==0) vv <- unlist(vv)
  return(vv)
}

terms.variables <- function(tt) {
  ## tt is
  ## 1. a terms object (or component of one)
  ## 2. a formula
  ## 3. a character string
  if(!inherits(tt,"terms") && inherits(tt,"formula"))
    tt <- Terms(tt)
  else if(is.character(tt))
    tt <- Terms(formula(paste("~",tt)))

  vars <- sapply(attr(tt,"variables"),function(x)my.dparse(x))[-1]
  if(y <- attr(tt,"response"))
    return(vars[-y])
  else
    return(vars)
}

Terms.argv <- function(obj) {
  ## obj is a list component (eg $fixed) from a call to modelTerms()
  ## t is the model term
  ## returns $Agrv[1] from $Vars for terms in obj

  ff <- attr(obj$Terms.obj,"factors")
  out <- vector(mode="list",length=ncol(ff))
  for(i in 1:length(out)) {
    vv <- dimnames(ff)[[1]][ff[,i] > 0]
    out[[i]] <- unlist(lapply(obj$Vars[vv], function(x)x$Argv[1]))
  }
  return(out)
}
which.variables <- function(tt, term) {
  ## tt is a Terms object
  ## term is the term name or number
  ## returns the variables in the term

  ## ****Fragile - relies on tt being properly recursive
  return(dimnames(attr(tt[match(term, attr(tt,"term.labels"))], "factors"))[[1]])

}
formulaTerms <- function (form, sep = "+")
{
    if (inherits(form, "formula") || mode(form) == "call" &&
        form[[1]] == as.name("~"))
        return(formulaTerms(form[[length(form)]], sep = sep))
    if (mode(form) == "call" && form[[1]] == as.name(sep))
        return(do.call("c", lapply(as.list(form[-1]), formulaTerms,
            sep = sep)))
    if (mode(form) == "(")
        return(formulaTerms(form[[2]], sep = sep))
    if (length(form) < 1)
        return(NULL)
    list(asRhsFormula(form))
}

asRhsFormula <- function (object)
{
    if ((mode(object) == "call") && (object[[1L]] == "~")) {
        object <- eval(object)
    }
    if (inherits(object, "formula")) {
        if (length(object) != 2L) {
            stop(gettextf("formula '%s' must be of the form '~expr'",
                my.dparse(as.vector(object))), domain = NA)
        }
        return(object)
    }
    do.call("~", list(switch(mode(object), name = , numeric = ,
        call = object, character = as.name(object), expression = object[[1L]],
        stop(gettextf("'%s' cannot be of mode '%s'", substitute(object),
            mode(object)), domain = NA))))
}

Terms <- function(form, specials=NULL, keep.order=FALSE)
{
  ## Strategy to retain factor order in interactions
  ## 1. Split form on "+"
  ## 2. terms() on each to expand any / or * operators
  ## 3. terms(form)
  ## 4. Replace attributes of terms(form)

  ## trap y~1 etc
  if(length(attr(terms(form),"term.labels"))==0)
    return(terms(form))

  ff <- formulaTerms(form)
  trm <- lapply(ff,function(x){attr(terms(x,keep.order=TRUE),"term.labels")})

  tt <- terms(form,specials=Spcls$Fun,keep.order=TRUE)

  fac <- attr(tt,"factors")
  trm <- unique(unlist(trm))
  dimnames(fac)[[2]] <- trm

  if(!keep.order) {
    odr <- attr(tt,"order")
    idx <- base::order(odr)
    fac <- fac[,idx,drop=FALSE]
    attr(tt,"order") <- odr[idx]
    trm <- trm[idx]
  }
  attr(tt,"factors") <- fac
  attr(tt,"term.labels") <- trm
  return(tt)
}
is.special <- function(x) {
  match(as.character(x), Spcls$Fun, nomatch=0)
}
narg <- function(x) {
  n <- is.special(x)
  if(n > 0)
    ifelse(Spcls$ObjArgs[n] == -1, NA, Spcls$ObjArgs[n])
  else
    NA
}
spc_args <- function(x, arg) {
  if(is.atomic(x)) {
    if(is.character(x)) {
      ##print(x)
      arg <- c(arg, x)
    }
  }
  else if(is.name(x)) {
    ##print(x)
    arg <- c(arg, as.character(x))
  }
  else if(is.call(x)) {
    ##print(x[[1]])
    n <- narg(x[[1]])
    if(length(x) > 1) {
      ulim <- ifelse(is.na(n), length(x), n+1)
      if(ulim > 1) {
        for(i in seq(2,ulim)) {
          arg <- spc_args(x[[i]], arg)
        }
      }
    }
  }
  else if(is.pairlist(x)) {
  }
  else {
    stop("Don't know what to do with ", typeof(x))
  }
  arg
}
keep.subset <- function(DT, sub) {
  ## does a subset keeping attributes
  std <- names(attributes(data.table())) #attr(DT, "std.attr")
  attrib <- attributes(DT)[symdiff(names(attributes(DT)), std)]
  DT <- subset(DT, sub)
  if(length(attrib) > 0) {
    for(a in names(attrib))
      setattr(DT, a, attrib[[a]])
  }
  DT
}
modelNames <- function(form)
{
  ## Base factors for model frame

  if(form.null(form)) return(NULL)
  ignore <- seq(1,(1+(attr(form,"response") > 0)))
  vv <- attr(form,"variables")
  unlist(lapply(vv[-ignore], function(x) {
                  arg <- character(0)
                  spc_args(x, arg)}))
}
form.null <- function(ff) {
  ifelse(is.null(ff[[length(ff)]]), TRUE, FALSE)
}
modelFrame <- function(tt,call,options,data,na.action)
{
  ## data is a data.table, NOT data.frame !!!!
  ## Strategy:
  ##  1. identify the response (may be a matrix, or factor for multinom)
  ##  2. add units
  ##  3. get 'group' and 'mbf' field names
  ##  4. glm total
  ##  4a check any PSD G-inverses to get additional levels
  ##  5. call modelTerms to get base factors from specials (pass 1)
  ##  6. eval base terms from 5, and drop unused columns
  ##  7. subset rows
  ##  8. filter missing values
  ##  9. expand if multivariate
  ## 10. drop unused levels in factors
  ## 11. add missing value factor
  ## 12. call modelTerms if multivariate or missing values

  ## Hack to suppress R CMD CHECK warnings
  total <- trait <- NULL

  fixed <- tt$fixed
  if(!form.null(tt$random))
    random <- tt$random
  else
    random <- terms(~NULL)
  if(!form.null(tt$permute))
    permute <- tt$permute
  else
    permute <- terms(~NULL)
  if(!form.null(tt$swap))
    swap <- tt$swap
  else
    swap <- terms(~NULL)

  odwEnv <- attr(tt$fixed,".Environment")

  if(!form.null(tt$residual))
    residual <- tt$residual
  else
    residual <- trimSpc(Terms(~ units))

  ## add units
  ## data may be a null data table
  if(ncol(data))
    data[,units:=factor(1:nrow(data))]
  else
    stop("'data' must not be empty or missing.")

  ## groups & mbf
  ## Set as attributes of data here for eval()
  if(!is.null(call$group)) {
      group <- eval(call$group)
      varNames <- names(data)
    for(i in names(group)) {
      if(is.numeric(group[[i]]))
        group[[i]] <- varNames[group[[i]]]
      else {
        if(any(is.na(match(group[[i]],varNames))))
          stop(paste("Object in group",i,"not in data."))
       }
    }
      gnames <- unique(unlist(group))
  }
  else {
    group <- list()
    gnames <- NULL
  }
  setattr(data,"GROUP",group)
  ## mbf
  ## keep data tables in a list; added to by mbf()
  setattr(data,"MBF",list())
  xtras <-  c(gnames, "units")
  if(!is.null(call$resolve)) {
    if(nchar(as.character(call$resolve)) > 0) {
      if(!is.element(as.character(call$resolve), names(data))) {
        stop("resolve column ", as.character(call$resolve), " not found in data")
      }
      if(!is.logical(data[[as.character(call$resolve)]])) {
        stop("resolve column ", as.character(call$resolve), " must be of type logical")
      }
      data[["..resolve"]] <- as.integer(data[[as.character(call$resolve)]])
    }
  } else {
    data[, ..resolve:=rep(1, nrow(data))]
  }
  xtras <- c(xtras, "..resolve")

  vv <- unique(c(modelNames(fixed),
                 modelNames(random),
                 modelNames(permute),
                 modelNames(swap),
                 modelNames(residual),
                 xtras)) # for mv

  ## Assume vv is a character vector of:
  ## 1. base variable names
  ## 2. std functions like "log(x)"
  ## 3. special functions

  ## Evaluate vv in data
  data[, (vv):= lapply(vv, function(x)eval(parse(text=x), envir=data, enclos=odwEnv))]

  ## subset the data
  if(!is.null(call$subset)) {
    sub <- eval(call$subset,data,odwEnv)
    if(length(sub) != nrow(data))
      stop("size of subset (",length(sub), ") does not match size of data (",
           nrow(data),").")
    data <- keep.subset(data, sub)
  }

  ## Drop any unused columns (by ref)
  if(any(!is.element(names(data),vv)))
    data[, (names(data)[!is.element(names(data),vv)]) := NULL]

  ## filter missing values
  ## All records are retained for multivariate analyses
  ## keep is a logical vector (stored as integer for C) of records to retain
  keep <- do.call("mv.method",args=list(object=data, x=na.action[1], xvar=vv))
  data <- keep.subset(data,keep)
  storage.mode(keep) <- "integer"
  setattr(data,"keep",keep)

  ## drop unused levels by reference
  if (options$drop.unused.levels) {
    for (nm in names(data)) {
      x <- data[[nm]]
      if (is.factor(x) && length(unique(x[!is.na(x)])) <
          length(levels(x)))
        data[, (nm):= droplevels(data[[nm]])]
    }
  }

  ## Resolve levels in 'equate.levels'
  if(length(eql <- eval(call$equate.levels)) > 1) {
    ## Check all exist and are factors
    if(any(is.na(match(eql,names(data)))))
      stop("Elements of 'equate.levels' not in data")
    if(!all(sapply(subset(data,select=eql),function(x)is.factor(x))))
      stop("Not all elements of 'equate.levels' are factors")

    ulev <- unique(unlist(lapply(subset(data,select=eql),function(x)levels(x))))
    for(i in eql)
      data[, (i):= factor(as.character(data[[i]]),levels=ulev)]
  }

  ## eval specials to get levels, data cols etc, correct.
  random <- formOrder(random, data, options$random.order)
  ## expand str()
  mixed <- expandStr(random, data)
  model.terms <- modelTerms(fixed, mixed, random, residual, permute, swap, data)

  ## kept record nos
  rkeep <- which(as.logical(keep))
  storage.mode(rkeep) <- "integer"
  setattr(data, "rkeep", rkeep)

  ## asreml does this to get the correct levels for singular ginv
  ## Ginverse(s)
  ## checkPSD(attr(model.terms$mixed, "random")$Vars)

  setattr(data, "model.terms", model.terms)
  class(data) <- c(class(data),"odw.model.frame")

  data
}
expandStr <- function(random,data)
{
  ## generate terms for str()
  ## 13/6/14
  ## Note str() returns a 'terms' object in obj !!!!!!!!!!!!!

  as.vec <- function(string) {
    return(strsplit(string,"+",fixed=TRUE)[[1]])
  }

  ## ----------------------> START

  if(length(random[[2]])==0) return(random)

  tt <- Terms(random,specials=Spcls$Fun, keep.order = TRUE)
  which <- attr(tt,"specials")$str

  terms.fac <- attr(tt,"factors")
  terms.var <- dimnames(terms.fac)[[1]]
  terms.lab <- dimnames(terms.fac)[[2]]

  str.group <- character(0)

  if(all(is.null(which))) {
    form <- random
    str.group <- rep("",length(terms.lab))
    attr(form,"str.group") <- str.group
    return(form)
  }

  ## preserve attributes
  tType <- attr(random,"tType")
  vType <- attr(random,"vType")

  str <- numeric(0)
  for(w in which)
    str <- c(str,seq(1,length(terms.lab))[terms.fac[w,] > 0])

  terms.use <- character(0)

  for(i in 1:length(terms.lab)) {
    if(any(str==i)) {
      ## split term
      ## work out which is str & get obj
      ## check if at & expand
      ## paste back together
      tts <- Terms(formula(paste("~",terms.lab[i])),
                   specials=Spcls$Fun, keep.order = TRUE)
      trm <- dimnames(attr(tts,"factors"))[[1]]
      ww <- attr(tts,"specials")$str
      if(length(ww) > 1)
        stop("Direct product of 'str' terms not allowed")
      wa <- attr(tts,"specials")$at
      outer <- NULL
      if(length(ww)+length(wa) != length(trm)) {
        outer <- paste(trm[-ww],collapse=":")
        ##stop("Direct product with 'str' not allowed")
      }
      ## If outer term is "at", generate multiple str instances
      atTrm <- character(0)
      if(length(wa)) {
        if(length(wa) > 1)
          stop("Multiple at' terms not allowed")
        A <- evalWithData((dimnames(attr(tts,"factors"))[[1]])[wa],data)
        ## A term for each level of at() ##
        ## eval str
        Y <- evalWithData((dimnames(attr(tts,"factors"))[[1]])[ww],data)
        tt.use <- dimnames(attr(Y$Obj,"factors"))[[2]]
        atLvls <- getLevels(A$Lvls)
        for(a in atLvls) {
          atTrm <- c(atTrm,paste("at(",A$Obj,", ","'",a,"'",")",sep=""))
        }
      }
      else {
        ## eval str
        Y <- evalWithData(dimnames(attr(tts,"factors"))[[1]][ww],data)
        tt.use <- dimnames(attr(Y$Obj,"factors"))[[2]]
      }
      ## paste back and expand at
      if(length(atTrm)) {
        tmp.group <- paste(atTrm,Y$FacNam,collapse=":")
        temp <- paste(atTrm,
                      paste("(",paste(tt.use,collapse="+"),")",sep=""),
                      sep=":")
        tt.use <- attr(Terms(formula(paste("~",paste(temp,collapse="+"))),
                             keep.order=TRUE),"term.labels")
        str.group <- c(str.group,rep(tmp.group,each=length(attr(Y$Obj,"term.labels"))))
      }
      else if(length(outer)) {
        tmp.group <- paste(outer,Y$FacNam,sep=":")
        temp <- paste(outer,
                      paste("(",paste(tt.use,collapse="+"),")",sep=""),
                      sep=":")
        tt.use <- attr(Terms(formula(paste("~",paste(temp,collapse="+"))),
                             keep.order=TRUE),"term.labels")
        str.group <- c(str.group,rep(tmp.group,each=length(attr(Y$Obj,"term.labels"))))
      }
      else {
        tt.use <- paste(tt.use,collapse="+")
        str.group <- c(str.group,rep(Y$FacNam,each=length(attr(Y$Obj,"term.labels"))))
      }
      terms.use <- c(terms.use,tt.use)
    }
    else {
      terms.use <- c(terms.use,terms.lab[i])
      str.group <- c(str.group,"")
    }
  }
  form <- formula(paste("~",paste(terms.use,collapse="+")))
  ## set/fix attributes
  attr(form,"str.group") <- str.group
  return(form)
}


## 5.9.8 Finding and setting variables
## -----------------------------------
##
## It will be usual that all the R objects needed in our C computations
## are passed as arguments to `.Call' or `.External', but it is possible
## to find the values of R objects from within the C given their names.
## The following code is the equivalent of `get(name, envir = rho)'.
##
##      SEXP getvar(SEXP name, SEXP rho)
##      {
##        SEXP ans;
##
##        if(!isString(name) || length(name) != 1)
##          error("name is not a single string");
##        if(!isEnvironment(rho))
##          error("rho should be an environment");
##        ans = findVar(install(CHAR(STRING_ELT(name, 0))), rho);
##        Rprintf("first value is %f\n", REAL(ans)[0]);
##        return(R_NilValue);
##      }
##
##    The main work is done by `findVar', but to use it we need to install
## `name' as a name in the symbol table.  As we wanted the value for
## internal use, we return `NULL'.
##
##    Similar functions with syntax
##
##      void defineVar(SEXP symbol, SEXP value, SEXP rho)
##      void setVar(SEXP symbol, SEXP value, SEXP rho)
##
## can be used to assign values to R variables.  `defineVar' creates a new
## binding or changes the value of an existing binding in the specified
## environment frame; it is the analogue of `assign(symbol, value, envir =
## rho, inherits = FALSE)', but unlike `assign', `defineVar' does not make
## a copy of the object `value'.(1)  `setVar' searches for an existing
## binding for `symbol' in `rho' or its enclosing environments.  If a
## binding is found, its value is changed to `value'.  Otherwise, a new
## binding with the specified value is created in the global environment.
## This corresponds to `assign(symbol, value, envir = rho, inherits =
## TRUE)'.
##
##    ---------- Footnotes ----------
##
##    (1) You can assign a _copy_ of the object in the environment frame
## `rho' using `defineVar(symbol, duplicate(value), rho)').
na.method <- function(x=c("fail","include","omit"))
{
  return(x)
}
mv.method <- function(object, x=c("fail","include","omit"), ...)
{
  na.exclude.data.table <- function (object,vars, ...)
    {
      keep <- complete.cases(object[,vars,with=FALSE])
      if (any(keep))
        attr(keep, "class") <- "exclude"
      else
        stop("All observations excluded")
      keep
    }

  na.omit.data.table <- function (object, vars, ...)
    {
      keep <- complete.cases(object[,vars,with=FALSE])
       if (any(keep))
        attr(keep, "class") <- "omit"
      else
        stop("All observations omitted")
      keep
    }

  na.fail.default <- function (object, vars, ...)
    {
      if(!all(complete.cases(object[,vars,with=FALSE]))) {
        if(length(vars)==1)
          stop("missing values in ",vars,".")
        else
          stop("missing values among ",paste(vars,collapse=","),".")
      }
      return(invisible())
    }

  ##----------------------------------------------------
  keep <- rep(TRUE,nrow(object))
  if(!is.null(tt <- attr(object,"terms"))) {
    object.X <- dimnames(attr(tt,"factors"))[[1]]
  }
  else {
    ddd <- list(...)
    object.X <- ddd$xvar
  }
  if(x == "fail")
    na.fail.default(object,object.X)
  else if(x == 'omit' || x=="exclude")
    keep <- do.call(paste("na",x,"data.table",sep="."),
                    args=list(object=object,vars=object.X))

  keep
}
fpipe <- function(form) {
  pipe <- function(expr) {
    ## return the expressions separated by "|"
    ## on first entry, expr is the expression on the right of "~"
    if (is.name(expr) || !is.language(expr)) return(NULL)
    if (expr[[1]] == as.name("(")) return(pipe(expr[[2]]))
    if (!is.call(expr)) stop("expr must be of class call")
    if (expr[[1]] == as.name("|")) return(expr)
    if (length(expr) == 2) return(pipe(expr[[2]]))
    c(pipe(expr[[2]]), pipe(expr[[3]]))
  }
  e <- form[[2]]
  f <- pipe(e)
  if(is.null(f)) {
    return(list(form))
  }
  else {
    return(lapply(f[-1],function(x){formula(paste0("~",my.dparse(x)))}))
  }
}

modelTerms <- function(fixed=~NULL, mixed=~NULL, random=~NULL,
                      residual=~NULL, permute=~NULL, swap=~NULL, data)
{
  ##
  ##                           model
  ##                           /  \
  ##             fixed --------    -------- random ------- perm ------- res
  ##             /  \                        / \            / \         / \
  ##        Terms() vars               Terms() vars
  ##                /  \                       /  \
  ##             var1 var2 ...               var1 var2 ...
  ##              |    |                       |    |
  ##           eval() eval()                eval() eval()
  ##
  ##
  ## Fixed terms: model == 'id' && param = Inf ??

  ## Set Rcov flag 'globally' as an attribute of data
  ##     needed to get power models correct

  ## Fixed, Random, Residual
  setattr(data, "Rcov", FALSE)
  fxd <- list()

  ## reset keep,order if and() used
  ko <- ifelse(!is.null(attr(Terms(formula(fixed),specials=Spcls$Fun), "specials")$xpr), TRUE,
               odw.options()$keep.order)
  fxd$Terms.obj <- trimSpc(Terms(formula(fixed),specials=Spcls$Fun,
                                 keep.order=ko))
  fxd$Vars <- modelList(fxd$Terms.obj, data)

  keep.order <- ifelse(odw.options()$random.order=="R",FALSE,TRUE)

  mxd <- list()
  setattr(data, "Rcov", FALSE)
  if(length(mixed[[2]])) {
    mxd$Terms.obj <- trimSpc(Terms(formula(mixed),specials=Spcls$Fun,
                                   keep.order=keep.order))
    mxd$Vars <- modelList(mxd$Terms.obj, data)
    attr(mxd$Terms.obj,"str.group") <- attr(mixed,"str.group")
  }

  rnd <- list()
  setattr(data, "Rcov", FALSE)
  rnd$Terms.obj <- trimSpc(Terms(formula(random),specials=Spcls$Fun,
                                 keep.order=keep.order))
  rnd$Vars <- modelList(rnd$Terms.obj, data)

  ## make a hidden formula from the expressions in xpr (aka and())
  hdn <- list()

  ht <- unique(c(unlist(lapply(fxd$Vars, function(x){
    if(x$Fun == "xpr") {
      return(attr(Terms(formula(paste("~", paste(x$Argv, collapse="+")))), "term.labels"))
    }
    else {
      return(NULL)
    }})),
    unlist(lapply(rnd$Vars, function(x){
      if(x$Fun == "xpr" || x$Fun == "str") {
      return(attr(Terms(formula(paste("~", paste(x$Argv, collapse="+")))), "term.labels"))
    }
    else {
      return(NULL)
    }}))))
  if(length(ht)) {
    hidden <- formula(paste("~",paste(ht,collapse="+")))
    hdn$Terms.obj <- trimSpc(Terms(hidden, specials=Spcls$Fun))
    hdn$Vars <- modelList(hdn$Terms.obj, data)
  }

  res <- list()
  setattr(data, "Rcov", TRUE)
  if(length(residual[[2]])) {
    res$Terms.obj <- trimSpc(Terms(formula(residual),specials=Spcls$Fun,
                                   keep.order=TRUE))
    res$Vars <- modelList(res$Terms.obj, data)
  }

  ## permute - separate into left & right
  pp <- fpipe(permute)
  prmL <- list()
  setattr(data, "Rcov", FALSE)
  prmL$Terms.obj <- trimSpc(Terms(formula(pp[[1]]),specials=Spcls$Fun,
                                 keep.order=keep.order))
  prmL$Vars <- modelList(prmL$Terms.obj, data)
  prmR <- list()
  if(length(pp) > 1) {
    prmR$Terms.obj <- trimSpc(Terms(formula(pp[[2]]),specials=Spcls$Fun,
                                    keep.order=keep.order))
    prmR$Vars <- modelList(prmR$Terms.obj, data)
  }

  swp <- list()
  setattr(data, "Rcov", FALSE)
  swp$Terms.obj <- trimSpc(Terms(formula(swap),specials=Spcls$Fun,
                                 keep.order=keep.order))
  swp$Vars <- modelList(swp$Terms.obj, data)

  ## unset Rcov flag
  setattr(data, "Rcov", NULL)

  ## set the intercept flag to 0 for all but fxd
  if(length(mxd)) {
    attr(mxd$Terms.obj, "intercept") <- 0
  }
  if(length(rnd)) {
    attr(rnd$Terms.obj, "intercept") <- 0
  }
  if(length(res)) {
    attr(res$Terms.obj, "intercept") <- 0
  }
  if(length(prmL)) {
    attr(prmL$Terms.obj, "intercept") <- 0
  }
  if(length(prmR)) {
    attr(prmR$Terms.obj, "intercept") <- 0
  }
  if(length(swp)) {
    attr(swp$Terms.obj, "intercept") <- 0
  }
  if(length(hdn)) {
    attr(hdn$Terms.obj, "intercept") <- 0
  }

  ## IN OD MAKE RANDOM AN ATTRIBUTE OF MIXED
  attr(mxd, "random") <- rnd

  model <- list(fixed=fxd, mixed=mxd, residual=res,
                permuteL=prmL, permuteR=prmR, swap=swp, hidden=hdn)

  model
}
modelList <- function(tt, data)
{
  ## tt is a terms object
  rsp <- attr(tt,"response")
  tt.vars <- dimnames(attr(tt,"factors"))[[1]]
  tt.terms <- dimnames(attr(tt,"factors"))[[2]]
  idx <- seq(along=tt.vars)
  if(any(rsp > 0))
    idx <- idx[-rsp]
  ## out is an evaluated list of length no. of variables

  ## May have a fixed form like y~1 (length(tt.terms)==0 in that case)
  if(rsp && length(tt.terms) == 0) {
      out <- vector(mode="list", length=1)
      out[[1]] <- NULL #"(Intercept)"
  }
  else {
    nvars <- length(tt.vars)
    out <- vector(mode="list", length=length(idx))

    howMany <- unlist(lapply(attr(tt,"specials"),function(x)length(x)))
    fun <- list(trm=unlist(attr(tt,'specials')),
                fun=rep(names(attr(tt,"specials")),times=howMany))
    model <- rep("id",nvars)
    is.set <- rep(FALSE,nvars)
    model[fun$trm] <- fun$fun
    is.set[fun$trm] <- TRUE
    for(v in seq(along=idx)) {
      idxv <- idx[v]
      if(is.set[idxv])
        out[[v]] <- evalWithData(tt.vars[idxv],data)
      else
        out[[v]] <- do.call(paste("odw_",model[idxv],sep=""),
                            list(obj=tt.vars[idxv], data=data))
    }
    names(out) <- tt.vars[idx]
  }
  out
}

#' Set odw() options.
#'
#' Sets or displays various options that affect the behaviour of
#' \code{odw}.
#'
#' If called with no arguments then a list of current option values is
#' returned. The list of options is held in an environment
#' \code{.ODWenv} in the \code{odw} database.
#'
#' \describe{
#'
#' \item{random.start}{number of random interchanges prior to the design
#' search. The default is 1000, and 0 may be specified. No initial interchanges 
#' are done if \code{search="random"} is specified on the \code{odw} call.}
#' 
#' \item{time}{estimate the time for a single tabu loop (that is, a greedy search
#' of the entire neighbourhood) from a set of random interchanges. If > 0, 
#' the objective criterion is evaluated the specified
#' number of times prior to the optimisation step. The elapsed time is reported and 
#' used to estimate the execution time
#' for a scavenging tabu loop. The default is 0.}
#'
#' \item{criterion}{the optimality criterion; only \code{"avalue"} or \code{"pev"}
#' are allowed at present; the default is \code{"avalue"}.}
#'
#' \item{debug}{turn on debug mode. If logical and \code{TRUE}, the
#' internal R data structures are returned, else if numeric
#' \code{debug = 1, 2} increasingly verbose summaries of the working
#' data structures are printed.}
#'
#' \item{design}{If \code{TRUE} the design matrices \code{W1} and \code{W2} are returned.
#' The default is \code{FALSE}.}
#' 
#' \item{P}{the probability of accepting a non-improving design in a random
#' walk; the default is \code{P=0.001}.}
#'
#' \item{localSearch}{the number of steps in the random walk local search 
#' strategy of the \code{"tabu+rw"} \code{search} option; the default is 10000.}
#'
#' \item{tabuTime}{if the number of tabu loops a visited
#' design remains taboo (the default is 2).}
#'
#' \item{tabuTimeTol}{The time spent in the taboo list is \code{t * tabuTime},
#' where \code{t} is chosen randomly from the range 
#' (\code{1-tabuTimeTol}, \code{1+tabuTimeTol}). 
#' The default is \code{tabuTimeTol=0.5}.}
#' 
#' \item{tabuStop}{if the number of consecutive tabu loops with no
#' change in the objective function exceeds \code{tabuStop}, then tabu
#' optimization terminates (the default is 4).}
##
## \item{search.threads}{Experimental. Used to inititiate a multi-threaded 
## \code{random} or \code{tabu} search. The default is 1 to use sequential
## methods; other settings are not recommended at this time.}
##
#' \item{tol}{the tolerance used to determine zero eigenvalues of the coefficient matrix
#' \code{C}; eigenvalues with absolute values less than \code{tol} are deemed to be zero.
#' The default \code{NA} implies that \code{tol = sqrt(eps)} where \code{eps} is the
#' relative machine precision returned by the BLAS routine \code{dlamch}
#' (defaults to approximately 1e-8).}
#' 
#' \item{MPmethod}{the method used to form the Moore-Penrose inverse. Values are \code{"evd"} or \code{"svd"}
#' for an eigenvalue decomposition for symmetric matrices, or a singular value decomposition, respectively.}
#' 
#' \item{trace}{if \code{TRUE} the status of the design search is
#' periodically reported. The default is \code{FALSE}.}
#'
#' \item{verbose}{if \code{TRUE} report the elapsed time for various 
#' steps of the program. The default is \code{FALSE}.}
#'
#' \item{cxp}{relative character size for titling text (0.66).}
#'
#' \item{lxp}{relative character size of point labels (2.0).}
#'
#' \item{brk}{stride for axis tick marks (1.0).}
#'
#' }
#'
#' @param ...
#'
#' A series of comma separated \code{name=value} pairs, where
#' \code{name} is a character string matching one of the options
#' below, and \code{value} is the allowable setting.
#'
odw.options <- function(...)
{
  args <- list(...)
  if (is.null(names(args)) && length(args) == 1 && is.list(args[[1]])) args <- args[[1]]
  old <- get("odw_options", envir = .ODWenv)

  ## if no args supplied, returns full options list
  if (length(args) == 0)
    return(old)

  nm <- names(args)

  if (is.null(nm))
    return(old[unlist(args)]) ## typically getting options, not setting
  isNamed <- nm != "" ## typically all named when setting, but could have mix

  if (any(!isNamed)) nm[!isNamed] <- unlist(args[!isNamed])

  ## so now everything has non-"" names, but only the isNamed ones should be set
  ## everything should be returned, however
  out <- old[nm]
  names(out) <- nm
  nm <- nm[isNamed]

  .ODWenv$odw_options <- updateList(old, args)

  ## return changed entries invisibly
  invisible(out)
}
.control <- function() {
  list(criterion="avalue", #avalue, pev
       trace=FALSE,
       P=0.001,
       localSearch=10000,
       tabuIntensity=1,
       tabuStop=4,
       tabuTime=2,
       tabuTimeTol=0.5,
       debug=FALSE,
       search.threads=1,
       update4=40, #4=scalar+external alloc; 40=vec+local storage; 41=scalar+local storage
       random.start=1000,
       time=0,
       verbose=FALSE,
       drop.unused.levels=TRUE,
       random.order = "user", #user, R
       tol=NA,
       MPmethod="evd",
       keep.order = FALSE, #for fixed terms
       design = FALSE,
       cxp=0.66, # relative size of titling text
       lxp=2.0, # relative size of point labels
       brk=1     # stride for axis labels
       )
}
updateList <- function(x, val)
{
  if (is.null(x)) x <- list()
  utils::modifyList(x, val)
}
#' Generate a model term from an algebraic expression
#'
#' Creates columns in the design matrix for a factor (or variate) that
#' is the result of an algebraic expression with existing model terms
#' as the operands.
#'
#' The expression is given in an R formula object and the levels of
#' all participating terms must conform (in size). Allowed operators
#' are '+', '-', '*' and '/' with any constants or coefficients given
#' explicitly; all other symbols are expected to resolve to model
#' terms.
#'
#' @param form
#'
#' The algebraic expression in a single sided R formula.
#'
#' @name xpr
#' @usage xpr(form)
#'
odw_xpr <- function(form, data)
{
  if(!inherits(form, "formula"))
     stop("Argument to xpr() must be a formula")
  if(length(form) == 3)
    stop("Argument to xpr() must be a one-sided formula")
  string <- deparse(form[[2]])

  ttree <- function(node,x) {
    if(mode(node)=="expression" && length(node)==1) {
      x <- ttree(node[[1]],x)
      return(x)
    }
    else if(length(node)==1) {
      x <- c(x,as.character(node))
      return(x)
    }
    if(mode(node)=="call" && is.element(as.character(node[[1]]),Spcls$Fun))
      x <- c(x,deparse(node))
    else {
      x <- ttree(node[[2]],x)
      if(length(node) > 2)
        x <- ttree(node[[3]],x)
      x <- c(x,as.character(node[[1]]))
    }
    x
  }
  all.trm <- function(node,x,dta) {
    if(mode(node)=="expression" && length(node)==1) {
      x <- all.trm(node[[1]],x,dta)
      return(x)
    }
    else if(length(node)==1) {
      if(is.element(as.character(node),dta))
        x <- c(x,as.character(node))
      return(x)
    }
    if(mode(node)=="call" && is.element(as.character(node[[1]]),Spcls$Fun))
      x <- c(x,deparse(node))
    else if(mode(node)!="call" && is.element(as.character(node),dta))
      x <- c(x,as.character(node))
    else {
      x <- all.trm(node[[2]],x,dta)
      if(length(node) > 2)
        x <- all.trm(node[[3]],x,dta)
      ##x <- c(x,as.character(node[[1]]))
    }
    x
  }
  all.fun <- function(node,x) {
    if(mode(node)=="expression" && length(node)==1) {
      x <- all.fun(node[[1]],x)
      return(x)
    }
    else if(length(node)==1) {
      #x <- c(x,as.character(node))
      return(x)
    }
    if(mode(node)=="call" && is.element(as.character(node[[1]]),Spcls$Fun))
      x <- c(x,as.character(node[[1]]))
    else {
      x <- all.fun(node[[2]],x)
      if(length(node) > 2)
        x <- all.fun(node[[3]],x)
      ##x <- c(x,as.character(node[[1]]))
    }
    x
  }
  out <- vector(mode="list",length=10)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial","Lab","Coords",
                  "Argv","isVariance","FacNam")

  ## Fun
  out$Fun <- "xpr"

  ## Call
  out$Call <- spCall(sys.call())

  ## Obj
  out$Obj <- string

  ee <- parse(text=string)
  x <- NULL
  x <- ttree(ee,x)
  Vars <- NULL
  Vars <- all.trm(ee,Vars,names(data))
  ## f <- NULL
  ## f <- all.fun(ee,f)
  ## f[is.null(f)] <- "idv"
  ## out[[11]] <- f
  ## Levels
  ##Vars <- all.vars(ee)
  vLevels <- sapply(Vars,function(z,d)
                    {
                      if(mode(parse(text=z)[[1]]) == "call")
                        length(evalWithData(parse(text=z),data=data)$Lvls)
                      else
                        length(levels(d[[z]]))
                    },data)

  if (length(unique(vLevels)) != 1) {
    print(vLevels)
    stop("Levels in xpr() do not conform")
  }
  out$Lvls <- levels(factor(seq(1,vLevels[1])))
  out$Initial <- as.numeric(NA)
  names(out$Initial) <- ""
  attr(out$Initial, "Tgamma") <- ""
  out$Lab <- "" #paste0("_",out$Lvls)
  out$Coords <- list()
  ## Argv
  out$Argv <- Vars
  out$isVariance <- FALSE
  out$FacNam <- out$Call
  oldClass(out) <- "odw.special"
  out
}
spc <- function(fun,fam,ncor,nvar,k,obj,init,data)
{
  out <- vector(mode="list",length=10)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial",
                  "Lab","Coords","Argv","isVariance","FacNam")

  ## "model" functions
  if(fam == "mdl") {
    obj <- as.character(obj)
    out$Fun <- fun
    out$Call <- spCall(sys.call(-1))
    out$Obj <- obj
    out$FacNam <- out$Call
    if(is.factor(data[[obj]])) {
      lvls <- levels(data[[obj]])
      out$Lvls <- lvls #as.integer(length(lvls))
    }
    else
      out$Lvls <- obj #1
    out$Initial <- as.numeric(NA)
    names(out$Initial) <- ""
    attr(out$Initial, "Tgamma") <- ""
    out$Lab <- ""
    out$Coords <- list()
    out$Argv <- obj
    out$isVariance <- NA
    oldClass(out) <- "odw.special"
    return(out)
  }
  ## variance/correlation functions
  nest <- inherits(obj,"odw.special")
  if(nest) {
    out$Fun <- obj$Fun #fun
    out$Call <- spCall(sys.call(-1))
    lab <- obj$FacNam
    out$Obj <- obj$Obj
    out$FacNam <- obj$FacNam
    out$Lvls <- obj$Lvls
    lvls <- obj$Lvls
    out$Coords <- obj$Coords
    out$Argv <- obj$Argv
  }
  else {
    if(is.numeric(obj)) {
      lvls <- as.character(seq(1,obj))
      lab <- paste(fun,"(",obj,")",sep="")
      cal <-  spCall(sys.call(-1))
      obj <- as.character(obj)
    }
    else {
      obj <- as.character(obj)
      cal <- spCall(sys.call(-1)) #obj
      if(is.factor(data[[obj]]))
        lvls <- levels(data[[obj]])
      else if(fun == "id" || fun == "idv")
        lvls <- obj
      else
        stop(paste(obj,"must be a factor"))
      lab <- obj
    }

    ## Fun
    out$Fun <- fun
    ## Call
    out$Call <- cal
    ## Obj
    out$Obj <- obj
    out$FacNam <- out$Obj
    ## Lvls
    out$Lvls <- lvls #as.integer(length(lvls))
  }
  n <- length(out$Lvls)
  what.var <- eval(parse(text=as.character(nvar)))
  if(is.vector(what.var))
    Nv <- length(what.var)
  else if(is.matrix(what.var))
    Nv <- n*(n+1)/2
  else if(is.null(what.var))
    Nv <- 0
  else
    stop("Unrecognised mode for nvar")

  what.cor <- eval(parse(text=as.character(ncor)))
  if(is.vector(what.cor)) {
    Nc <- length(what.cor)
  }
  else if(is.matrix(what.cor)) {
    Nc <- n*(n-1)/2
  }
  else if(is.null(what.cor)) {
    Nc <- 0
  }
  else
    stop("Unrecognised mode for ncor")

  IniFlag <- ifelse(all(is.na(init)),FALSE,TRUE)
  if(IniFlag) {
    if(is.character(init)) init <- eval(parse(text=init))
    if(length(init) != Nc+Nv)
      stop(paste(fun,"- Wrong number of initial values\n"))
  }
  ## Correlation models
  if(fam == "cor") {
    if(!IniFlag) {
      init <- c(what.cor, what.var)
      if(length(init)==0)
        init <- NA
    }
    out$Initial <- as.double(init)
    attr(out$Initial, "set") <- IniFlag

    if(is.matrix(what.cor)) {
      x <- (row(what.cor) < col(what.cor))
      corLab <- c(paste(paste("!",lab,"!",lvls[col(x)[x]],sep=""),
                        ":",
                        paste("!",lab,"!",lvls[row(x)[x]],sep=""),
                        ".cor",sep=""))
    }
    else if(Nc > 1)
      corLab <- paste("!",lab,paste("!cor",seq(1,Nc),sep=""),sep="")
    else if(Nc == 1)
      corLab <- paste("!",lab,"!cor",sep="")
    else
      corLab <- character(0)

    if(Nv > 1)
      varLab <- paste("!",lab,"_",lvls,sep="")
    else if(Nv == 1 && Nc > 0)
      varLab <- paste("!",lab,"!var",sep="")
    else
      varLab <- character(0)

    out$Lab <- c(corLab,varLab)
    if(length(out$Lab) == 0) out$Lab <- paste("!",lab,sep="")

    attr(out$Initial, "Tgamma") <- c(rep("R",Nc),rep("V",Nv))
    out$isVariance <- ifelse(Nv==0,FALSE,TRUE)
  }
  ## Variance models
  else if(fam == "var") {
    if(is.matrix(what.var)) {
      if(!IniFlag)
        init <- what.var[t(lower.tri(what.var,diag=TRUE))]
       ## EM updates for us structures
      labels <- switch(fun,
                       us = {x <- t(lower.tri(matrix(nrow=n,ncol=n),diag=TRUE))
                             paste("!",lab,"_",
                                   paste(lvls[col(x)[x]],lvls[row(x)[x]],sep=":"),sep="")},
                       chol = {x <- t(lower.tri(what.var,diag=TRUE))
                               y <- col(x)-row(x) > k
                               temp <- paste("!",lab,"_",
                                             paste(lvls[col(x)[x]],lvls[row(x)[x]],sep=":"),sep="")
                               temp[y[!lower.tri(y)]] <- paste(temp[y[!lower.tri(y)]],"<NotEstimated>",sep="")
                               temp},
                       cholc = {x <- t(lower.tri(what.var,diag=TRUE))
                                y <- (col(x)-row(x) >= k) & row(x) > k
                                temp <- paste("!",lab,"_",
                                              paste(lvls[col(x)[x]],lvls[row(x)[x]],sep=":"),sep="")
                                temp[y[!lower.tri(y)]] <- paste(temp[y[!lower.tri(y)]],"<NotEstimated>",sep="")
                                temp},
                       ante = {x <- t(lower.tri(what.var,diag=TRUE))
                               y <- col(x)-row(x) > k
                               temp <- paste("!",lab,"_",
                                             paste(lvls[col(x)[x]],lvls[row(x)[x]],sep=":"),sep="")
                               temp[y[!lower.tri(y)]] <- paste(temp[y[!lower.tri(y)]],"<NotEstimated>",sep="")
                               temp}
                       )
      out$Lab <- labels
      tgam <- matrix(4,nrow=n,ncol=n)-diag(2,nrow=n)
      tgam <- tgam[t(lower.tri(tgam, diag=TRUE))]
    } # end if matrix
    else {
      if(!IniFlag)
        init <- what.var
      if(Nv > 1)
        out$Lab <- paste("!",lab,"_",lvls,sep="")
      else
        out$Lab <- character()
      tgam <- rep("V", Nv)
    }
    out$Initial <- as.double(init)
    attr(out$Initial, "Tgamma") <- tgam
    attr(out$Initial, "set") <- IniFlag
    out$isVariance <- TRUE
  }
  ## trap special case idv (fam=cor)
  if(!nest) {
    out$Coords <- list()
    out$Argv <- obj
  }

  oldClass(out) <- "odw.special"
  out
}
#' General variance structures.
#'
#' General variance structure spanning consecutive model terms.
#'
#' Typically, a variance structure applies to an individual term (main
#' effect or interaction) in the linear model, and there is no
#' covariance between model terms. Sometimes it is appropriate to
#' include a covariance, such as random coefficients regression, for
#' example. In such cases it is essential that the model terms be
#' contiguous and that the variance structure defined is the structure
#' required across all terms in the set. While \code{odw}
#' will check the overall size of the included terms, it cannot check
#' that the order of effects matches the structure definition in
#' \code{vmodel}; care must be taken to ensure this is correct. Check
#' that the terms are conformable by considering the order of the
#' fitted effects and ensuring the first term of the direct product in
#' \code{vmodel} corresponds to the outer factor in the nesting of the
#' effects in \code{form}.
#'
#' @param form
#'
#' A model formula included verbatim when parsing the \code{odw()}
#' \code{random} argument.
#'
#' @param vmodel
#'
#' A direct product variance model for the set of terms given in
#' \code{form}.
#'
#' @aliases str
#' @name str
#' @usage str(form, vmodel)
#'
odw_str <- function(form, vmodel, data)
{
#  if(mode(substitute(obj))=="call" && inherits(obj,"odw.special"))
#    stop("Argument to str() must be a formula\n")
  out <- vector(mode="list",length=10)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial",
                  "Lab","Coords","Argv","isVariance","FacNam")

  ttf <- trimSpc(Terms(as.formula(form),keep.order=TRUE))
  ttm <- Terms(as.formula(vmodel),keep.order=TRUE)

  form.lab <- attr(ttf,"term.labels")

  form.var <- lapply(form.lab, function(x){
    dimnames(attr(Terms(formula(paste("~",x))),"factors"))[[1]]})

  vmodel.lab <- dimnames(attr(ttm,"factors"))[[2]]
  if(length(vmodel.lab) > 1)
    stop("Invalid vmodel formula in str()")
  vmodel.var <- dimnames(attr(ttm,"factors"))[[1]]
  ndim <- length(vmodel.var)

  Y <- lapply(vmodel.var, function(x,data) {
    evalWithData(x,data)
  },data)

  vn <- dimnames(attr(ttf,"factors"))[[1]]
  FVars <- lapply(vn,function(x,data) {
    evalWithData(x,data)
  },data)
  names(FVars) <- vn

  ## Check conformity
  lcheck <- lapply(Y,function(x){
    getLevels(x$Lvls)
  })
  ## fsize = sum(levels( "Anim","Anim:time", ...))
  ##         inner sapply does prod(levels(strsplit("Anim:time")))
  vsize <- prod(sapply(lcheck,function(x)length(x)))
  fsize <- sum(unlist(lapply(form.var, function(x,FV,data){
    w <- sapply(x,function(z,FV,data){
      if(inherits(FV[[z]],"odw.special")) {
        length(getLevels(FV[[z]]$Lvls))
      }
      else {
        ifelse(is.factor(data[[z]]),length(levels(data[[z]])),1)
      }
    },FVars,data)
    prod(w)
  },FVars,data)),na.rm=TRUE)

  if(vsize != fsize)
    stop(paste("Size of direct product (",vsize,
               ") does not conform with total size of included terms (",fsize,")",sep=""))

  ## Fun
  out$Fun <- "str"

  ## Call
  out$Call <- Y
  names(out$Call) <- sapply(Y,function(x)x$Call)

  ## Obj
  out$Obj <- ttf
  ## Levels
  out$Lvls <- lapply(Y,function(x)x$Lvls)
  names(out$Lvls) <- sapply(Y,function(x)x$Fun)

  ## Initial & Con
  out$Initial <- lapply(Y,function(x)x$Initial)
  names(out$Initial) <- sapply(Y,function(x)x$Fun)

  ## Lab
  out$Lab <- lapply(Y,function(x)x$Lab)
  names(out$Lab) <- sapply(Y,function(x)x$Fun)

  ##Coords
  out$Coords <- list(faconst=NULL,nuxPoints=NULL,coords=NULL)

  ## Argv
  out$Argv  <- paste(unlist(lapply(form.var, function(x,FV,data){
    #y <- strsplit(x,":",fixed=TRUE)[[1]]
    w <- sapply(x,function(z,FV,data){
      if(inherits(FV[[z]],"odw.special") && FV[[z]]$Fun == "grp")
        FV[[z]]$Obj
      else if(inherits(FV[[z]],"odw.special"))
        FV[[z]]$Call
      else
        z
    },FVars,data)
    paste(w,collapse=":")
  },FVars,data)), collapse="+")
  out$Argv <- unlist(lapply(FVars,function(x)x$Argv))

  ## isVariance
  out$isVariance <- {x <- unlist(lapply(Y,function(x)x$isVariance))
                if(any(is.na(x)))
                  NA
                else if(any(x))
                  TRUE
                else
                  FALSE
              }
  out$FacNam <- paste(form.lab, collapse="+") #spCall(sys.call())

  oldClass(out) <- "odw.special"
  #out[c("Fun","Call","Obj","FacNam")]
  out
}
#' Known variance structures.
#'
#' Model function associating a known variance structure with a factor
#' in the data.
#'
#' If \code{source} inherits from class \code{Matrix}, \code{odw}
#' will convert \code{source} internally to either sparse triplet form
#' (class \code{dsparseMatrix}), or dense vector form (class
#' \code{ddenseMatrix}) for processing.
#'
#' @param obj
#'
#' A factor in \code{data}.
#'
#' @param source
#'
#' The known inverse or relationship matrix:
#'
#' \itemize{
#'
#' \item a sparse inverse variance
#' matrix held in three column co-ordinate form in row major
#' order. This triplet matrix must have class \code{ginv}
#' from a call to \code{ainverse()}, or have attribute \code{INVERSE}
#' set to \code{TRUE}. For backwards compatability, a three column
#' data frame is also accepted. In either case, the \code{source} must
#' have a \code{rowNames} attribute.
#'
#' \item a sparse relationship
#' matrix held in three column co-ordinate form (as a matrix) in row major
#' order. If the attribute \code{INVERSE} is not set then
#' \code{FALSE} is assumed; a \code{rowNames}
#' attribute must be set.
#'
#' \item a \code{matrix} (or \code{Matrix} object) with a
#' \code{dimnames} attribute giving the levels of the model term
#' being defined. This may be a relationship matrix or its inverse; if
#' an inverse, it must have an attribute \code{INVERSE} set to
#' \code{TRUE}.
#'
#' \item a numeric vector of the lower triangular elements in row
#' major order. The vector must have a \code{rowNames} attribute, and
#' if an inverse structure, it must also have an \code{INVERSE}
#' attribute set to \code{TRUE}.  }
#'
#' @param singG
#'
#' A character string. Ignored if \code{source} has class \code{ginv}
#' or attribute \code{INVERSE}=\code{TRUE}; in such cases
#' \code{source} must be one of:
#'
#' \itemize{
#'
#' \item a sparse matrix in coordinate form with class \code{ginv}, or
#' attribute \code{INVERSE}=\code{TRUE}, or
#'
#' \item an object of class \code{matrix} or \code{Matrix}
#' with \code{INVERSE}=\code{TRUE}, or
#'
#' \item a vector assumed to be the lower triangle in row
#' major order with attribute \code{INVERSE}=\code{TRUE}.
#' }
#'
#' If \code{source} does not have class \code{ginv}, or the attribute
#' \code{INVERSE} is \code{FALSE} or is not set, and \code{singG} is
#' \code{NULL} (the default), then \code{source} is assumed a positive
#' definite relationship matrix and \code{singG} is reset to
#' \code{"PD"}. \bold{Currently this is the only valid value for
#' \code{singG}, that is, if the source matrix is not an inverse it
#' must be positive definite.}
#'
#' @aliases vm ide ric
#' @name knownStructures
NULL
#' @describeIn knownStructures Create a model term associating a known
#' relationship structure in \code{source} with a factor in
#' \code{data}.
#'
#' @usage vm(obj, source, singG=NULL)
#'
odw_vm <- function(obj, source, singG=NULL, data)
{
  out <- vector(mode="list",length=10)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial",
                  "Lab","Coords","Argv","isVariance","FacNam")

  inter2 <- FALSE
  if(mode(substitute(obj))=="call" && inherits(obj,"odw.special")) {
    ## extend to handle vm(grp()) etc
    out$Fun <- "vm"
    out$Call <- spCall(sys.call())
    out$Obj <- obj$Obj
    out$Lvls <- obj$Lvls
    ## if obj[[1]] is grp then do stuff to inter??????
    out$Coords <- obj$Coords
    out$Argv <- obj$Argv
    out$FacNam <- out$Call #obj$FacNam  ## FacNam
  }
  else {
    out$Fun <- "vm"
    ## Call
    obj <- as.character(substitute(obj))
    out$Call <- spCall(sys.call())
    ## Obj
    out$Obj <- obj
    out$Lvls <- NA # set below
    out$FacNam <- out$Call  ## FacNam
    inter2 <- TRUE
    ##Coords
    out$Coords <- list()
    ## Argv
    out$Argv <- obj
  }

  ## figure out what we have:
  ## if source inherits class 'ginv'
  ##    just read the object (df or 3 column matrix)
  ## if a matrix then check for rowNames, then dimnames
  ##    if singG=PD/PSD/ND/NSD then a relationship matrix to be inverted
  ##    if is.null(singG) assume PD unless class=ginv
  ## else
  ##    check if vector....

  if(is.character(source)) {
    expr <- as.name(source)
    source <- get(source)
  }
  else
    expr <- as.name(substitute(source))

  inv <- attr(source, "INVERSE")
  if(is.null(inv))
    inv <- FALSE
  inv <- (inv || inherits(source, "ginv"))

  if(!is.null(singG)) {
    if(inv)
      stop("'singG' set for an inverse object.", call.=FALSE)
    if(!is.element(casefold(singG), c("pd","psd","nd","nsd")))
      stop("'singG' must be NULL, or one of 'pd','psd','nd','nsd'.", call.=FALSE)
  }

  ## Assume a 3 col data frame is A^{-1}
  ## Assume a 3 col matrix is A^{-1} unless attr inverse=FALSE
  if(is.data.frame(source)) {
    if(ncol(source) == 3) { # Assume an inverse or ginv
      if(!inv) {
        stop("Source object ", as.character(expr),
             " must be a sparse inverse; coerce to a matrix.", call.=FALSE)
      }
      singG <- "ginv"
      inverse <- TRUE
      if(is.null(glvls <- attr(source,"rowNames")))
        stop("Missing 'rowNames' attribute.", call.=FALSE)

      if(is.unsorted(do.call("order",list(source[,1], source[,2]))))
        stop(as.character(expr)," does not appear to be in row-major order.",
             call.=FALSE)
      lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
    }
    else
      stop("Data frame must have 3 columns.", call.=FALSE)
  }
  else if(inherits(source, c("matrix", "Matrix"))) {
    if(inv) {
      singG <- "ginv"
      inverse <- TRUE
    }
    else {
      inverse <- FALSE
      singG <- if(is.null(singG)) "pd" else singG
    }
    nc <- if(inherits(source,"TsparseMatrix"))
            ncol(summary(source))
          else
            ncol(source)
    if(nc == 3) {
      if(inherits(source,"TsparseMatrix")) { ## gets sorted in '
        if(is.null(glvls <- dimnames(source)[[1]])) {
          stop("'source' is missing a 'dimnames' attribute 1.", call.=FALSE)
        }
        else {
          lev <- rownames(source) #as.call(list(as.name("rownames"),expr))
        }
      }
      else {
        if(is.unsorted(do.call("order",list(source[,1], source[,2]))))
          stop(as.character(expr)," does not appear to be in row-major order.",
               call.=FALSE)
        if(is.null(glvls <- attr(source,"rowNames")))
          stop("'source' is missing a 'rowNames' attribute.", call.=FALSE)
        lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
      }
    }
    else {
      if(is.null(glvls <- attr(source, "rowNames"))) { # rowNames gets priority - may be set from checkPSD
        if(is.null(glvls <- dimnames(source)[[1]])) {
          stop("'source' is missing a 'dimnames' attribute.")
        }
        else {
          lev <- rownames(source) #as.call(list(as.name("rownames"),expr))
        }
      }
      else {
        lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
      }
    }
  }
  else { # vector
    if(inv) {
      singG <- "ginv"
      inverse <- TRUE
    }
    else {
      inverse <- FALSE
      singG <- if(is.null(singG)) "pd" else singG
      message("Note: ",as.character(expr), " assumed a relationship (not inverse) structure.")
    }
    if(is.null(glvls <- attr(source,"rowNames"))) {
      stop("'source' is missing a 'rowNames' attribute.")
    }
    else {
      lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
    }
  }

  if(!is.character(glvls))
    stop("'rowNames' must be of mode 'character'.", call.=FALSE)

  attr(out$Call,"Source") <- as.character(expr)
  attr(out$Call,"singG") <- singG
  attr(out$Call,"inverse") <- inverse
  attr(out$Call,"ricardo") <- 0
  if(is.null(attr(source, "logdet")))
    attr(out$Call,"logdet") <- -1e-37
  else
    attr(out$Call,"logdet") <- attr(source, "logdet")
  if(is.null(attr(source, "geneticGroups")))
    attr(out$Call,"geneticGroups") <- c(0.0,0.0)
  else
    attr(out$Call,"geneticGroups") <- attr(source, "geneticGroups")

  if(inter2) { # from above
    v <- match(obj,names(data))
    if(!is.factor(data[[obj]]))
      stop("Argument to vm() must be a factor)\n", call.=FALSE)

    if(length(flvls <- levels(data[[obj]])) == 0)
      flvls <- unique(data[[obj]])
    not_genotyped <- symdiff(intersect(flvls,glvls), flvls)
    if(length(not_genotyped) > 0) {
      ##cat(not_genotyped,"\n")
      warning(obj," has levels in the data that are missing in ",expr,
              call. = FALSE, immediate. = FALSE)
    }
    out$Lvls <- lev

    ## Use this for ide!
    setattr(data[[obj]],"rowNames",c(glvls, not_genotyped))
  }

  ## Initial & Con
  out$Initial <- as.numeric(NA)
  attr(out$Initial, "Tgamma") <- ""

  ## Lab
  out$Lab <- "" #"!var"

  ## isVariance
  out$isVariance <- FALSE

  oldClass(out) <- "odw.special"
  out
}

#' @describeIn knownStructures Create a term with the levels of \code{vm},
#' and modelled by the homogeneous form of the identity variance
#' structure. The \code{vm} term must precede \code{ide} in the model
#' for the factor levels to be found.
#'
#' @usage ide(obj)
#'
odw_ide <- function(obj, source=NULL, data)
{
  out <- vector(mode="list",length=10)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial",
                  "Lab","Coords","Argv","isVariance","FacNam")

  if(mode(substitute(obj))=="call" && inherits(obj,"odw.special")) {
    ## extend to handle vm(grp()) etc
    out$Fun <- "ide"
    out$Call <- spCall(sys.call())
    out$Obj <- obj$Obj
    out$Lvls <- obj$Lvls
    ## if obj[[1]] is grp then do stuff to inter??????
    out$Coords <- obj$Coords
    out$Argv <- obj$Argv
    out$FacNam <- out$Call #obj$FacNam  ## FacNam
  }
  else {
    out$Fun <- "ide"
    ## Call
    obj <- as.character(substitute(obj))
    out$Call <- spCall(sys.call())
    ## Obj
    out$Obj <- obj
    out$Lvls <- NA # set below
    out$FacNam <- out$Call  ## FacNam
    ##Coords
    out$Coords <- list()
    ## Argv
    out$Argv <- obj
  }

  ## figure out what we have:
  ## if source inherits class 'ginv'
  ##    just read the object (df or 3 column matrix)
  ## if a matrix then check for rowNames, then dimnames
  ##    if singG=PD/PSD/ND/NSD then a relationship matrix to be inverted
  ##    if is.null(singG) assume PD unless class=ginv
  ## else
  ##    check if vector....

  if(!is.null(source)) {
    if(is.character(source)) {
      expr <- as.name(source)
      source <- get(source)
    }
    else
      expr <- as.name(substitute(source))
    ## Assume a 3 col data frame is A^{-1}
    ## Assume a 3 col matrix is A^{-1} unless attr inverse=FALSE
    if(is.data.frame(source)) {
      if(ncol(source) == 3) {
        if(is.null(glvls <- attr(source,"rowNames")))
          stop("Missing 'rowNames' attribute.", call.=FALSE)
        lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
      }
      else
        stop("ide() source Data frame must have 3 columns.", call.=FALSE)
    }
    else if(inherits(source, c("matrix", "Matrix"))) {
      nc <- if(inherits(source,"TsparseMatrix"))
              ncol(summary(source))
            else
              ncol(source)
      if(nc == 3) {
        if(inherits(source,"TsparseMatrix")) { ## gets sorted in '
          if(is.null(glvls <- dimnames(source)[[1]])) {
            stop("ide() 'source' is missing a 'dimnames' attribute.", call.=FALSE)
          }
          else {
            lev <- rownames(source) #as.call(list(as.name("rownames"),expr))
          }
        }
        else {
          if(is.null(glvls <- attr(source,"rowNames")))
            stop("ide() 'source' is missing a 'rowNames' attribute.", call.=FALSE)
          lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
        }
      }
      else {
        if(is.null(glvls <- attr(source, "rowNames"))) {
          ## rowNames gets priority - may be set from checkPSD
          if(is.null(glvls <- dimnames(source)[[1]])) {
            stop("'source' is missing a 'dimnames' attribute.")
          }
          else {
            lev <- rownames(source) #as.call(list(as.name("rownames"),expr))
          }
        }
        else {
          lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
        }
      }
    }
    else { # vector
      if(is.null(glvls <- attr(source,"rowNames"))) {
        stop("ide() 'source' is missing a 'rowNames' attribute.")
      }
      else {
        lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
      }
    }

    if(!is.character(glvls))
      stop("'rowNames' must be of mode 'character'.", call.=FALSE)

    if(length(flvls <- levels(data[[obj]])) == 0)
      flvls <- unique(data[[obj]])
    not_genotyped <- symdiff(intersect(flvls,glvls), flvls)
    if(length(not_genotyped) > 0) {
      ##cat(not_genotyped,"\n")
      warning(obj," has levels in the data that are missing in ",expr,
              call. = FALSE, immediate. = FALSE)
    }
    setattr(data[[obj]],"rowNames",c(glvls, not_genotyped))
  }
  else {
    if(is.null(lev <- attr(data[[obj]],"rowNames")))
      stop("ide: 'rowNames' attribute not set for ",obj,". ide() precedes vm()?",
           call. = FALSE)
  }
  out$Lvls <- lev

  ## Initial & Con
  IniFlag <- FALSE
  out$Initial <- as.numeric(NA)
  attr(out$Initial, "Tgamma") <- ""

  ## Lab
  out$Lab <- "!var"

  ## isVariance
  out$isVariance <- FALSE

  oldClass(out) <- "odw.special"
  out
}

#' @describeIn knownStructures Create a model term associating a known
#'   relationship structure in \code{source} and residual additive
#'   genetic effects with a factor in \code{data}.
#'
#' @usage ric(obj, source, singG=NULL)
#'
odw_ric <- function(obj, source, singG=NULL, init=c(0.2, 0.1), data)
{
  out <- vector(mode="list",length=10)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial",
                  "Lab","Coords","Argv","isVariance","FacNam")

  inter2 <- FALSE
  if(mode(substitute(obj))=="call" && inherits(obj,"odw.special")) {
    ## extend to handle ric(grp()) etc
    out$Fun <- "ric"
    out$Call <- spCall(sys.call())
    out$Obj <- obj$Obj
    out$Lvls <- obj$Lvls
    ## if obj[[1]] is grp then do stuff to inter??????
    out$Coords <- obj$Coords
    out$Argv <- obj$Argv
    out$FacNam <- out$Call #obj$FacNam  ## FacNam
  }
  else {
    out$Fun <- "ric"
    ## Call
    obj <- as.character(substitute(obj))
    out$Call <- spCall(sys.call())
    ## Obj
    out$Obj <- obj
    out$Lvls <- NA # set below
    out$FacNam <- out$Call  ## FacNam
    inter2 <- TRUE
    ##Coords
    out$Coords <- list()
    ## Argv
    out$Argv <- obj
  }

  ## figure out what we have:
  ## if source inherits class 'ginv'
  ##    just read the object (df or 3 column matrix)
  ## if a matrix then check for rowNames, then dimnames
  ##    if singG=PD/PSD/ND/NSD then a relationship matrix to be inverted
  ##    if is.null(singG) assume PD unless class=ginv
  ## else
  ##    check if vector....

  if(is.character(source)) {
    expr <- as.name(source)
    source <- get(source)
  }
  else
    expr <- as.name(substitute(source))

  inv <- attr(source, "INVERSE")
  if(is.null(inv))
    inv <- FALSE
  inv <- (inv || inherits(source, "ginv"))

  if(!is.null(singG)) {
    if(inv)
      stop("'singG' set for an inverse object.", call.=FALSE)
    if(!is.element(casefold(singG), c("pd","psd","nd","nsd")))
      stop("'singG' must be NULL, or one of 'pd','psd','nd','nsd'.", call.=FALSE)
  }

  ## Assume a 3 col data frame is A^{-1}
  ## Assume a 3 col matrix is A^{-1} unless attr inverse=FALSE
  if(is.data.frame(source)) {
    if(ncol(source) == 3) { # Assume an inverse or ginv
      if(!inv) {
        stop("Source object ", as.character(expr),
             " must be a sparse inverse; coerce to a matrix.", call.=FALSE)
      }
      singG <- "ginv"
      inverse <- TRUE
      if(is.null(glvls <- attr(source,"rowNames")))
        stop("Missing 'rowNames' attribute.", call.=FALSE)

      if(is.unsorted(do.call("order",list(source[,1], source[,2]))))
        stop(as.character(expr)," does not appear to be in row-major order.",
             call.=FALSE)
      lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
    }
    else
      stop("Data frame must have 3 columns.", call.=FALSE)
  }
  else if(inherits(source, c("matrix", "Matrix"))) {
    if(inv) {
      singG <- "ginv"
      inverse <- TRUE
    }
    else {
      inverse <- FALSE
      singG <- if(is.null(singG)) "pd" else singG
    }
    nc <- if(inherits(source,"TsparseMatrix"))
            ncol(summary(source))
          else
            ncol(source)
    if(nc == 3) {
      if(inherits(source,"TsparseMatrix")) { ## gets sorted in '
        if(is.null(glvls <- dimnames(source)[[1]])) {
          stop("'source' is missing a 'dimnames' attribute 1.", call.=FALSE)
        }
        else {
          lev <- rownames(source) #as.call(list(as.name("rownames"),expr))
        }
      }
      else {
        if(is.unsorted(do.call("order",list(source[,1], source[,2]))))
          stop(as.character(expr)," does not appear to be in row-major order.",
               call.=FALSE)
        if(is.null(glvls <- attr(source,"rowNames")))
          stop("'source' is missing a 'rowNames' attribute.", call.=FALSE)
        lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
      }
    }
    else {
      if(is.null(glvls <- attr(source, "rowNames"))) { # rowNames gets priority - may be set from checkPSD
        if(is.null(glvls <- dimnames(source)[[1]])) {
          stop("'source' is missing a 'dimnames' attribute.")
        }
        else {
          lev <- rownames(source) #as.call(list(as.name("rownames"),expr))
        }
      }
      else {
        lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
      }
    }
  }
  else { # vector
    if(inv) {
      singG <- "ginv"
      inverse <- TRUE
    }
    else {
      inverse <- FALSE
      singG <- if(is.null(singG)) "pd" else singG
      message("Note: ",as.character(expr), " assumed a relationship (not inverse) structure.")
    }
    if(is.null(glvls <- attr(source,"rowNames"))) {
      stop("'source' is missing a 'rowNames' attribute.")
    }
    else {
      lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
    }
  }

  if(!is.character(glvls))
    stop("'rowNames' must be of mode 'character'.", call.=FALSE)

  attr(out$Call,"Source") <- as.character(expr)
  attr(out$Call,"singG") <- singG
  attr(out$Call,"inverse") <- inverse
  attr(out$Call,"ricardo") <- 1
  if(is.null(attr(source, "logdet")))
    attr(out$Call,"logdet") <- -1e-37
  else
    attr(out$Call,"logdet") <- attr(source, "logdet")
  if(is.null(attr(source, "geneticGroups")))
    attr(out$Call,"geneticGroups") <- c(0.0,0.0)
  else
    attr(out$Call,"geneticGroups") <- attr(source, "geneticGroups")

  if(inter2) { # from above
    v <- match(obj,names(data))
    if(!is.factor(data[[obj]]))
      stop("Argument to ric() must be a factor)\n", call.=FALSE)

    if(length(flvls <- levels(data[[obj]])) == 0)
      flvls <- unique(data[[obj]])
    not_genotyped <- symdiff(intersect(flvls,glvls), flvls)
    if(length(not_genotyped) > 0) {
      ##cat(not_genotyped,"\n")
      warning(obj," has levels in the data that are missing in ",expr,
              call. = FALSE, immediate. = FALSE)
    }
    out$Lvls <- lev

    ## Use this for ide!
    setattr(data[[obj]],"rowNames",c(glvls, not_genotyped))
  }

  ## Initial & Con
  out$Initial <- as.double(init)
  attr(out$Initial, "Tgamma") <- c("V","V")

  ## Lab
  out$Lab <- c(paste0("!",obj,"_vm"), paste0("!",obj,"_ide"))

  ## isVariance
  out$isVariance <- TRUE

  oldClass(out) <- "odw.special"
  out
}
#' @describeIn knownStructures Create a model term associating a known
#'   relationship structure in \code{source} and residual additive
#'   genetic effects with a factor in \code{data}.
#'
#' @usage tric(obj, source, singG=NULL)
#'
odw_tric <- function(obj, source, singG=NULL, init=c(0.2, 0.1), data)
{
  out <- vector(mode="list",length=10)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial",
                  "Lab","Coords","Argv","isVariance","FacNam")

  inter2 <- FALSE
  if(mode(substitute(obj))=="call" && inherits(obj,"odw.special")) {
    ## extend to handle tric(grp()) etc
    out$Fun <- "tric"
    out$Call <- spCall(sys.call())
    out$Obj <- obj$Obj
    out$Lvls <- obj$Lvls
    ## if obj[[1]] is grp then do stuff to inter??????
    out$Coords <- obj$Coords
    out$Argv <- obj$Argv
    out$FacNam <- out$Call #obj$FacNam  ## FacNam
  }
  else {
    out$Fun <- "tric"
    ## Call
    obj <- as.character(substitute(obj))
    out$Call <- spCall(sys.call())
    ## Obj
    out$Obj <- obj
    out$Lvls <- NA # set below
    out$FacNam <- out$Call  ## FacNam
    inter2 <- TRUE
    ##Coords
    out$Coords <- list()
    ## Argv
    out$Argv <- obj
  }

  ## figure out what we have:
  ## if source inherits class 'ginv'
  ##    just read the object (df or 3 column matrix)
  ## if a matrix then check for rowNames, then dimnames
  ##    if singG=PD/PSD/ND/NSD then a relationship matrix to be inverted
  ##    if is.null(singG) assume PD unless class=ginv
  ## else
  ##    check if vector....

  if(is.character(source)) {
    expr <- as.name(source)
    source <- get(source)
  }
  else
    expr <- as.name(substitute(source))

  inv <- attr(source, "INVERSE")
  if(is.null(inv))
    inv <- FALSE
  inv <- (inv || inherits(source, "ginv"))

  if(!is.null(singG)) {
    if(inv)
      stop("'singG' set for an inverse object.", call.=FALSE)
    if(!is.element(casefold(singG), c("pd","psd","nd","nsd")))
      stop("'singG' must be NULL, or one of 'pd','psd','nd','nsd'.", call.=FALSE)
  }

  ## Assume a 3 col data frame is A^{-1}
  ## Assume a 3 col matrix is A^{-1} unless attr inverse=FALSE
  if(is.data.frame(source)) {
    if(ncol(source) == 3) { # Assume an inverse or ginv
      if(!inv) {
        stop("Source object ", as.character(expr),
             " must be a sparse inverse; coerce to a matrix.", call.=FALSE)
      }
      singG <- "ginv"
      inverse <- TRUE
      if(is.null(glvls <- attr(source,"rowNames")))
        stop("Missing 'rowNames' attribute.", call.=FALSE)

      if(is.unsorted(do.call("order",list(source[,1], source[,2]))))
        stop(as.character(expr)," does not appear to be in row-major order.",
             call.=FALSE)
      lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
    }
    else
      stop("Data frame must have 3 columns.", call.=FALSE)
  }
  else if(inherits(source, c("matrix", "Matrix"))) {
    if(inv) {
      singG <- "ginv"
      inverse <- TRUE
    }
    else {
      inverse <- FALSE
      singG <- if(is.null(singG)) "pd" else singG
    }
    nc <- if(inherits(source,"TsparseMatrix"))
            ncol(summary(source))
          else
            ncol(source)
    if(nc == 3) {
      if(inherits(source,"TsparseMatrix")) { ## gets sorted in '
        if(is.null(glvls <- dimnames(source)[[1]])) {
          stop("'source' is missing a 'dimnames' attribute 1.", call.=FALSE)
        }
        else {
          lev <- rownames(source) #as.call(list(as.name("rownames"),expr))
        }
      }
      else {
        if(is.unsorted(do.call("order",list(source[,1], source[,2]))))
          stop(as.character(expr)," does not appear to be in row-major order.",
               call.=FALSE)
        if(is.null(glvls <- attr(source,"rowNames")))
          stop("'source' is missing a 'rowNames' attribute.", call.=FALSE)
        lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
      }
    }
    else {
      if(is.null(glvls <- attr(source, "rowNames"))) { # rowNames gets priority - may be set from checkPSD
        if(is.null(glvls <- dimnames(source)[[1]])) {
          stop("'source' is missing a 'dimnames' attribute.")
        }
        else {
          lev <- rownames(source) #as.call(list(as.name("rownames"),expr))
        }
      }
      else {
        lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
      }
    }
  }
  else { # vector
    if(inv) {
      singG <- "ginv"
      inverse <- TRUE
    }
    else {
      inverse <- FALSE
      singG <- if(is.null(singG)) "pd" else singG
      message("Note: ",as.character(expr), " assumed a relationship (not inverse) structure.")
    }
    if(is.null(glvls <- attr(source,"rowNames"))) {
      stop("'source' is missing a 'rowNames' attribute.")
    }
    else {
      lev <- attr(source, "rowNames") #as.call(list(as.name("attr"),expr,"rowNames"))
    }
  }

  if(!is.character(glvls))
    stop("'rowNames' must be of mode 'character'.", call.=FALSE)

  attr(out$Call,"Source") <- as.character(expr)
  attr(out$Call,"singG") <- singG
  attr(out$Call,"inverse") <- inverse
  attr(out$Call,"ricardo") <- 2
  if(is.null(attr(source, "logdet")))
    attr(out$Call,"logdet") <- -1e-37
  else
    attr(out$Call,"logdet") <- attr(source, "logdet")
  if(is.null(attr(source, "geneticGroups")))
    attr(out$Call,"geneticGroups") <- c(0.0,0.0)
  else
    attr(out$Call,"geneticGroups") <- attr(source, "geneticGroups")

  if(inter2) { # from above
    v <- match(obj,names(data))
    if(!is.factor(data[[obj]]))
      stop("Argument to tric() must be a factor)\n", call.=FALSE)

    if(length(flvls <- levels(data[[obj]])) == 0)
      flvls <- unique(data[[obj]])
    not_genotyped <- symdiff(intersect(flvls,glvls), flvls)
    if(length(not_genotyped) > 0) {
      ##cat(not_genotyped,"\n")
      warning(obj," has levels in the data that are missing in ",expr,
              call. = FALSE, immediate. = FALSE)
    }
    out$Lvls <- lev
    ## Use this for ide!
    setattr(data[[obj]],"rowNames",c(glvls, not_genotyped))
  }

  ## Initial & Con
  out$Initial <- as.double(init)
  attr(out$Initial, "Tgamma") <- c("V","V")

  ## Lab
  out$Lab <- c(paste0("!",obj,"_vm"), paste0("!",obj,"_ide"))

  ## isVariance
  out$isVariance <- TRUE

  oldClass(out) <- "odw.special"
  out
}
#' Direct sum structures for residual models.
#'
#' @param model
#'
#' A formula of the form \code{~A+B+...|Z}, where \code{A} and
#' \code{B} define variance matrices for simple or compound model
#' terms, and \code{Z} is a simple conditioning factor whose levels
#' identify and determine the number of sub-matrices in the direct
#' sum. The \code{"|"} operator is applied associatively and operates
#' with all terms on its left; that is, \code{A+B|C} implies
#' \code{(A+B)|C} and is equivalent to \code{A|C+B|C}.
#'
#' @param levels
#'
#' A list of length the number of terms in the left hand side of
#' \code{model} that are separated by \code{"+"}. The components of
#' \code{levels} are vectors of factor levels of \code{Z}. If there is
#' only one term in the left hand side of \code{model} (or if the
#' context allows, see examples) then \code{levels} may be a
#' vector. If \code{NULL}, the default is to use \code{levels(Z)}.
#'
#' @name dsum
#' @usage dsum(model, levels=NULL)
#'
odw_dsum <- function(model, levels=NULL, data) {

  ## model is a formula: ~ A + B + C | D
  ## where A,B,C are model terms involving variance structures
  ## Eg for R (scale=1):
  ##
  ## ~ar1v(Col):ar1(Row) + idv(Col):id(Row) | Site
  ##
  ## levels is a list of length the number of terms separated by "+",
  ##   the elements of which are vectors of levels of D.
  ## Eg
  ## levels=list(c('Warwick','Dalby'),'Gatton')
  ## So,
  ## dsum(~ar1v(Col):ar1(Row) + idv(Col):id(Row) | Site,
  ##      levels=list(c('Warwick','Dalby'),'Gatton'))
  ##
  ## means fit an arXar at sites W & D, and an id at G
  ##
  ## Arthur's !SUBSECTION examples on P147 of the SA V3 guide
  ## dsum(~ar1v(bid) | auction, outer=TRUE)
  ## dsum(expv(date) | plot, outer=TRUE)
  outer <- FALSE
  call <- spCall(sys.call())

  ## split model on "|"
  m1 <- formulaTerms(model, sep="|")
  if(length(m1) != 2)
    stop("Invalid dsum model")
  ## split m1 on "+"
  lhs <- formulaTerms(m1[[1]], sep="+")
  cf <- attr(terms(m1[[2]]),"term.labels")
  if(length(lhs) > 1) {
    if(is.list(levels)) {
      if(length(levels) != length(lhs))
        stop("levels' must be a list of length ",length(lhs), call.=FALSE)
    }
    else if(is.null(levels)) {
      if(length(lhs) != length(levels(data[[cf]])))
         stop("Insufficient variance structures for ",
              length(levels(data[[cf]])), " sections", call.=FALSE)
      levels <- as.list(seq(1, length(levels(data[[cf]]))))
    }
    else
      stop("levels' must be a list of length ",length(lhs), call.=FALSE)
  }

  if(outer && length(lhs) > 1)
    stop("dsum: Only a single term allowed if 'outer=TRUE'", call.=FALSE)
  ##
  ## return a list (one for each level of cf) of special
  ##        function evaluations

  if(is.null(levels))
    ds.lev <- V.lev <- levels(data[[cf]])
  else if(is.list(levels)) {
    V.lev <- levels
    for(ll in seq(1,length(V.lev))) {
      if(is.numeric(V.lev[[ll]])) V.lev[[ll]] <- levels(data[[cf]])[V.lev[[ll]]]
    }
    ds.lev <- unlist(V.lev)
  }
  else if(is.numeric(levels))
    ds.lev <- V.lev <- levels(data[[cf]])[levels]
  else
    ds.lev <- V.lev <- levels
  if(!all(is.element(ds.lev, levels(data[[cf]]))))
     stop("Elements in 'levels' argument not in data")

##   if(is.list(V.lev)) {
##     V.len <- sum(sapply(V.lev,function(x)length(x)))
##     V.nam <- unlist(sapply(V.lev,function(x)x))
##   }
##   else {
##     V.len <- length(V.lev)
##     V.nam <- V.lev
##   }

  ## model terms fixed, mixed, random, residual, Csparse, dense, data
  model.terms <- modelTerms(residual=m1[[1]],data=data)$residual
  if(outer && length(model.terms$Vars) > 1)
    stop("Only one dimension allowed if 'outer=TRUE'")

  ## look-up table "section, term, fun" (section is levels of cf)
  if(is.list(V.lev)) {
    section.term <- data.table(
      term=rep(sapply(lhs,function(x)as.character(x)[2]),
        times=sapply(V.lev,function(x)length(x))),
      section=unlist(lapply(V.lev,function(x)x)))
  }
  else {
    section.term <- data.table(
      term=rep(as.character(m1[[1]])[2],times=length(V.lev)),
      section=V.lev)
  }
  section.term$fun <- rep(call, nrow(section.term))

  ## expanded formula
  ## dQuote misbehaved on Linux - utf chars??
  at.form <- formula(paste("~", paste( paste("at(",cf,", ",paste0('"',section.term$section,'"'),"):",
                                             section.term$term),collapse="+")))
##  V <- vector(mode="list", length=V.len)
##  names(V) <- V.nam
##  if(is.list(V.lev)) {
##    for(ll in seq(1,length(V.lev))) {
##      V[[ll]] <- evalSpecials(lhs[[ll]],data,id2idv=FALSE)
##    }
##  }
##  else if(is.vector(V.lev)) { # only one formula allowed
##    for(ll in seq(1,length(V.lev))) {
##      V[[ll]] <- evalSpecials(lhs[[1]],data,id2idv=FALSE)
##    }
##      }

  ## some checks
  #dims <- sapply(V,function(x)length(x))
  #dnz <- dims[which(dims > 0)]
  ## base funs identical and/or all.equal seem spooked by data.table
  #if(sum(dnz-rep(dnz[1],length(dnz))) > 1e-5)
  #  stop("Unequal dimensions")
  ## set missing to id
  ##dz <- which(dims == 0)
  ##if(length(dz)) {
  ##  dn <- names(V[[which(dims > 0)[1]]])
  ##  model <- formula(paste("~",paste(paste("id(",dn,")",sep=""),collapse=":")))
  ##  for(i in names(V)[dz])
  ##    V[[i]] <- evalSpecials(model,data,id2idv=FALSE)
  ##}

  ##V

  out <- vector(mode="list",length=10)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial",
                  "Lab","Coords","Argv","isVariance","FacNam")

  # Fun
  out$Fun <- "dsum"

  # Call
  out$Call <- call

  # Obj
  out$Obj <- cf

  # Levels

  if(any(is.na(match(ds.lev,levels(data[[cf]])))))
    stop(paste("Not all levels specified in dsum() match those in",cf,"\n"))

  out$Lvls <- ds.lev

  # Initial & Con
  out$Initial <- as.numeric(NA)
  attr(out$Initial, "Tgamma") <- ""

  # Lab
  out$Lab <- ""

  #Coords
  out$Coords <- list()

  # Argv
  out$Argv <- c(unique(unlist(lapply(model.terms$Vars,function(x)x$Argv)))) #cf

  # isVariance
  out$isVariance <- FALSE

  out$FacNam <- out$Call

  ## attributes of "Call"
  attr(out$Call,"model.terms") <- model.terms
  attr(out$Call,"section.term") <- section.term
  attr(out$Call,"at.form") <- at.form
  attr(out$Call,"conditioning.factor") <- cf
  attr(out$Call,"outer") <- outer

  oldClass(out) <- "odw.special"

  out
}
#' User-defined variance models.
#'
#' Specify an external function that provides a variance matrix, or
#' its inverse.
#'
#' The \code{own} variance model allows users to specify external
#' variance structures. This requires the user to provide an \code{R}
#' function that accepts a single argument, the leading dimension of
#' the structure, and forms the variance matrix (or its inverse). The
#' \code{R} function may invoke compiled code if necessary.
#'
#' @param obj A factor in \code{data}.
#'
#' @param fun
#'
#' The name (as a character string) of an \code{R} function to compute
#' the variance matrix. This function must accept
#' a single argument:
#'
#' \describe{
#'
#' \item{order}{a scalar giving the dimension of the structure being
#' defined,}
#' }
#'
#' and return a matrix (the variance matrix, or its inverse). The
#' variance matrix may be a dense \code{matrix} class object, a vector
#' being the lower triangle in row major order, or a three column
#' matrix in coordinate form in row major order. This object may have
#' an attribute \code{INVERSE}, a logical scalar identifying the
#' structure as a variance matrices or its inverse; if \code{INVERSE}
#' is absent the default is \code{FALSE}.
#'
#' @param is.variance
#'
#' If \code{TRUE} (the default) then \code{odw} assumes the resulting
#' structure is a variance matrix, otherwise a correlation matrix is
#' assumed. This only affects the default scaling factor.
#'
#' @aliases own
#' @name own
#' @usage own(obj, fun = "myowng", is.variance = TRUE)
#'
odw_own <- function(obj, fun = "myowng", is.variance = TRUE, data) {
  ##
  ## R function myowng provides G
  ## args to fun are:
  ## 1. order of the structure (length(levels(obj)))
  ## 2. numeric vector of parameters, length k
  ## return: a matrix or vector
  ##

  out <- vector(mode="list",length=10)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial",
                  "Lab","Coords","Argv","isVariance","FacNam")
  ## Fun
  out$Fun <- "own"

  # Call
  out$Call <- spCall(sys.call())
  attr(out$Call, "OWN") <- fun

  # Obj
  obj <- as.character(substitute(obj))
  out$Obj <- obj
  out$FacNam <- out$Obj ## facnam

  dd <- data[[obj]]
  if(!is.factor(dd))
    stop(paste("Argument",obj,"to own() must be a factor\n"))

  # Levels

  out$Lvls <- levels(dd)

  # Initial & Con
  out$Initial <- as.numeric(NA)
  attr(out$Initial, "Tgamma") <- ""

  ## Lab
  out$Lab <- ""
  names(out$Phi) <- character()
  names(out$Gamma) <- character()

 #Coords
  out$Coords <- list()

  # Argv
  out$Argv <- fun

  # isVariance
  out$isVariance <- is.variance

  oldClass(out) <- "odw.special"
  out
}
## special functions

## May 2017: Lvls is a vector so no eval needed from C
#' Model term constructor functions.
#'
#' This class of special functions constructs model terms with specific
#' properties.
#'
#' @param obj An object in the data frame.
#' \describe{
#' \item{\code{grp}}{A component name from the \code{asreml()} \code{group}
#' list argument.}
#' }
#'
#' @aliases grp
#' @name modelFunctions
NULL
#' @describeIn modelFunctions Create a model term from covariates held
#' in columns of \code{data}.
#'
#' @usage grp(obj)
#'
odw_grp <- function(obj, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"dwreml.special"))
    stop("Argument to grp() must be a numeric or character vector\n")

  out <- vector(mode="list",length=10)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial",
                  "Lab","Coords","Argv","isVariance","FacNam")

  obj <- as.character(substitute(obj))
  ## Fun
  out$Fun <- "grp"
  ## Call
  out$Call <- spCall(sys.call()) ##obj
  ## Obj
  out$Obj <- obj
  out$FacNam <- out$Call

  ## Get component names from data
  what <- match(obj,names(attr(data,"GROUP")))
  if(is.na(what))
    stop(paste("Object",obj,"is not a component of the group argument"))
  which <- attr(data,"GROUP")[[obj]]

  ## Levels

  out$Lvls <- which #as.integer(length(which))

  ## Initial & Con
  out$Initial <- as.numeric(NA)
  attr(out$Initial, "Bound") <- character(0)

  ## Lab
  out$Lab <- ""

  ## Tgamma
  attr(out$Initial, "Tgamma") <- character(0)

  ## Coords
  out$Coords <- list()

  ## Argv
  out$Argv <- which

  ## isVariance
  out$isVariance <- FALSE

  oldClass(out) <- "dwreml.special"
  out
}

#' Conditional factors.
#'
#' Form a conditional covariable from \code{obj} for each level of
#' \code{obj} specified in the \code{lvls} argument.
#'
#' @param obj An object in the data frame.
#'
#' @param lvls Vector of levels of the conditioning factor
#'   (\code{obj}) that define the conditioning covariates formed by
#'   \code{at}. If numeric, \code{lvls} indexes the levels vector of
#'   \code{obj}; that is, \code{levels(obj)[lvls]}. If absent all
#'   levels are used.
#'
#' @aliases at
#' @name at
#' @usage at(obj,lvls)
#'
odw_at <- function(obj,lvls, data)
{
  if(mode(substitute(obj))=="call" && inherits(obj,"odw.special"))
    stop("Argument to at() must be a simple object (factor)\n")

  out <- vector(mode="list",length=10)
  names(out) <- c("Fun","Call","Obj","Lvls","Initial",
                  "Lab","Coords","Argv","isVariance","FacNam")

  # Fun
  out$Fun <- "at"

  # Call
  out$Call <- spCall(sys.call())

  # Obj
  obj <- as.character(substitute(obj))
  out$Obj <- obj


  dd <- data[[obj]]
  if(!is.factor(dd))
    stop(paste("Argument",obj,"to at() must be a factor\n"))

  # Levels
  if(missing(lvls))
    at.lev <- levels(dd)
  else {
    at.lev <- eval(lvls)
  }
  if(!is.vector(at.lev))
    stop("at() levels argument must be a simple vector.", call.=FALSE)
  #if(is.numeric(at.lev))
  #  at.lev <- levels(dd)[at.lev]

  if(is.numeric(at.lev)) {
    if(any(at.lev > length(levels(dd))))
      stop("at() level out of range")
    at.num <- at.lev
  }
  else {
    if(any(is.na(at.num <- match(at.lev,levels(dd)))))
      stop(paste("Not all levels specified in at() match those in",obj,"\n"))
  }

  out$Lvls <- at.num #at.lev in asreml
  ##attr(out$Lvls, "Levels") <- at.lev

  # Initial & Con
  out$Initial <- as.numeric(NA)
  names(out$Initial) <- ""
  attr(out$Initial, "Tgamma") <- ""

  # Lab
  out$Lab <- ""

  #Coords
  out$Coords <- list()

  # Argv
  out$Argv <- obj

  # isVariance
  out$isVariance <- FALSE

  facnam <- NULL
  if(is.numeric(at.lev)) {
    for(i in at.lev)
      facnam <- c(facnam, paste("at(",obj,", ",i,")",sep=""))
  }
  else {
    for(i in at.lev)
      facnam <- c(facnam, paste("at(",obj,", ",'"', i,'"',")",sep=""))
  }
  out$FacNam <- facnam

  oldClass(out) <- "odw.special"
  out
}
#' Identity variance models
#'
#' Model functions for identlty variance models.
#'
#' The class of identity models includes the \emph{null} correlation
#' model \code{id}, and its homogeneous and heterogeneous variance
#' forms (\code{idv} and \code{idh}).
#'
#' @param obj
#'
#' A factor in \code{data}.
#'
#' @param init
#'
#' Optional vector of initial values.
#'
#' @aliases id idv idh
#' @name identity
#' @usage id(obj)
#'
odw_id <- function(obj, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("id","cor","numeric(0)","numeric(0)",NA,obj,NA,data)
  out
}
#' @describeIn identity Identity variance model.
#'
#' @usage idv(obj, init=NA)
#'
odw_idv <- function(obj, init=NA,  data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("idv","cor","numeric(0)","0.1",NA,obj,init, data)
  out
}
#' @describeIn identity Heterogeneous identity (diagonal) variance
#' model.
#'
#' @usage idh(obj, init=NA)
#'
odw_idh <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("idh","cor","numeric(0)","rep(0.1,n)",NA,obj,init, data)
  out
}
#' Time series type variance models.
#'
#' Time series type correlation and variance models.
#'
#' The class of time series type models includes autoregressive models
#' of order 1 (\code{ar1}).
#'
#' @param obj
#'
#' A factor in \code{data}.
#'
#' @param init
#'
#' A vector of initial values (correlation parameters followed by
#' variance parameters.
#'
#' @aliases ar1 ar1v ar1h
#'
#' @name timeSeries
#' @usage ar1(obj, init=NA)
#'
odw_ar1 <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("ar1","cor",0.5,numeric(0),NA,obj,init, data)
  out
}
#' @describeIn timeSeries Autoregressive model of order 1;
#' homogeneous variance form.
#'
#' @usage ar1v(obj, init=NA)
#'
odw_ar1v <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("ar1v","cor",0.5,0.1,NA,obj,init, data)
  out
}
#' @describeIn timeSeries Autoregressive model of order 1;
#' heterogeneous variance form.
#'
#' @usage ar1h(obj, init=NA)
#'
odw_ar1h <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("ar1h","cor",0.5,"rep(0.1,n)",NA,obj,init, data)
  out
}
#' General structure variance models.
#'
#' General correlation and covariance models.
#'
#' The class of general variance models includes the simple, and
#' general correlation models (\code{cor}, and \code{corg}), the
#' diagonal, and unstructured variance models (\code{diag},
#' \code{us}).
#'
#' @param obj
#'
#' A factor in \code{data}.
#'
#' @param init
#'
#' A vector of initial values (correlation parameters followed by
#' variance parameters).
#'
#' @aliases cor corv corh corg corgv corgh diag us
#'
#' @name unstructured
#'
#' @usage cor(obj, init=NA)
#'
odw_cor <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("cor","cor",0.1,numeric(0),NA,obj,init, data)
  out
}
#' @describeIn unstructured Simple correlation model,
#' homogeneous variance form.
#'
#' @usage corv(obj, init=NA)
#'
odw_corv <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("corv","cor",0.1,0.1,NA,obj,init, data)
  out
}
#' @describeIn unstructured Simple correlation model,
#' heterogeneous variance form.
#'
#' @usage corh(obj, init=NA)
#'
odw_corh <- function(obj, init=NA,data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("corh","cor",0.1,"rep(0.1,n)",NA,obj,init, data)
  out
}
#' @describeIn unstructured General correlation model.
#'
#' @usage corg(obj, init=NA)
#'
odw_corg <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("corg","cor","matrix(0.1,nrow=n,ncol=n)",numeric(0),NA,obj,init,data)
  out
}
#' @describeIn unstructured General correlation model,
#' homogeneous variance form.
#'
#' @usage corgv(obj, init=NA)
#'
odw_corgv <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("corgv","cor","matrix(0.1,nrow=n,ncol=n)",0.1,NA,obj,init, data)
  N <- length(out$Lvls)*(length(out$Lvls)-1)/2
  out
}
#' @describeIn unstructured General correlation model,
#' heterogeneous variance form.
#'
#' @usage corgh(obj, init=NA)
#'
odw_corgh <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("corgh","cor","matrix(0.1,nrow=n,ncol=n)","rep(0.1,n)",
                    NA,obj,init, data)
  out
}
#' @describeIn unstructured Diagonal variance model.
#'
#' @usage diag(obj, init=NA)
#'
odw_diag <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("diag","var",numeric(0),"rep(0.1,n)",NA,obj,init, data)
  out
}
#' @describeIn unstructured Unstructured variance model.
#'
#' @usage us(obj, init=NA)
#'
odw_us <- function(obj, init=NA, data)
{
  if(!(mode(substitute(obj))=="call" && inherits(obj,"odw.special")))
    obj <- substitute(obj)
  out <- spc("us","var",numeric(0),"matrix(0.1,nrow=n,ncol=n)+diag(0.05,nrow=n)",
             NA,obj,init, data)
  out
}

## end of function list

matchCon <- function(init)
{
  what <- names(init)
  if(is.null(what))
    return(NULL)
  codes <- c('P','U','F')
  what <- casefold(what,upper=TRUE)
  which <- charmatch(what,codes)
  where <- is.na(which)
  if(all(where))
    return(NULL)
  else if(sum(as.numeric(where)) > 0)
    what[where] <- 'F'
  return(what)

}
iniCon <- function(x)
{
  n <- nchar(x)
  vec <- casefold(substring(x,1:n,1:n),upper=TRUE)
  where <- match(c("P","U","F"),vec)
  if(sum(!is.na(where)) == 0) {
    ## default to Fixed
    x <- paste(x,"F",sep="")
    where <- c(NA,NA,n+1)
  }
  if(sum(!is.na(where)) > 1)
    stop("Only one of 'P','U','F' may be specified in 'mtrn'")
  which <- where[!is.na(where)]
  value <- as.numeric(substring(x,1,which-1))
  constraint <- casefold(substring(x,which,which),upper=TRUE)
  list(value=value,constraint=constraint)
}
spCall <- function(sc)
{
  return(paste(my.dparse(recurse.del(sc)),collapse=""))
}
odw.levels <- function(x, Rcov = TRUE) {
  ## If levels of a factor are nested within at() sections
  ## Rstruc requires just the levels present in the given section
  ## rdflt and rlist call these special functions using data
  ## subsetted by at()
  ## Not called from gdflt or glist this way
  ##
  ## sort(unique()) may not be good enough
  ## TODO: check NA's
  if(length(Rcov)==0) Rcov <- FALSE
  if(Rcov) {
    full <- levels(x)
    present <- unique(x)
    ##return(full[sort(match(present,full))])
    return(full[match(present,full)])
  }
  else
    return(levels(x))
}
specials.df <- function() {
  ##Fun, Code (inter), Type, ObjArgs, Struc3, FunGroup
  ## ObjArgs could be used in modelFrame to get just the "variables"
  ##         in a call to a special function.
  ## FunGroup used to group into classes for initial value routines.
  spcls <- data.frame(matrix(c(
    "ide",-2,0,1,0,"ide",
    "vm",-2,1,1,-1,"vm",
    "ric",-2,1,1,-1,"ric",
    "tric",-2,1,1,-1,"tric",
    "at",-15,0,1,0,"at",
    "dsum",-98,0,1,0,"dsum",
    "grp",-99,0,0,0,"grp",
    "mbf",-24,0,0,0,"mbf",
    "xpr",-12,0,-1,0,"xpr",
    "id",0,1,1,0,"id",
    "idv",0,1,1,0,"idv",
    "idh",0,1,1,8,"diag",
    "ar1",0,1,1,1,"ar1",
    "ar1v",0,1,1,1,"corv",
    "ar1h",0,1,1,1,"corh",
    "cor",0,1,1,5,"cor",
    "corv",0,1,1,5,"corv",
    "corh",0,1,1,5,"corh",
    "corg",0,1,1,5,"corg",
    "corgv",0,1,1,5,"corgv",
    "corgh",0,1,1,5,"corgh",
    "diag",0,1,1,8,"diag",
    "us",0,1,1,9,"us",
    "str",-101,0,-1,0,"str",
    "own",0,1,1,1,"own"),byrow=TRUE,ncol=6),
                      stringsAsFactors=FALSE)
  names(spcls) <- c("Fun","Code","Type","ObjArgs","Struc3","FunGroup")
  row.names(spcls) <- spcls$Fun
  spcls$Struc3 <- as.numeric(spcls$Struc3)
  spcls$Code <- as.numeric(spcls$Code)
  spcls$Type <- as.numeric(spcls$Type)
  spcls$ObjArgs <- as.numeric(spcls$ObjArgs)

  invisible(spcls)
}
trimSpc <- function(tt) {
  fun <- attr(tt,"specials")
  which <- sapply(fun, function(x){!is.null(x)})
  if(any(which))
    attr(tt,"specials") <- fun[which]
  else
    attr(tt,"specials") <- list()
  return(tt)
}
## setdiff is (annoyingly) asymmetrical
symdiff <- function( x, y) { setdiff( union(x, y), intersect(x, y))}
my.dparse <- function(x) {
  return(paste(deparse(x, 500),collapse=""))
}
recurse.del <- function(expr)
{
  ## delete 'data' arg to a special function call
  stripExpr <- function(ee) {
    switch(mode(ee[[1]]),
           "call" = {
             if(is.element("data",names(ee[[1]])))
               ee[[1]]$data <- NULL
             if(is.element("init",names(ee[[1]])))
               ee[[1]]$init <- NULL
             ee[[1]][[1]] <- as.name(gsub("odw_","",ee[[1]][[1]]))
             if(length(ee[[1]]) > 1) {
               for(i in 2:length(ee[[1]])) {
                 ee[[1]][i] <-stripExpr(ee[[1]][i])
               }
             }
             ee
           },
           "numeric" = {
             ee
           },
           "name" = {
             ee
           },
           "character" = {
             ee
           },
           "logical" = {
             ee
           },
           ee
           )
    ee
  }

  stripCall <- function(cc) {
    switch(mode(cc),
           "call" = {
             if(is.element("data",names(cc)))
               cc$data <- NULL
             if(is.element("init",names(cc)))
               cc$init <- NULL
             cc[[1]] <- as.name(gsub("odw_","",cc[[1]]))
             if(length(cc) > 1) {
               for(i in 2:length(cc)) {
                 cc[[i]] <-stripCall(cc[[i]])
               }
             }
           }
           )
    cc
  }
  ## start here
  if(is.character(expr))
    expr <- parse(text=expr)
  if(is.expression(expr)) {
    expr <- stripExpr(expr)
    return(as.expression(expr[[1]]))
  }
  else if(is.call(expr)) {
    expr <- stripCall(expr)
    return(expr)
  }
  else
    stop("Argument to 'recurse.del' must be mode expression or call")

}
formOrder <- function(random, data, ran.order)
{
  Form <- function(r, keep.order=TRUE) {
    if(length(r[[2]]) == 0) {
      out <- ~NULL
    }
    else {
      out <- formula(paste("~",paste(attr(Terms(r,keep.order=keep.order),"term.labels"),
                                     collapse="+")))
    }
    if(length(out[[2]]) > 0) {
      tto <- Terms(out,keep.order=keep.order)

      if(!is.null(x <- attr(r,"str.group"))) {
        x <- x[base::order(match(names(x),attr(tto,"term.labels")))]
        attr(out,"str.group") <- x
      }
    }
    return(out)
  }
  rs.form <- Form(random)

  if(length(rs.form[[2]]) == 0)
    return(random)

  keep.order <- switch(ran.order,
                       user = TRUE,
                       R = FALSE,
                       stop("ran.order must be either 'user' or 'R'"))
  ## user (or noeff) order
  if(keep.order) return(rs.form)
  ## R default
  if(ran.order == "R")
    return(Form(rs.form, keep.order=FALSE))
}
R.sections <- function(mf) {

  ## no checks here - done in Rparam

  X <- attr(mf,"model.terms")$residual$Terms.obj
  V <- attr(mf,"model.terms")$residual$Var

  sect <- attr(X,"specials")$dsum

  if(length(sect) > 0) {
    outer <- attr(V[[1]]$Call,"outer")
    if(outer) {
      nsect <- 1
    }
    else {
      nsect <- nrow(rbindlist(lapply(V,function(x)attr(x$Call, "section.term"))))
    }
  }
  else {
    nsect <- 1
  }
  return(nsect)
}
R.unique <- function(mf, lhs, x, distbn) {
  ## len unique(mf[[x]]) if ISUV or ASMV
  ## len unique(trait) if ISMV or ASMN
  ## mf is the response matrix or vector
  if(x == "trait") {
    n <- length(lhs)
    if(n  > 1) {
      if(distbn[1] == 9)
        return(n-1)
      else
        return(n)
    }
    else
      return(length(unique(mf[[x]]))-1)
  }
  else
    return(length(unique(mf[[x]])))
}
Rparam <- function(mf)
{
  ## List of initial values for R(esidual) structures
  r2 <- function(sname, slevel, dimensions, ss) {
    one.sect <- ifelse(sname == slevel, TRUE, FALSE)
    L2 <- vector(mode="list",length=length(dimensions)+1)
    names(L2) <- c("variance",unlist(lapply(dimensions,function(x)x$Obj)))
    gam.name <- paste(unique(c(sname,slevel)),collapse="_")
    isVar <- 0
    size <- 1
    for(i in 1:length(dimensions)) {
      X <- dimensions[[i]]
      n <- names(L2)[i+1]
      iset <- attr(X$Initial, "set")
      L2[[n]]$facnam <- X$FacNam
      L2[[n]]$model <- X$Fun
      names(L2[[n]]$model) <- X$Obj
      L2[[n]]$levels <- X$Lvls
      L2[[n]]$uniq <- as.numeric(unique(ss[[X$Obj]]))
      ## Initial values
      L2[[n]]$initial <- X$Initial
      storage.mode(L2[[n]]$initial) <- "double"
      names(L2[[n]]$initial) <- {if(length(dimensions) > 0)
                                   paste(gam.name,X$Lab,sep="")
                                 else
                                   gam.name}
      size <- prod(size, length(L2[[n]]$uniq))
      isVar <- isVar + ifelse(is.na(X$isVariance),0,as.numeric(X$isVariance))
    }
    ## In odw "initial" is the scale factor
    ## "NA" flags if it is updatable via start.values
    ## reset to 1 in C if NA

    if(isVar) {
      L2$variance$size <- size
      L2$variance$model <- "id"
      L2$variance$initial <- as.double(NA)
      attr(L2$variance$initial, "Tgamma") <- ""
      attr(L2$variance$initial, "Bound") <- ""
     }
    else {
      L2$variance$size <- size
      L2$variance$model <- "idv"
      L2$variance$initial <- as.double(1.0)
      attr(L2$variance$initial, "Tgamma") <- "V"
      attr(L2$variance$initial, "Bound") <- ""
    }

    names(L2$variance$model) <- paste(sname,"!","scale",sep="")
    names(L2$variance$initial) <- paste(gam.name,"!R",sep="")

    L2
  }

  ## START -------------------------------->
  ## Suppress R CMD CHECK warning
  section <- NULL

  ##mm <- attr(mf,"traits")$mvar.method # asmv or multinomial

  X <- attr(mf,"model.terms")$residual$Terms.obj
  V <- attr(mf,"model.terms")$residual$Vars

  sect <- NULL
  cf <- NULL
  ## Check for dsum & validate
  if(any(sect <- attr(X,"specials")$at))
    stop("'at()' not allowed in residual model formula, replace with 'dsum'\n")
  sect <- attr(X,"specials")$dsum
  if(length(sect) > 0 && (length(sect) != length(attr(X, "term.labels"))))
    stop("Invalid 'residual' formula")
  if(length(sect) == 0 && (length(attr(X, "term.labels")) > 1))
    stop("Invalid 'residual' formula")

  if(length(sect) > 0) {
    outer <- attr(V[[1]]$Call,"outer")
    cf <- attr(V[[1]]$Call,"conditioning.factor")
    if(any(is.na(mf[[cf]])))
      stop("Missing values in section factor ",cf, call.=FALSE)
    if(outer) {
      nsect <- 1
      ndim <- length(dims <- attr(V[[1]]$Call,"model.terms")$Var[[1]]$Argv[1])
      uname <- sections <- paste(cf,dims,sep=":")
    }
    else {
      sname <- sapply(V,function(x)x$Obj) #Argv[1]
      if(length(uname <- unique(sname)) != 1)
        stop("Multiple conditioning factors ",uname," in 'residual' model")
      section.term <- rbindlist(lapply(V,function(x)attr(x$Call, "section.term")))
      ## All sections specified?
      nsect <- nrow(section.term)
      if(length(unique(section.term$section)) != nsect)
        stop("Residual model not specified for all sections")
      ndim <- unlist(lapply(V,function(x){
        apply(attr(attr(x$Call,"model.terms")$Terms.obj,"factors"),2,function(y)sum(y>0))}))
      dims <- lapply(V,function(x){attr(x$Call,"model.terms")$Vars})
      if(length(ndim <- unique(as.vector(ndim))) != 1)
        stop("Number of dimensions differ ",unique(nsect)," in 'residual' model")
    }
  }
  else {
    outer <- FALSE
    nsect <- 1
    uname <- sections <- paste(unlist(sapply(V,function(x)x$Obj)),collapse=":")
    ndim <- length(dims <- vapply(V[terms.variables(X)],function(x){x$Obj},character(1)))
  }

  ## Process in data (ie unique) order
  if(length(sect) > 0 && !outer)
    sections <- unique(mf[[uname]])

  Vlist <- vector(mode="list",length=nsect)
  names(Vlist) <- sections

  if(outer) {
    for(i in unique(mf[[cf]])) {
      ss <- subset(mf, mf[[cf]]==i, select=dims) # subset on data.table ok??
      if(is.unsorted(do.call(base::order,ss)))
        stop("Data not ordered ",dims," within ",cf,".")
    }
    Vlist[[sections]] <- r2(uname,uname,attr(V[[1]]$Call, "model.terms")$Vars,mf)
  }
  else if(length(sect) > 0) {
    for(i in sections) {
      ## section.term is a data.table - subset ok???
      st <- subset(section.term, section == i)
      dd <- unique(unlist(lapply(dims[st$fun], function(x){sapply(x,function(y)y$Obj)})))
      ## Check section sizes, and if sorted
      ss <- subset(mf, mf[[uname]]==i, select=dd)
      if((pp <- prod(unlist(lapply(ss[,dd,with=FALSE],function(x)length(unique(x)))))) != nrow(ss)) {
        stop("Section has ",nrow(ss),
             " observations but the residual model implies ",pp)
      }
      if(is.unsorted(do.call(base::order,ss[,dd,with=FALSE])))
        stop("Data order does not match that specified by the residual model formula.", call.=FALSE)
      ff <- st$fun
      tt <- st$term
      w <- which.variables(attr(V[[ff]]$Call, "model.terms")$Terms.obj,tt)
      Vlist[[i]] <- r2(uname,i,attr(V[[ff]]$Call, "model.terms")$Vars[w], ss)
    }
  }
  else {
    ## Check section size
    if((pp <- prod(sapply(mf[,dims,with=FALSE],function(x)length(unique(x))))) != nrow(mf)) {
      stop("Data has ",nrow(mf),
           " observations but the residual model implies ",pp)
    }
    if(is.unsorted(do.call(base::order,mf[,dims,with=FALSE])))
      stop("Data order does not match that specified by the residual model formula.", call.=FALSE)
    Vlist[[sections]] <- r2(uname,uname,V,mf)
  }
  new.names <- unlist(lapply(Vlist, function(x) {
    paste(sapply(x[2:length(x)], function(y){y$facnam}),collapse=":")}))
  if(is.null(cf)) cf <- "units"
  attr(Vlist, "conditioning.factor") <- cf
  Vlist
}
Gparam <- function(mf)
{
  ## List of initial values for G (random) structures
  ## Tgamma: 0 fixed, 1 variance, 2 ratio, 3 correlation, 4 covariance

  g2 <- function(term, dimensions, at.nam) {
    L2 <- vector(mode="list",length=length(dimensions)+1)
    names(L2) <- c("variance",unlist(lapply(dimensions,function(x)x$FacNam))) #Obj
    isVar <- 0

    if(length(dimensions) > 1) {
      vmide <- which(is.element(unlist(lapply(dimensions, function(x)x$Fun)), 'vm'))
      if(length(vmide) > 0) {
         if(sum(unlist(lapply(dimensions[-vmide], function(x)as.numeric(x$isVariance)))) == 0) {
           stop("Direct product with vm() must be a variance structure", call.=FALSE)
          }
       }
     }
    size <- 1
    for(i in 1:length(dimensions)) {
      X <- dimensions[[i]]
      n <- names(L2)[i+1]
      thisVar <- (!is.na(X$isVariance) && X$isVariance)
      L2[[n]]$facnam <- ifelse(is.null(at.nam),X$FacNam,paste(at.nam,X$FacNam,sep=":"))
      L2[[n]]$model <- X$Fun
      names(L2[[n]]$model) <- X$Obj
      L2[[n]]$levels <- X$Lvls
      L2[[n]]$initial <- X$Initial
      storage.mode(L2[[n]]$initial) <- "double"
      L2[[n]]$phi <- X$Phi
      L2[[n]]$gamma <- X$Gamma
      names(L2[[n]]$initial) <- paste(term, X$Lab,sep="") #paste(gam.name,X$Lab,sep="")
      isVar <- isVar + as.numeric(thisVar)
      size <- prod(size, length(L2[[n]]$levels))
    }
    ## As for R except default gamma (scale factor) is 0.1 for correlation models
    L2$variance$size = size
    if(isVar > 0) {
      L2$variance$model <- "id"
      L2$variance$initial <- as.double(NA)
      names(L2$variance$model) <- "scale"
      attr(L2$variance$initial, "Tgamma") <- ""
      attr(L2$variance$initial, "Bound") <- ""
    }
    else {
      L2$variance$model <- "idv"
      names(L2$variance$model) <- "scale"
      L2$variance$initial <- as.double(0.1)
      attr(L2$variance$initial, "Tgamma") <- "V"
      attr(L2$variance$initial, "Bound") <- ""
    }
    names(L2$variance$initial) <- term #gam.name
    L2
  }

  ## START -------------------------------->
  ## In odw "random" is an attribute of "mixed"
  if(is.null(RA <- attr(attr(mf,"model.terms")$mixed, "random")))
    return(NULL)
  X <- RA$Terms.obj
  V <- RA$Var

  scale <- 1.0
  ## Walk along the random formula (str() terms are preserved in random)
  tl <- attr(X,"term.labels")
  Glist <- list()
  for(z in seq(along=tl)) {
    ## trm.vars should match names(Var) for the duration
    ## replace with facnam
    trm.vars <- terms.variables(tl[z])
    ## special cases
    ##is.and <- sapply(V[trm.vars],function(x){x$Fun=="and"})
    ##trm.vars <- trm.vars[!is.and]
    if(length(trm.vars) == 0) next
    is.at <- sapply(V[trm.vars],function(x){x$Fun=="at"})
    if(sum(as.numeric(is.at)) > 1)
      stop("Multiple at() functions")
    is.str <- sapply(V[trm.vars],function(x){x$Fun=="str"})
    if(any(is.str)) {## should only be one str in a term
      str.lst <- lapply(V[trm.vars[is.str]],function(x)x$Call)[[1]]
    }
    trm.names <- do.call("cbind",lapply(V[trm.vars],function(x)x$FacNam))
    if(any(is.at)) {
      for(i in seq(1,nrow(trm.names))) {
        at.nam <- trm.names[i, is.at]
        if(any(is.str)) {
          Glist[[paste(trm.names[i,],collapse=":")]] <- g2(paste(trm.names[i,],collapse=":"),
                                       str.lst,at.nam)
        }
        else {
          trm.V <- dimnames(trm.names)[[2]][!is.at]
          VAT <- list()
          VAT[[1]] <- evalWithData(at.nam, data=mf, env=environment())
          VAT <- c(VAT, V[trm.V])
          Glist[[paste(trm.names[i,],collapse=":")]] <- g2(paste(trm.names[i, is.at],
                                                                 paste(trm.names[1,!is.at],collapse=":"),
                                                                 sep=":"),
                                                           VAT,NULL)

          #Glist[[paste(trm.names[i,],collapse=":")]] <- g2(paste(trm.names[i, is.at],
          #                             paste(trm.names[1,!is.at],collapse=":"),
          #                             sep=":"),
          #                             V[trm.V],at.nam) #trm.names[i,!is.at]
        }
      }
    }
    else if(any(is.str)) {
      if(length(trm.names) > 1) {
        Glist[[paste(trm.names, collapse=":")]] <- g2(paste(trm.names, collapse=":"),
                                                      c(V[trm.vars[!is.str]],str.lst),
                                                      paste(trm.names, collapse=":"))
      }
      else
        Glist[[trm.names]] <- g2(trm.names, str.lst, NULL)
    }
    else {
      Glist[[paste(trm.names,collapse=":")]] <- g2(paste(trm.names,collapse=":"),
                                                   V[trm.vars], NULL)
    }
  }
  Glist
}
updateV <- function(dflt, param, which) {
  rgupdt <- function(dflt, gammas) {
    ## Update G or R structure list from a vector of gammas
    ## dflt is either R.param or G.param

    if(length(dflt)==0)
      return(NULL)

    up <- lapply(dflt,function(x,gammas) {
      lapply(x,function(y,gammas) {
        tmp <- names(y$initial)
        tgam <- attr(y$initial, "Tgamma")
        #print(tmp)
        #print(tgam)
        ## Only update those that match!
        i <- match(tmp,names(gammas),nomatch=NA)
        ii <- !is.na(i)
        i <- i[ii]
        if(length(i) > 0 && !is.na(y$initial[1])) {
          z <- y$initial
          z[ii] <- gammas[i]
          y$initial <- switch(y$model,
                              ante = udu(z),
                              chol = ldl(z),
                              cholc = ldl(z),
                              id = y$initial,
                              z)
          names(y$initial) <- tmp
        }
        y
      },gammas)
    },gammas)
    up
  }

  ## If param is mode character then assume a filename:
  ##    csv file with header c("Component","Value","Constraint")
  ## If is.data.frame(param)
  ##    just call asreml.rupdt()
  ## If param is mode list:
  ##    Look for a component named "R/G.param"
  ##    If no component named "R/G.param" asume it is a R.param or G.param list object

  ## Match names and overwrite initial values of those parameters that match

  if(mode(param) == "character")
    param <- read.table(param,header=TRUE,sep=",",as.is=TRUE)
  if(is.data.frame(param)) {
    if(any(is.na(match(c('Component','Value'),names(param)))))
      stop(as.character(substitute(param)),
           " must have names 'Component','Value'")
    gammas <- param$Value
    names(gammas) <- param$Component
    return(rgupdt(dflt,gammas))
  }
  ## list form
  if(inherits(param, "odw")) {
    param <- param[[paste0(which,".param")]]
  }
  else if(is.list(param)) {
    if(!is.na(match(paste0(which,".param"),names(param))))
      param <- param[[paste0(which, ".param")]]
  }
  else
    stop(as.character(substitute(param)),"Invalid mode for intial values argument.")
  nt <- length(param)
  gammas <- numeric(0)
  for(n in seq(1,nt)) {
    nf <- length(param[[n]])
    for(j in 1:nf) {
      gammas <- c(gammas,param[[n]][[j]]$initial)
    }
  }
  ## don't update those with initial == NA
  not.id <- !is.na(gammas)
  gammas <- gammas[not.id]
  ## Capture "initial" for "variance" elements and update "gamma"
  rgu <- lapply(rgupdt(dflt,gammas), function(x){
    x[[1]]$gamma <- x[[1]]$initial
    x})
  return(rgu)
}
udu <- function(gammas)
{
  ## For ante:
  ## gammas is length n(n+1)/2 with ANTE solutions in the appropriate
  ## n(q+1)-q(q+1)/2 positions

  N <- length(gammas)
  which <- rep(1,N)
  which[grep("<NotEstimated>$",names(gammas))] <- 0
  if(sum(which) == N)
    return(gammas)
  n <- (sqrt(8*N+1)-1)/2
  n <- floor(n+0.5)
  q <- ((2*n-1)-sqrt((2*n+1)^2-8*length(gammas[which==1])))/2
  q <- floor(q+0.5)
  U <- D <- matrix(0,nrow=n,ncol=n)
  xx <- 0 <= (col(U)-row(U)) & (col(U)-row(U)) <= q
  U[xx] <- gammas[which==1]
  diag(D) <- diag(U)
  diag(U) <- 1
  V <- solve(U %*% D %*% t(U))
  V[!lower.tri(V)]
}
ldl <- function(gammas)
{
  ## For chol:
  ## gammas is length n(n+1)/2 with CHOL solutions in the appropriate
  ## n(q+1)-q(q+1)/2 positions
  ##

  N <- length(gammas)
  which <- rep(1,N)
  which[grep("<NotEstimated>$",names(gammas))] <- 0
  if(sum(which) == N)
    return(gammas)
  n <- (sqrt(8*N+1)-1)/2
  q <- ((2*n-1)-sqrt((2*n+1)^2-8*length(gammas[which==1])))/2
  L <- D <- matrix(0,nrow=n,ncol=n)
  xx <- 0 <= (row(L)-col(L)) & (row(L)-col(L)) <= q
  L[xx] <- gammas[which==1]
  diag(D) <- diag(L)
  diag(L) <- 1
  V <- L %*% D %*% t(L)
  V[!lower.tri(V)]
}
getLevels <- function(object) {
  ## function to return the levels of a model term from
  ##   an object of class "asr.special".
  ##   The Lvls component may be a function, vector, or expression.

  if(is.expression(object) || is.call(object))
    return(eval(object))

  if(is.element(mode(object), c("numeric","character","list")))
     return(object)

  if(mode(object)=="function")
    return(object())
}
where.env <- function(name, env = parent.frame()) {
  stopifnot(is.character(name), length(name) == 1)
  ##env <- to_env(env)
  if (identical(env, emptyenv())) {
    stop("Can't find ", name, call. = FALSE)
  }
  if (exists(name, env, inherits = FALSE)) {
    env
  }
  else {
    where.env(name, parent.env(env))
  }
}
#' Draw a design from a data frame
#'
#' Draws one or more two dimensional images of the design held in a
#' data frame.
#'
#' The rendering of an experimental plan is considered akin to a GIS
#' mapping exercise, where the thematic layers or point data
#' correspond to design features such as \emph{blocks}, \emph{rows},
#' \emph{columns} and \emph{treatment identifiers} etc. A spatial data
#' object of class \code{SpatialPolygonsDataFrame} from the \pkg{sp}
#' package is constructed from the \code{layout} argument, and images
#' of the design object rendered using the \pkg{ggplot2} graphics
#' library. The spatial object is optionally returned for more
#' detailed processing by \pkg{sp} methods.
#'
#' @param layout
#'
#' A formula specifying two terms that exist in \code{data} and
#' uniquely identify the experimental units.
#'
#' @param labels
#'
#' A model formula specifying the term(s) that label the experimental
#' units.
#'
#' @param theme
#'
#' An optional formula containing other factors to overlay on the
#' image. These layers are drawn in separate frames unless
#' \code{multi_page = FALSE}.
#'
#' @param subset
#'
#' A logical vector identifying the records of \code{data} to keep.
#'
#' @param spdf
#'
#' If \code{TRUE} (the default is \code{FALSE}), a Spatial data object
#' of class \code{SpatialPolygonsDataFrame} is returned for processing
#' by methods from the package \pkg{sp} or other GIS packages.
#'
#' @param multi_page
#'
#' If \code{TRUE}, additional themes are drawn in separate windows;
#' the default is \code{FALSE}.
#'
#' @param main
#'
#' A character string for the main title; the default is the name of
#' the data frame.
#'
#' @param data
#'
#' A data frame containing a design in the form used and returned by
#' \code{odw()}.
#'
#' @return
#'
#' An invisible list of \pkg{ggplot2} objects, or a
#' \code{SpatialPolygonsDataFrame} object if \code{spdf = TRUE}.
#'
plotData <- function(layout = ~Column+Row, labels = ~NULL, theme = ~NULL,
                     subset = logical(), spdf=FALSE, multi_page=FALSE,
                     main=character(), data=sys.parent())
{
  if(!requireNamespace("ggplot2", quietly=TRUE))
    stop("Requires package 'ggplot2'")
  if(length(grep("ggplot2", search())) == 0)
    attachNamespace("ggplot2")
  if(!requireNamespace("grid", quietly=TRUE))
    stop("Requires package 'grid'")
  if(!requireNamespace("sp", quietly=TRUE))
    stop("Requires package 'sp'")

  cxp <- odw.options()$cxp
  lxp <- odw.options()$lxp
  brk <- odw.options()$brk

  if(length(subset) == nrow(data))
    data <- data[subset,]

  ## some helpers
  ##
  ## Multiple plot function
  ##
  ## ggplot objects can be passed in ..., or to plotlist (as a list of ggplot objects)
  ## - cols:   Number of columns in layout
  ## - layout: A matrix specifying the layout. If present, 'cols' is ignored.
  ##
  ## If the layout is something like matrix(c(1,2,3,3), nrow=2, byrow=TRUE),
  ## then plot 1 will go in the upper left, 2 will go in the upper right, and
  ## 3 will go all the way across the bottom.
  ##
  multiplot <- function(..., plotlist=NULL, cols=1, layout=NULL) {
    requireNamespace("grid", quietly=FALSE)

    ## Make a list from the ... arguments and plotlist
    plots <- c(list(...), plotlist)

    numPlots = length(plots)

    ## If layout is NULL, then use 'cols' to determine layout
    if (is.null(layout)) {
      ## Make the panel
      ## ncol: Number of columns of plots
      ## nrow: Number of rows needed, calculated from # of cols
      layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                       ncol = cols, nrow = ceiling(numPlots/cols))
    }

    if (numPlots==1) {
      print(plots[[1]])

    } else {
      ## Set up the page
      grid::grid.newpage()
      grid::pushViewport(grid::viewport(layout = grid::grid.layout(nrow(layout), ncol(layout))))

      ## Make each plot, in the correct location
      for (i in 1:numPlots) {
        ## Get the i,j matrix positions of the regions that contain this subplot
        matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE), stringsAsFactors=TRUE)

        print(plots[[i]], vp = grid::viewport(layout.pos.row = matchidx$row,
                            layout.pos.col = matchidx$col))
      }
    }
  } ## end multiplot
  multipage <- function(plotlist) {
    print(plotlist[[1]])
    if(length(plotlist) > 1) {
      for(i in 2:length(plotlist)) {
        if(!is.null(plotlist[[i]])) {
          dev.new()
           print(plotlist[[i]])
        }
      }
    }
  }



  ## fn to get first arg of a function call
  ## ie, gets "site" from fa(site)
  target <- function(x) {
    ## x is the rhs of a formula object
    if(length(x)==1)
      return(x)
    if(length(x[[2]]) > 1)
      target(x[[2]])
    else
      return(x[[2]])
  }


  ## body

  cbfPal <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442",
              "#0072B2", "#D55E00", "#CC79A7")
  x <- y <- character(0)

  tt <- attr(terms(layout),"term.labels")
  x <- tt[1]
  if(length(tt) == 2) {
    y <- tt[2]
  }
  if(!length(y))
    stop("Layout specifies one dimension")

  if(any(!(is.element(c(x,y),names(data)))))
    stop("'layout' specifies columns not in 'design'")

  ## set up coords

  nx <- length(unique(data[[x]]))
  ny <- length(unique(data[[y]]))

  ## set up a SpatialPolygonsDataFrame
  xx <- paste0(x,".x")
  yy <- paste0(y,".y")
  xy <- data.frame(as.numeric(data[[x]]), as.numeric(data[[y]]))

  spoints <- sp::SpatialPointsDataFrame(xy, data, which(is.element(names(data), c(x,y))))
  polydf <- as(sp::SpatialPixelsDataFrame(spoints, spoints@data), "SpatialPolygonsDataFrame")
  if(spdf)
    return(polydf)

  ## getting the coords
  ggdata <- as.data.frame(do.call("rbind",
                                  sapply(polydf@polygons,function(z){
                                    lapply(z@Polygons,function(s)s@coords)})), stringsAsFactors=TRUE)
  names(ggdata) <- c(xx,yy)
  row.names(ggdata) <- seq(1, nrow(ggdata))
  ggdata$id <- rep(seq(1,nrow(polydf@data)), each=5)
  ggdata <- cbind(ggdata, polydf@data[ggdata$id,])
  ## centroids
  roids <- data.frame(x = sp::coordinates(polydf)[,1],
                      y = sp::coordinates(polydf)[,2], stringsAsFactors=TRUE)
  point_labs <- FALSE
  if(length(labels[[2]])) {
    ll <- unlist(lapply(dimnames(attr(terms(as.formula(labels)),"factors"))[[1]],
                        function(x){as.character(target(formula(paste("~",x))[[2]]))}))
    if(any(!is.element(ll, names(data))))
      stop("'labels' specifies columns not in 'data'")
    if(length(ll) > 1)
      labs <- do.call("paste", c(data[, ll], sep="|"))
    else
      labs <- data[[ll]]
    point_labs <- TRUE
  }

  if(length(theme[[2]])) {
    bb <- unlist(lapply(dimnames(attr(terms(theme),"factors"))[[1]],
                        function(x){as.character(target(formula(paste("~",x))[[2]]))}))
  }
  else
    bb <- character(0)

  if(length(bb)) {
    if(any(is.na(is.element(bb, names(data)))))
      stop("Elements of 'theme' not in 'data'.")

    for(i in bb) {
      data[[i]] <- as.factor(data[[i]])
    }
    ## colours needed
    mc <- unlist(lapply(data[bb], function(x){length(unique(x))}))
    mc[mc < length(cbfPal)] <- length(cbfPal)
  }
  else
    mc <- 1

  if(length(main) == 0)
    main <- as.character(match.call()$data)

  gg.list <- vector(mode="list", length=max(1,length(bb)-1)) # first theme goes on plot 1

  gg <- ggplot(data=ggdata, aes_string(x=xx, y=yy)) +
    xlab(x) + ylab(y) + ggtitle(main) +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
          plot.margin = unit(c(0.2,0.2,0.2,0.2), "cm"), panel.spacing = unit(0, "cm"),
          plot.title = element_text(size=rel(cxp)),
          axis.title.x = element_text(size=rel(cxp)),
          axis.title.y = element_text(size=rel(cxp)),
          axis.text.x = element_text(size=rel(cxp)),
          axis.text.y = element_text(size=rel(cxp)),
          legend.key.size = grid::unit(0.3,"cm"),
          legend.text=element_text(size=rel(cxp)),
          legend.title=element_text(size=rel(cxp))) +
    scale_x_continuous(limits=range(ggdata[[xx]]), expand=c(0,0),
                       breaks=seq(min(roids$x),max(roids$x),brk)) +
    scale_y_reverse(limits=rev(range(ggdata[[yy]])), expand=c(0,0),
                    breaks=seq(min(roids$y),max(roids$y),brk))

  ## base layer
  ramp <- colorRampPalette(cbfPal)(mc[1])
  if(length(bb) == 0) {
    gg.list[[1]] <- gg +
      geom_polygon(aes_string(group="id"), colour="white", fill=cbfPal[3], size=0.2)
  }
  else {
    gg.list[[1]] <- gg + scale_fill_manual(values=ramp) +
      geom_polygon(aes_string(group="id", fill=bb[1]), colour="white", size=0.2)
  }

  if(point_labs) {
    ## centroids
    roids$labs <- as.factor(labs)
    gg.list[[1]] <- gg.list[[1]] +
      geom_text(data=roids, aes(x=x, y=y, label=labs), show.legend=FALSE, size=rel(lxp))
  }
  if(length(bb) > 1) {
    ramp <- colorRampPalette(cbfPal)(max(mc[2:length(bb)]))
    for(i in 2:length(bb)) {
      gg.list[[i]] <- gg + scale_fill_manual(values=ramp)+scale_colour_manual(values=ramp) +
        geom_polygon(aes_string(group="id", fill=bb[i]), colour="grey90", size=0.1)

    }
  }

  if(multi_page)
    multipage(plotlist=gg.list)
  else
    multiplot(plotlist=gg.list, cols=ceiling(sqrt(max(1,length(bb)-1))))

  return(invisible(gg.list))

}
#' Plot an odw object
#'
#' Draws one or more two dimensional images of the design component of
#' an \code{odw} object.
#'
#' The rendering of an experimental plan is considered akin to a GIS
#' mapping exercise, where the thematic layers or point data
#' correspond to design features such as \emph{blocks}, \emph{rows},
#' \emph{columns} and \emph{treatment identifiers} etc. A spatial data
#' object of class \code{SpatialPolygonsDataFrame} from the \pkg{sp}
#' package is constructed from the layout information in the
#' \code{residual} formula or \code{layout} argument, and images of
#' the design object rendered using the \pkg{ggplot2} graphics
#' library. The spatial object is optionally returned for more
#' detailed processing by \pkg{sp} methods.
#'
#' @param object
#'
#' An \code{odw} object.
#'
#' @param layout
#'
#' A formula specifying two terms that uniquely identify the
#' experimental units. If \code{~NULL} (the default) the
#' \code{R.param} list is used, otherwise a formula object of the form
#' \code{\~x+y} must be given, where \code{x} and \code{y} are columns
#' in the design data frame component of the object.
#'
#' @param labels
#'
#' A model formula specifying the term(s) that label the experimental
#' units. The default is to use the term to the left of \code{"|"} in
#' the \code{permute} formula, otherwise a formula of the form
#' \code{~a+b+...} can be given, where \code{a} etc nominate columns
#' in the design component of the object. If more than one label is
#' specified they are concatenated and separated with \code{"|"}.
#'
#' @param theme
#'
#' An optional formula containing other factors to overlay on the
#' image. These layers are drawn in separate frames unless
#' \code{multi_page = FALSE}.
#'
#' @param section
#'
#' If the residual formula defines a multi-section model,
#' \code{section} is a numeric scalar that selects which design to
#' display; the default is \code{section = 1}.
#'
#' @param spdf
#'
#' If \code{TRUE} (the default is \code{FALSE}), a Spatial data object
#' of class \code{SpatialPolygonsDataFrame} is returned for processing
#' by methods from the package \pkg{sp} or other GIS packages.
#'
#' @param final
#'
#' If \code{TRUE} (default) the final permuted design is drawn,
#' otherwise the labels are drawn in their original order using
#' (reversing) the \code{permute} component of the object.
#'
#' @param multi_page
#'
#' If \code{TRUE} additional themes are drawn in separate windows; the
#' default is \code{FALSE}.
#'
#' @return
#'
#' An invisible list of \pkg{ggplot2} objects, or a
#' \code{SpatialPolygonsDataFrame} object if \code{spdf = TRUE}.
#'
#' @method plot odw
#' @aliases plot
#'
#' @export
#'
plot.odw <- function(object, layout = ~NULL, labels=object$call$permute,
                    theme = ~NULL, section = 1, spdf = FALSE, final = TRUE,
                    multi_page = FALSE)
{
  if(!inherits(object,"odw"))
    stop("Object not of class 'odw'")

  if(!requireNamespace("ggplot2", quietly=TRUE))
    stop("Requires package 'ggplot2'")
  if(length(grep("ggplot2", search())) == 0)
    attachNamespace("ggplot2")
  if(!requireNamespace("grid", quietly=TRUE))
    stop("Requires package 'grid'")
  if(!requireNamespace("sp", quietly=TRUE))
    stop("Requires package 'sp'")

  cxp <- odw.options()$cxp
  lxp <- odw.options()$lxp
  brk <- odw.options()$brk

  cf <- character()
  if(length(object$R.param) > 1) {
    cf <- attr(object$R.param, "conditioning.factor")
    if(section > length(object$R.param))
      stop("section cannot be greater than ", length(object$R.param))
    rparam <- object$R.param[section]
    data <- object$design[object$design[[cf]] == names(object$R.param)[section],]
    title <- paste(cf, names(object$R.param)[section])
  } else {
    data <- object$design
    rparam <- object$R.param
    title <- as.character(match.call()$data)
  }

  ## some helpers

  ##
  ## Multiple plot function
  ##
  ## ggplot objects can be passed in ..., or to plotlist (as a list of ggplot objects)
  ## - cols:   Number of columns in layout
  ## - layout: A matrix specifying the layout. If present, 'cols' is ignored.
  ##
  ## If the layout is something like matrix(c(1,2,3,3), nrow=2, byrow=TRUE),
  ## then plot 1 will go in the upper left, 2 will go in the upper right, and
  ## 3 will go all the way across the bottom.
  ##
  multiplot <- function(..., plotlist=NULL, cols=1, layout=NULL) {
    requireNamespace("grid", quietly=FALSE)

    ## Make a list from the ... arguments and plotlist
    plots <- c(list(...), plotlist)

    numPlots = length(plots)

    ## If layout is NULL, then use 'cols' to determine layout
    if (is.null(layout)) {
      ## Make the panel
      ## ncol: Number of columns of plots
      ## nrow: Number of rows needed, calculated from # of cols
      layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                       ncol = cols, nrow = ceiling(numPlots/cols))
    }

    if (numPlots==1) {
      print(plots[[1]])

    } else {
      ## Set up the page
      grid::grid.newpage()
      grid::pushViewport(grid::viewport(layout = grid::grid.layout(nrow(layout), ncol(layout))))

      ## Make each plot, in the correct location
      for (i in 1:numPlots) {
        ## Get the i,j matrix positions of the regions that contain this subplot
        matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE), stringsAsFactors=TRUE)

        print(plots[[i]], vp = grid::viewport(layout.pos.row = matchidx$row,
                            layout.pos.col = matchidx$col))
      }
    }
  } ## end multiplot
  multipage <- function(plotlist) {
    print(plotlist[[1]])
    if(length(plotlist) > 1) {
      for(i in 2:length(plotlist)) {
        if(!is.null(plotlist[[i]])) {
          dev.new()
          print(plotlist[[i]])
        }
      }
    }
  }

  ## fn to get first arg of a function call
  ## ie, gets "site" from fa(site)
  target <- function(x) {
    ## x is the rhs of a formula object
    if(length(x)==1)
      return(x)
    if(length(x[[2]]) > 1)
      target(x[[2]])
    else
      return(x[[2]])
  }

  ## function body
  cbfPal <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442",
              "#0072B2", "#D55E00", "#CC79A7")
  x <- y <- character(0)

  ## get layout from R.param
  if(length(layout[[2]]) == 0) { #use R.param
    dims <- names(rparam[[1]])[-1]
    if(length(dims) > 2) stop("Cannot plot in ",length(dims), " dimensions")
    x <- dims[1]
    if(length(dims) == 2) {
      y <- dims[2]
    }
  }
  else {
    tt <- attr(terms(layout),"term.labels")
    x <- tt[1]
    if(length(tt) == 2) {
      y <- dims[2]
    }
  }
  if(!length(y))
      stop("Layout specifies one dimension")

  if(any(!(is.element(c(x,y),names(data)))))
    stop("'layout' specifies columns not in 'design'")

  nx <- length(unique(data[[x]]))
  ny <- length(unique(data[[y]]))

  ## set up a SpatialPolygonsDataFrame
  xx <- paste0(x,".x")
  yy <- paste0(y,".y")
  xy <- data.frame(as.numeric(data[[x]]), as.numeric(data[[y]]))

  spoints <- sp::SpatialPointsDataFrame(xy, data, which(is.element(names(data), c(x,y))))
  polydf <- as(sp::SpatialPixelsDataFrame(spoints, spoints@data), "SpatialPolygonsDataFrame")
  if(spdf)
    return(polydf)

  ## getting the coords
  ggdata <- as.data.frame(do.call("rbind",
                                  sapply(polydf@polygons,function(z){
                                    lapply(z@Polygons,function(s)s@coords)})), stringsAsFactors=TRUE)
  names(ggdata) <- c(xx,yy)
  row.names(ggdata) <- seq(1, nrow(ggdata))
  ggdata$id <- rep(seq(1,nrow(polydf@data)), each=5)
  ggdata <- cbind(ggdata, polydf@data[ggdata$id,])
  ## centroids
  roids <- data.frame(x = sp::coordinates(polydf)[,1],
                      y = sp::coordinates(polydf)[,2], stringsAsFactors=TRUE)
  point_labs <- FALSE
  if(length(labels[[2]])) {
    ll <- unlist(lapply(dimnames(attr(terms(as.formula(labels)),"factors"))[[1]],
                        function(x){as.character(target(formula(paste("~",x))[[2]]))}))
    if(any(!is.element(ll, names(data))))
      stop("'labels' specifies elements not in 'data'.")
    if(length(ll) > 1)
      labs <- do.call("paste", c(polydf@data[, ll], sep="|"))
    else
      labs <- data[[ll]]
    point_labs <- TRUE
  }

  if(length(theme[[2]])) {
    bb <- unlist(lapply(dimnames(attr(terms(theme),"factors"))[[1]],
                        function(x){as.character(target(formula(paste("~",x))[[2]]))}))
  }
  else
    bb <- character(0)

  if(length(bb)) {
    if(any(is.na(is.element(bb, names(data)))))
      stop("Elements of 'theme' not in 'data'.")

    for(i in bb) {
      data[[i]] <- as.factor(data[[i]])
    }
    ## colours needed
    mc <- unlist(lapply(data[bb], function(x){length(unique(x))}))
    mc[mc < length(cbfPal)] <- length(cbfPal)
  }
  else
    mc <- 1

  gg.list <- vector(mode="list", length=max(1,length(bb)-1)) # first theme goes on plot 1

  gg <- ggplot(data=ggdata, aes_string(x=xx, y=yy)) +
    xlab(x) + ylab(y) + ggtitle(title) +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
          plot.margin = grid::unit(c(0.2,0.2,0.2,0.2), "cm"),
          panel.spacing = grid::unit(0, "cm"),
          plot.title = element_text(size=rel(cxp)),
          axis.title.x = element_text(size=rel(cxp)),
          axis.title.y = element_text(size=rel(cxp)),
          axis.text.x = element_text(size=rel(cxp)),
          axis.text.y = element_text(size=rel(cxp)),
          legend.key.size = grid::unit(0.3,"cm"),
          legend.text=element_text(size=rel(cxp)),
          legend.title=element_text(size=rel(cxp))) +
    scale_x_continuous(limits=range(ggdata[[xx]]), expand=c(0,0),
                       breaks=seq(min(roids$x),max(roids$x),brk)) +
    scale_y_reverse(limits=rev(range(ggdata[[yy]])), expand=c(0,0),
                    breaks=seq(min(roids$y),max(roids$y),brk))
  ## base layer
  ramp <- colorRampPalette(cbfPal)(mc[1])
  if(length(bb) == 0) {
    gg.list[[1]] <- gg +
      geom_polygon(aes_string(group="id"), colour="white", fill=cbfPal[3], size=0.2)
  }
  else {
    gg.list[[1]] <- gg + scale_fill_manual(values=ramp) +
      geom_polygon(aes_string(group="id", fill=bb[1]), colour="white", size=0.2)
  }
  if(point_labs) {
    ## centroids
    roids$labs <- as.factor(labs)
    gg.list[[1]] <- gg.list[[1]] +
      geom_text(data=roids, aes(x=x, y=y, label=labs), show.legend=FALSE, size=rel(lxp))
  }
  if(length(bb) > 1) {
    ramp <- colorRampPalette(cbfPal)(max(mc[2:length(bb)]))
    for(i in 2:length(bb)) {
      gg.list[[i]] <- gg + scale_fill_manual(values=ramp)+scale_colour_manual(values=ramp) +
        geom_polygon(aes_string(group="id", fill=bb[i]), colour="grey90", size=0.1)

    }
  }

  if(multi_page)
    multipage(plotlist=gg.list)
  else
    multiplot(plotlist=gg.list, cols=ceiling(sqrt(max(1,length(bb)-1))))

  return(invisible(gg.list))
}
#' Summarise an odw object.
#'
#' Summary method for objects of class \pkg{odw}.
#'
#' If the \code{residual} formula specifies a multi-dimensional
#' structure, the dimensions are added to the vector of design factors
#' extracted from the \code{fixed} and \code{random} formulae used in
#' constructing the tables.
#'
#' @param object
#'
#' An object of class \pkg{odw}, usually a result of a call to
#' \code{odw}.
#'
#' @param incidence
#'
#' If \code{TRUE} (the default), an incidence matrix is formed for the
#' objective (\code{permute}) term with respect to each potential
#' design factor in the model.
#'
#' @param concurrence
#'
#' If \code{TRUE} (the default), a concurrence matrix is formed for
#' the objective (\code{permute}) term with respect to each potential
#' design factor in the model.
#'
#' @return
#'
#' A list with the following components:
#'
#' \describe{
#'
#'  \item{criterion}{
#'    the value of the design criterion at termination.
#'  }
#'
#'  \item{is.binary}{
#'    a list of logical scalars, one for each factor in the model. If
#'    \code{TRUE}, the objective factor is binary with respect to the
#'    particular model term.
#'  }
#'
#'  \item{incidence}{
#'    a list of incidence matrices, one for each factor in the model. Each
#'    matrix is a \eqn{v \times m} array of occurrence counts, where there
#'    are \eqn{v} levels in the factor being permuted, and \eqn{m} levels
#'    in the \emph{incidence} factor.
#'  }
#'
#'  \item{concurrence}{
#'    a list of concurrence matrices, one for each factor in the
#'    model. Each matrix is a \eqn{v \times v} array of pairwise treatment
#'    concurrences for the particular model term.
#'  }
#'}
#'
#' @method summary odw
#' @aliases summary
#'
summary.odw <- function(object, incidence=TRUE, concurrence=TRUE)
{
  if(!inherits(object,"odw"))
    stop("Object not of class 'odw'")
  ## some helpers

  ## fn to get first arg of a function call
  ## ie, gets "site" from fa(site)
  target <- function(x) {
    ## x is the rhs of a formula object
    if(length(x)==1)
      return(x)
    if(length(x[[2]]) > 1)
      target(x[[2]])
    else
      return(x[[2]])
  }

  i.list <- c.list <- is.binary <- list()
  ## incidence matrices first

  if(is.null(object$call$fixed))
    ff <- ~NULL
  else
    ff <- as.formula(object$call$fixed)
  if(is.null(object$call$random))
    rr <- ~NULL
  else
    rr <- as.formula(object$call$random)

  ttres <- NULL
  if(length(object$R.param[[1]]) > 2) #variance is 1
    ttres <- names(object$R.param[[1]])[-1]
  if(length(object$R.param) > 1)
    ttres <- c(ttres, attr(object$R.param, "conditioning.factor"))

  ttp <- unlist(lapply(dimnames(attr(terms(as.formula(object$call$permute)),
                                     "factors"))[[1]],
                       function(x){as.character(target(formula(paste("~",x))[[2]]))}))

  if(length(ttp)>1)
    stop("Too many permute terms")

  ttr <- unique(c(unlist(lapply(dimnames(attr(terms(ff),
                                              "factors"))[[1]],
                                function(x){as.character(target(formula(paste("~",x))[[2]]))})),
                  unlist(lapply(dimnames(attr(terms(rr),
                                              "factors"))[[1]],
                                function(x){as.character(target(formula(paste("~",x))[[2]]))})),
                  ttres))

  if(is.element(ttp,ttr))
    ttr <- ttr[-match(ttp,ttr)]

  ttp <- all.vars(parse(text=ttp))
  ## ttp may be a vector

  if(length(ttp) > 1)
    nn <- apply(expand.grid(ttp,ttr),1,function(z)paste(z,collapse="."))
  else
    nn <- ttr

  if(incidence) {
    i.list <- vector(mode="list",length=length(ttp)*length(ttr))
    names(i.list) <- nn
    for(i in seq(along=ttr)) {
      for(j in seq(along=ttp))
        i.list[[(i-1)*length(ttp)+j]] <- table(object$design[[ttp[j]]],object$design[[ttr[i]]])
    }
    is.binary <- vector(mode="list",length=length(ttp)*length(ttr))
    names(is.binary) <- nn
    for(i in seq(along=ttr)) {
      for(j in seq(along=ttp))
        is.binary[[(i-1)*length(ttp)+j]] <- !any(i.list[[(i-1)*length(ttp)+j]] > 1)
    }
  }
  if(concurrence) {
    c.list <- vector(mode="list",length=length(ttp)*length(ttr))
    names(c.list) <- nn
    for(i in seq(along=ttr)) {
      for(j in seq(along=ttp))
        c.list[[(i-1)*length(ttp)+j]] <- i.list[[(i-1)*length(ttp)+j]] %*%
          t(i.list[[(i-1)*length(ttp)+j]])
    }
  }

  out <- list()
  out$criterion <- object$criterion
  out$incidence <- i.list
  out$is.binary <- is.binary
  out$concurrence <- c.list
  out
}
#' Update an odw model.
#'
#' Extract and evaluate the \code{call} from the \code{odw} object,
#' replacing any arguments with changed values. 
#'
#' In addition to any other changes, \code{update.odw} replaces the
#' argument \code{data} with
#' \code{object\$design},
#' creating a new odw object using the design
#' from a previous search.
#'
#' @param object
#'
#' A valid \code{odw} object with a \code{call} component, the
#' expression used to create itself.
#'
#' @param fixed.
#'
#' Changes to the fixed formula. This is a one sided formula where
#' \code{"."} is substituted for existing components in the
#' \code{fixed} component of \code{object$call}.
#'
#' @param random.
#'
#' Changes to the random formula. This is a one sided formula where
#' \code{"."} is substituted for existing components in the right hand
#' side of the \code{random} component of \code{object$call}.
#'
#' @param permute.
#'
#' Changes to the permute formula. This is a one sided formula where
#' \code{"."} is substituted for existing components in the right hand
#' side of the \code{permute} component of \code{object$call}.
#'
#' @param swap.
#'
#' Changes to the swap formula.
#'
#' @param residual.
#'
#' Changes to the residual formula. This is a one sided formula where
#' \code{"."} is substituted for existing components in the right hand
#' side of the \code{residual} component of \code{object$call}.
#'
#' @param \dots
#'
#' Additional arguments to the call, or arguments with changed values.
#'
#' @return
#'
#' A new updated \code{odw} object.
#'
#' @method update odw
#' @aliases update
#'
update.odw <- function(object, fixed., random., permute., swap., residual., ...)
{
  my.update.formula <- function(old, new, keep.order=TRUE, ...) {
    env <- environment(as.formula(old))
    ## Package "stats"
    tmp <- .Call(stats:::C_updateform, as.formula(old), as.formula(new))
    out <- formula(terms.formula(tmp, simplify = TRUE, keep.order=keep.order))
    environment(out) <- env
    return(out)
  }
  ## UPDATE.odw
  if(is.null(newcall <- object$call) && is.null(newcall <- attr(object,"call")))
    stop("need an object with call component or attribute")

  tempcall <- list(...)

  ## formulae may be in variables
  if(length(newcall$fixed)) newcall$fixed <- eval(newcall$fixed, parent.frame())
  if(length(newcall$random)) newcall$random <- eval(newcall$random, parent.frame())
  if(length(newcall$permute)) newcall$permute <- eval(newcall$permute, parent.frame())
  if(length(newcall$swap)) newcall$swap <- eval(newcall$swap, parent.frame())
  if(length(newcall$residual)) newcall$residual <- eval(newcall$residual, parent.frame())

  if(!missing(fixed.))
    newcall$fixed <- my.update.formula(as.formula(newcall$fixed), fixed., keep.order=TRUE)
  if(!missing(random.))
    newcall$random <- {if(length(newcall$random))
                         my.update.formula(as.formula(newcall$random), random.,
                                           keep.order=TRUE)
                       else
                         random.}
  if(!missing(permute.))
    newcall$permute <- {if(length(newcall$permute))
                         my.update.formula(as.formula(newcall$permute), permute.,
                                           keep.order=TRUE)
                       else
                         permute.}
  if(!missing(swap.))
    newcall$swap <- {if(length(newcall$swap))
                         my.update.formula(as.formula(newcall$swap), swap.,
                                           keep.order=TRUE)
                       else
                         swap.}

  if(!missing(residual.))
    newcall$residual <- {if(length(newcall$residual))
                       my.update.formula(as.formula(newcall$residual), residual., keep.order=TRUE)
                     else
                       residual.}

  if(length(tempcall)) {
    what <- !is.na(match(names(tempcall), names(newcall)))
    for (z in names(tempcall)[what]) newcall[[z]] <- tempcall[[z]]
    if (any(!what)) {
      newcall <- c(as.list(newcall), tempcall[!what])
      newcall <- as.call(newcall)
    }
  }

  ## Don't want any of these with an intercept only
  if(length(newcall$random) && length(attr(Terms(as.formula(newcall$random)),"factors"))==0)
    newcall$random <- NULL
    if(length(newcall$permute) && length(attr(Terms(as.formula(newcall$permute)),"factors"))==0)
    newcall$permute <- NULL
    if(length(newcall$swap) && length(attr(Terms(as.formula(newcall$swap)),"factors"))==0)
    newcall$swap <- NULL
    if(length(newcall$residual) && length(attr(Terms(as.formula(newcall$residual)),"factors"))==0)
    newcall$residual <- NULL

  newcall$data <- call("$",as.name(deparse(substitute(object))),"design")
  eval(newcall, sys.parent())
}

mat2sparse <- function(X)
{
  which <- (X!=0 & lower.tri(X,diag=TRUE))
  A <- matrix(c(t(row(X))[t(which)],
                   t(col(X))[t(which)],
                 t(X)[t(which)]), ncol=3)
  dimnames(A) <- list(NULL, c('row','col','val'))


  attr(A, 'rowNames') <- dimnames(X)[[1]]
  if(inherits(X, "ginv")) {
    class(A) <- c(class(A), "ginv")
    attr(A,"INVERSE") <- TRUE
    for(i in c("inbreeding","logdet","geneticGroups"))
      attr(A,i) <- attr(X,i)
  }
  else {
    attr(A, 'INVERSE') <- attr(X, 'INVERSE')
  }
  A
}
sparse2mat <- function(x)
{
  ## sparse form is 3 col matrix or dataframe
  ## row,col,value

  nrow <- max(x[,1])
  y <- rep(0,nrow * nrow)
  y[(x[,2]-1)*nrow+x[,1]] <- x[,3]
  y[(x[,1]-1)*nrow+x[,2]] <- x[,3]
  A <- matrix(y, nrow=nrow, ncol=nrow, byrow=FALSE)

  if(inherits(x, "ginv")) {
    dimnames(A) <- list(attr(x, "rowNames"), attr(x, "rowNames"))
    class(A) <- c(class(A), "ginv")
    attr(A,"INVERSE") <- TRUE
    for(i in c("inbreeding","logdet","geneticGroups"))
      attr(A,i) <- attr(x,i)
  }
  else {
    att <- c("rowNames", "INVERSE")
    w <- which(is.element(att, names(attributes(x))))
    if(length(w) > 0) {
      for(i in w) {
        if(i == 1)
          dimnames(A) <- list(attr(x, "rowNames"), attr(x, "rowNames"))
        else
          attr(A, att[i]) <- attr(x, att[i])
      }
    }
  }
  return(A)
}
giv.internal <- function(optimize, permute, data) {
  ## From permute we get the base factor and giv file via vm or ric
  ## From optimize we get the action to take
  ## From data we get the vector of levels in the dataframe.

  ## 1. get lhs of permute
  ## 2. check for vm/ric
  ## 3. get arguments

  if(length(optimize) == 1 && optimize == "ginv") {
    return(invisible())
  }

  pp <- fpipe(permute)[[1]]
  pp <- trimSpc(Terms(pp, keep.order=TRUE))
  if(!any(is.element(c("vm", "ric", "tric"), names(attr(pp, "specials"))))) {
    return(invisible())
  }
  args <- all.vars(attr(pp,"variables")[[2]])
  ## assume 1 is obj and 2 is giv
  giv.env <- where.env(args[2])
  giv <- get(args[2], envir=giv.env)

  ## what have we?
  if(inherits(giv, "ginv")) {
    rn <- attr(giv, "rowNames")
  } else if(is.matrix(giv)) {
    if(ncol(giv) == 3) {
      rn <- attr(giv, "rowNames")
    } else {
      rn <- dimnames(giv)[[1]]
    }
  }
  if(is.null(rn)) {
    stop("No rowNames or dimnames found for ",giv)
  }
  if(length(optimize) == 1) {
    if(optimize == "data") {
      inAval <- is.element(rn, data[[ args[1] ]])
    } else {
      stop("optimize must be one of 'data' or 'ginv'")
    }
  } else {
    inAval <- is.element(rn, as.character(optimize))
  }
  idx <- rep(0, length(inAval))
  neqA <- sum(inAval)
  idx[1:neqA] <- which(inAval)
  if(sum(as.numeric(!inAval)) > 0) {
    idx[seq(neqA+1, length(inAval))] <- which(!inAval)
  }
  if(!is.unsorted(idx)) {
    message(args[2]," already ordered.")
    return(invisible())
  } else {
    message("Saving ",paste0(args[2],".copy"))
    assign(paste0(args[2],".copy"), giv, giv.env)
  }
  if(inherits(giv, "ginv") || ncol(giv) == 3) {
    ## too hard
    ##exch <- vector(length=length(rn))
    ##i <- seq(1,length(rn))
    ##exch[idx[i]] <- i
    atr <- attributes(giv)
    giv <- sparse2mat(giv)[idx,idx]
    dimnames(giv) <- list(rn[idx],rn[idx])
    attr(giv, "INVERSE") <- atr$INVERSE
    attr(giv, "inbreeding") <- atr$inbreeding
    attr(giv, "logdet") <- atr$logdet
    attr(giv, "geneticGroups") <- atr$geneticGroups
    class(giv) <- c(class(giv), "ginv")
    giv <- mat2sparse(giv)
  } else {
    atr <- attributes(giv)
    giv <- giv[idx,idx]
    attr(giv, "INVERSE") <- atr$INVERSE
  }
  message("Overwriting ",args[2])
  assign(args[2], giv, giv.env)
  invisible()
}
#' Bipartite graph of a design
#'
#' Forms an incidence matrix from the nominated factors and represents 
#' the design in a graph
#'
#' Uses the \code{igraph} package to create and render the graph
#'
#' @param ...
#'
#' Exactly two character strings identifying the classifying factors
#'
#' @param title
#'
#' Optional title for the graph. If not set a title is created
#' from the classifying strings
#'
#' @param data
#'
#' A data frame in which to resolve the classifying factors
#'
#' @examples
#'
#' \dontrun{
#' # From Godolphin (2004), Applied Statistics, 53, 133-147
#' rc <- data.frame(Block = factor(rep(1:2, each=9)),
#'                  Row = factor(rep(1:3,6)),
#'                  Column = factor(rep(1:6, each=3)),
#'                  Treat = factor(c(1,4,7,2,5,8,3,6,9,9,8,3,6,5,4,7,2,1)))
#' is.connected("Treat", "Row", data=rc)
#' }
#'
is.connected <- function(..., title="", data=sys.parent()) {

  if(!requireNamespace("igraph", quietly=TRUE)) {
    stop("Requires package 'igraph'")
  }

  classify = list(...)
  if(length(classify) != 2) {
    stop("Two classify factors must be provided")
  }
  if(!all(is.element(unlist(classify), names(data)))) {
    stop("One or more classify factors not present in the data")
  }
  imat <- table(data[[ classify[[1]] ]], data[[ classify[[2]] ]])
  G <- igraph::graph_from_incidence_matrix(imat)
  igraph::vertex_attr(G) <- list(color = c(rep("white", dim(imat)[1]), rep("red", dim(imat)[2])),
                                 name = c(dimnames(imat)[[1]], dimnames(imat)[[2]]))
  plot(G)
  if(missing(title)) {
    title <- paste("Graph of", classify[[1]], "x", classify[[2]])
  }
  title(title)
  return(invisible())
}
if(!exists(".ODWenv",inherits=TRUE)) {
  .ODWenv <- new.env()
  assign("odw_options", list(), envir = .ODWenv)
}
.onLoad <- function(libname, pkgname) {
  if(Sys.getenv("load_libs", unset="") == "" || Sys.getenv("load_libs") != "no") {
    if(Sys.info()["sysname"] == "Linux") {
      ## might have to add blas libs here
      #library.dynam("libmkl_rt", pkgname, libname)
      #library.dynam("libmkl_intel_lp64", pkgname, libname)
      #library.dynam("libmkl_core", pkgname, libname)
      #library.dynam("libmkl_gnu_thread", pkgname, libname)
      library.dynam("odw", pkgname, libname)
    }
    else if(Sys.info()["sysname"] == "Darwin") {
      #library.dynam("libiomp5", pkgname, libname)
      library.dynam("odw", pkgname, libname)
    }
    else {
      library.dynam("vcruntime140", pkgname, libname)
      library.dynam("libgcc_s_seh-1", pkgname, libname)
      library.dynam("libgomp-1", pkgname, libname)
      library.dynam("libwinpthread-1", pkgname, libname)
      library.dynam("libiomp5md", pkgname, libname)
      library.dynam("mkl_odw", pkgname, libname)
      library.dynam("odw", pkgname, libname)
    }
  }
  odw.options(.control())
}
