#example 9-1 from Montgomery 5 edn
Pressure.lev <- c(10,15,20)
Speed.lev <- c(100,120,140)
Fac2Syrup.dat <- fac.gen(generate=list(Pressure = Pressure.lev, Speed = Speed.lev),
                         each=2)
Fac2Syrup.dat$Pressure <- ordered(Fac2Syrup.dat$Pressure, levels=Pressure.lev)
contrasts(Fac2Syrup.dat$Pressure) <- contr.poly(3, scores=Pressure.lev)
Fac2Syrup.dat$Speed <- ordered(Fac2Syrup.dat$Speed, levels=Speed.lev)
contrasts(Fac2Syrup.dat$Speed) <- contr.poly(3, scores=Speed.lev)
Fac2Syrup.dat <- data.frame(Test = factor(1:18), Fac2Syrup.dat)

#Data for nozzle 1 - used in SMod exam 2007
Fac2Syrup.dat$Loss <- c(-35,-25,-45,-60,-40,15, 110,75,-10,30,80,54,
                         4,5,-40,-30,31,36)+70
save(Fac2Syrup.dat, file="Fac2Syrup.dat.rda")
#Data for nozzle 2
Fac2Syrup.dat$Loss <- c(17,24,-65,-58,20,4, 55,120,-55,-44,110,44,
                        -23,-5,-64,-62,-20,-31)+70
#Data for nozzle 3
Fac2Syrup.dat$Loss <- c(-39,-35,-55,-67,15,-30, 90,113,-28,-26,110,135,
                        -30,-55,-61,-52,54,4)+70
#Analysis
load("Fac2Syrup.dat.rda")
attach(Fac2Syrup.dat)
interaction.plot(Pressure, Speed, Loss, lwd=4)
Fac2Syrup.aov <- aov(Loss ~ Pressure * Speed + Error(Test), Fac2Syrup.dat)
summary(Fac2Syrup.aov)
summary(Fac2Syrup.aov, split = list(Pressure = list(L=1, Dev=2),
         Speed = list(L=1, Dev=2)))
summary(Fac2Syrup.aov, split = list(Pressure = list(L=1, Dev=2),
         Speed = list(L=1, Dev=2),
        "Pressure:Speed" = list(L.L=1, Dev=c(2:4))))
#
# Diagnostic checking
#
res <- resid.errors(Fac2Syrup.aov)
fit <- fitted.errors(Fac2Syrup.aov)
plot(fit, res, pch=16)
plot(as.numeric(Fac2Syrup.dat$Pressure), res, pch=16)
plot(as.numeric(Fac2Syrup.dat$Speed), res, pch=16)
qqnorm(res, pch=16)
qqline(res)
#
# multiple comparisons
#
model.tables( Fac2Syrup.aov, type="means")
q <- qtukey(0.95, 3, 9)