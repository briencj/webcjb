library(dae)
load("Fac2Copp.dat.rda")
attach(Fac2Copp.dat)
Fac2Copp.dat
interaction.plot(Copper, Temp, Warp, lwd=4)
interaction.plot(Temp, Copper, Warp, lwd=4)
#
# Set up to fit polynomials
#
Copper.lev <- seq(40, 100, 20)
Fac2Copp.dat$Copper <- ordered(Fac2Copp.dat$Copper, levels=Copper.lev)
contrasts(Fac2Copp.dat$Copper) <- contr.poly(4, scores=Copper.lev)
contrasts(Fac2Copp.dat$Copper)
Temp.lev <- seq(50, 125, 25)
Fac2Copp.dat$Temp <- ordered(Fac2Copp.dat$Temp, levels=Temp.lev)
contrasts(Fac2Copp.dat$Temp) <- contr.poly(4, scores=Temp.lev)
contrasts(Fac2Copp.dat$Temp)
Fac2Copp.aov <- aov(Warp ~ Day + Copper * Temp + Error(Day/Run), Fac2Copp.dat)
summary(Fac2Copp.aov)
summary(Fac2Copp.aov, split = list(Copper = list(L=1, Q=2, Dev=3), Temp = list(L=1, Q= 2, Dev=3)))
summary(Fac2Copp.aov, split = list(
        Copper = list(L=1, Q=2, Dev=3), 
        Temp = list(L=1, Q= 2, Dev=3),
        "Copper:Temp" = list(L.L=1, L.Q=2, Q.L=4, Q.Q=5, Dev=c(3,6:9))))
summary(Fac2Copp.aov, split = list(Temp = list(L = 1, Q = 2)))
#Compute Day F and p
Day.F <- 4.5/5.3
Day.p <- 1-pf(Day.F, 1, 15)
data.frame(Day.F,Day.p)
#
# Diagnostic checking
#
res <- resid.errors(Fac2Copp.aov)
fit <- fitted.errors(Fac2Copp.aov)
data.frame(Day,Run,Copper,Temp,Warp,res,fit)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
plot(as.numeric(Day), res, pch = 16)
plot(as.numeric(Copper), res, pch = 16)
plot(as.numeric(Temp), res, pch = 16)
tukey.1df(Fac2Copp.aov, Fac2Copp.dat, error.term="Day:Run")
#
# get fitted equation using power terms
#
Cu <- as.numeric(as.vector(Copper))
Cu2 <- Cu * Cu
Te <- as.numeric(as.vector(Temp))
Te2 <- Te * Te
Te3 <- Te2 * Te
LinLin <- Cu * Te
LinQuad <- LinLin * Te
Fac2Copp.lm <- lm(Warp ~ Cu + Cu2 + Te + Te2 +Te3 + LinLin + LinQuad)
coef(Fac2Copp.lm)
wireframe(Warp ~ Cu*Te, data= Fac2Copp.surf, drape=TRUE)

#
# get fitted equation and surface plot based on including power terms
#
Cu <- as.numeric(as.vector(Copper))

Cu2 <- Cu * Cu
Te <- as.numeric(as.vector(Temp))
Te2 <- Te * Te ; Te3 <- Te2 * Te
LinLin <- Cu * Te ; LinQuad <- LinLin * Te
Fac2Copp.lm <- lm(Warp ~ Cu + Cu2 + Te + Te2 +Te3 + LinLin + LinQuad)
coef(Fac2Copp.lm)
Fac2Copp.grid <- list(Cu = seq(min(Cu), max(Cu), length = 40), 
                      Te = seq(min(Te), max(Te), length = 40))
Pred.grid <- expand.grid(Fac2Copp.grid)
Pred.grid$Cu2 <- Pred.grid$Cu*Pred.grid$Cu
Pred.grid$Te2 <- Pred.grid$Te*Pred.grid$Te
Pred.grid$Te3 <- Pred.grid$Te2*Pred.grid$Te
Pred.grid$LinLin <- Pred.grid$Cu*Pred.grid$Te
Pred.grid$LinQuad <- Pred.grid$LinLin*Pred.grid$Te
Pred.grid$Warp <- as.vector(predict.gam(Fac2Copp.lm, Pred.grid))
persp(Fac2Copp.grid$Cu, Fac2Copp.grid$Te, matrix(Pred.grid$Warp, 40, 40))
#make sure that columns of Pred.grid are in same order as coefficients if next expression used
#Pred.grid$"(Intercept)" <- rep(1, 1600)
#Fac2Copp.pred <- as.matrix(Pred.grid, 1600, 8, byrow=T) %*% as.matrix(coef(Fac2Copp.lm), 8, 1)
#
# plotting surface based on use of poly in model (cannot get coefficients on the natural scale)
#
Cu <- as.numeric(as.vector(Copper))
Te <- as.numeric(as.vector(Temp))
Fac2Copp.lm <- lm(Warp ~ poly(Cu, 2) + poly(Te,3) + poly(Cu, 1) * poly(Te, 2), singular.ok=T)
coef(Fac2Copp.lm)
Fac2Copp.grid <- list(Cu = seq(min(Cu), max(Cu), length = 40), 
                      Te = seq(min(Te), max(Te), length = 40))
Fac2Copp.surf <- expand.grid(Fac2Copp.grid)
Fac2Copp.surf$Warp <- as.vector(predict(Fac2Copp.lm, Fac2Copp.surf))
wireframe(Warp ~ Cu*Te, data= Fac2Copp.surf, drape=TRUE)
# now use the 3D Plot Pallete to plot the predicted values
windows()
persp(Fac2Copp.surf$Cu, Fac2Copp.surf$Te, Fac2Copp.surf$Warp)
#tried to get coeffs from orthogonal polys but appears to be impossible
poly(Cu,2)
poly(Te,3)
poly.both <- poly(Cu, Te, 3)
poly.both
poly.all <- poly.both[,c(1,2,4,5,6,7,9)]
attributes(poly.all)[["degree"]] <- attributes(poly.both)[["degree"]][c(1,2,4,5,6,7,9)]
poly.all
poly.transform(poly.all, coef(Fac2Copp.lm))

