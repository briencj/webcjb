library(dae)
load("Fac2Copp.dat.rda")
attach(Fac2Copp.dat)
Fac2Copp.dat
#
# Set up to fit polynomials
#
Copper.lev <- seq(40, 100, 20)
Fac2Copp.dat$Copper <- ordered(Fac2Copp.dat$Copper, levels=Copper.lev)
contrasts(Fac2Copp.dat$Copper) <- contr.poly(4, scores=Copper.lev)
contrasts(Fac2Copp.dat$Copper)
Temp.lev <- seq(50, 125, 25)
Fac2Copp.dat$Temp <- ordered(Fac2Copp.dat$Temp, levels=Temp.lev)
contrasts(Fac2Copp.dat$Temp) <- contr.poly(4, scores=Temp.lev)
contrasts(Fac2Copp.dat$Temp)
Fac2Copp.aov <- aov(Warp ~ Day + Copper * Temp + Error(Day/Run), Fac2Copp.dat)
summary(Fac2Copp.aov, split = list(
        Copper = list(L=1, Q=2, Dev=3), 
        Temp = list(L=1, Q= 2, Dev=3),
        "Copper:Temp" = list(L.L=1, L.Q=2, Q.L=4, Q.Q=5, Dev=c(3,6:9))))
#
# get fitted equation using power terms
#
Cu <- as.numeric(as.vector(Copper))
Te <- as.numeric(as.vector(Temp))
Fac2Copp.lm <- lm(Warp ~ poly(Cu, 2) + poly(Te,3) 
                          + poly(Cu, 1) * poly(Te, 2), singular.ok=T)
coef(Fac2Copp.lm)
Fac2Copp.grid <- list(Cu = seq(min(Cu), max(Cu), length = 40), 
                      Te = seq(min(Te), max(Te), length = 40))
Fac2Copp.surf <- expand.grid(Fac2Copp.grid)
Fac2Copp.surf$Warp <- as.vector(predict(Fac2Copp.lm, Fac2Copp.surf))
wireframe(Warp ~ Cu*Te, data= Fac2Copp.surf, drape=TRUE)


