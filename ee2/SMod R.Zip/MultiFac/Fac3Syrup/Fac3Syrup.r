#example 9-1 from Montgomery 5 edn
Pressure.lev <- c(10,15,20)
Speed.lev <- c(100,120,140)
Nozzle.lev <- c("A", "B", "C")
Fac3Syrup.dat <- fac.gen(generate=list(Nozzle = Nozzle.lev, 
                                       Pressure = Pressure.lev, Speed = Speed.lev),
                         each=2)
Fac3Syrup.dat$Pressure <- ordered(Fac3Syrup.dat$Pressure, levels=Pressure.lev)
contrasts(Fac3Syrup.dat$Pressure) <- contr.poly(3, scores=Pressure.lev)
Fac3Syrup.dat$Speed <- ordered(Fac3Syrup.dat$Speed, levels=Speed.lev)
contrasts(Fac3Syrup.dat$Speed) <- contr.poly(3, scores=Speed.lev)
Fac3Syrup.dat <- data.frame(Test = factor(1:54), Fac3Syrup.dat)

#Data
Fac3Syrup.dat$Loss <- c(-35,-25,-45,-60,-40,15, 110,75,-10,30,80,54,
                         4,5,-40,-30,31,36, 17,24,-65,-58,20,4, 
                         55,120,-55,-44,110,44, -23,-5,-64,-62,-20,-31,
                         -39,-35,-55,-67,15,-30, 90,113,-28,-26,110,135,
                        -30,-55,-61,-52,54,4)+70
#Analysis
interaction.ABC.plot(Loss, Pressure, Speed, Nozzle, data=Fac3Syrup.dat)
Fac3Syrup.aov <- aov(Loss ~ Nozzle * Pressure * Speed + Error(Test), Fac3Syrup.dat)
summary(Fac3Syrup.aov)
summary(Fac3Syrup.aov, split = list(Pressure = list(L=1, Dev=2),
         Speed = list(L=1, Dev=2)))
summary(Fac3Syrup.aov, split = list(Pressure = list(L=1, Dev=2),
         Speed = list(L=1, Dev=2),
        "Pressure:Speed" = list(L.L=1, Dev=c(2:4)),
        "Nozzle:Pressure:Speed" = list(L.L=1, Dev=c(2:4))))
#
# Diagnostic checking
#
res <- resid.errors(Fac3Syrup.aov)
fit <- fitted.errors(Fac3Syrup.aov)
plot(fit, res, pch=16)
plot(as.numeric(Fac3Syrup.dat$Nozzle), res, pch=16)
plot(as.numeric(Fac3Syrup.dat$Pressure), res, pch=16)
plot(as.numeric(Fac3Syrup.dat$Speed), res, pch=16)
qqnorm(res, pch=16)
qqline(res)
#
# multiple comparisons
#
model.tables( Fac3Syrup.aov, type="means")
q <- qtukey(0.95, 3, 9)