# set up some dummy factors and MOE values
mp <- c("-", "+")
fnames <- list(A = mp, B = mp, C = mp)
ABC.Interact.dat <- fac.gen(fnames)
ABC.Interact.dat$MOE <- rnorm(8, mean=100, sd=5)
ABC.Interact
load("ABC.Interact.dat.rda")
attach(ABC.Interact.dat)

#two-factor interaction plot
interaction.plot(A, B, MOE, lwd=4)

# produce a three-factor interaction plot for the dummy data
"mpone" <- function(factor) {2*as.numeric(factor)-3}

interaction.ABC.plot(MOE, A, B, C, data=ABC.Interact.dat)
interaction.ABC.plot(MOE, mpone(A), B, C, xlab="A", data=ABC.Interact.dat)
interaction.ABC.plot(ABC.Interact.dat$MOE, ABC.Interact.dat$A, ABC.Interact.dat$B, ABC.Interact.dat$C)

