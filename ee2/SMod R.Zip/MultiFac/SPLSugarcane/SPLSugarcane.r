library(dae)

# set up data.frame with factors Blocks,Plots,Subplots,
# Treats, Weeks and response variable Brix
RCBDSPSugar.dat <- data.frame(Blocks = factor(rep(c(1:8), each=18)),
Plots = factor(rep(rep(c(1:3), each=6),times=8)),SubPlots = factor(rep(c(1:6), times=24)),
Products = factor(rep(rep(c("A","B","C"), each=6),times=8)),Weeks = factor(rep(c(0,2,4,6,8,10),times=24)))
RCBDSPSugar.dat$Brix<-c(
17.70,16.95,18.95,18.65,19.70,20.75,16.83,17.70,18.00,
18.68,19.55,15.56,16.63,17.18,18.05,18.50,20.65,19.90,
17.50,18.60,18.10,18.50,20.20,19.00,16.96,17.56,18.05,
18.83,19.38,17.18,17.70,17.75,18.20,19.53,20.90,23.96,
17.95,17.05,17.60,19.65,19.70,19.85,17.25,18.17,18.55,
17.65,18.10,19.00,17.52,17.65,18.57,19.08,18.68,19.08,
17.90,18.00,18.35,18.30,19.70,20.80,18.22,17.72,19.52,
20.40,20.85,19.40,17.52,17.55,19.57,19.03,18.55,19.03,
17.30,19.40,19.20,20.10,20.55,19.45,17.75,19.48,20.70,
20.03,20.80,20.45,17.26,18.61,19.03,19.48,20.28,20.62,
17.60,18.55,18.90,18.75,20.25,21.70,16.90,18.20,18.85,
19.63,20.42,19.92,17.18,18.26,18.91,18.95,20.25,20.33,
17.40,17.80,18.25,19.25,19.80,19.10,16.70,18.58,18.41,
18.70,19.33,20.00,17.43,18.00,18.48,18.77,19.27,20.06,
17.75,18.05,18.70,17.40,18.70,18.25,17.19,18.14,19.20,
19.71,21.10,19.65,16.52,16.56,17.73,16.54,15.60,18.85)

attach(RCBDSPSugar.dat)
RCBDSPSugar.dat

interaction.plot(Products, Weeks, Brix, lwd = 2)
interaction.plot(Weeks, Products, Brix, lwd = 2)

RCBDSPSugar.aov <- aov(Brix ~ Blocks+Products*Weeks + Error(Blocks/Plots/SubPlots), RCBDSPSugar.dat)
summary(RCBDSPSugar.aov)
res <- resid.errors(RCBDSPSugar.aov)
fit <- fitted.errors(RCBDSPSugar.aov)
plot(fit, res, pch = 16)
plot(as.numeric(Products), res, pch = 16)
plot(as.numeric(Weeks), res, pch = 16)
qqnorm(res, pch = 16)
qqline(res)

model.tables(RCBDSPSugar.aov, type="means", se=T)

Weeks.lev <- seq(0, 10, 2)
contrasts(RCBDSPSugar.dat$Weeks) <- contr.poly(Weeks.lev)
contrasts(RCBDSPSugar.dat$Weeks)
RCBDSPSugar.aov <- aov(Brix ~ Blocks+Products*Weeks + 
                              Error(Blocks/Plots/SubPlots), RCBDSPSugar.dat)
summary(RCBDSPSugar.aov, split = list(Weeks = list(L = 1, Q = 2, Devn=3:5)))
