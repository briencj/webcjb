#
# set up data.frame
#
mp <- c("-", "+")
fnames <- list(Seat = mp, Dynamo = mp, Handbars = mp)
Frf7Bike.Treats <- fac.gen(generate = fnames, order="yates")
attach(Frf7Bike.Treats)
Frf7Bike.Treats$Gear <- factor(mpone(Seat)*mpone(Dynamo), labels = mp)
Frf7Bike.Treats$Raincoat <- factor(mpone(Seat)*mpone(Handbars), labels = mp)
Frf7Bike.Treats$Brekkie <- factor(mpone(Dynamo)*mpone(Handbars), labels = mp)
Frf7Bike.Treats$Tyres <- factor(mpone(Seat)*mpone(Dynamo)*mpone(Handbars), 
                                                                   labels = mp)
detach(Frf7Bike.Treats)
Frf7Bike.dat <- data.frame(Runs = factor(1:8), Frf7Bike.Treats)
Frf7Bike.dat$Time <- as.vector(c(69, 52, 60, 83, 71, 50, 59, 88))
Frf7Bike.dat
#
# analyse
#
Frf7Bike.aov <- aov(Time ~ (Seat + Dynamo + Handbars + Gear + Raincoat + Brekkie + Tyres)^2 
                                                                      + Error(Runs), Frf7Bike.dat)
summary(Frf7Bike.aov)
qqnorm.yeffects(Frf7Bike.aov, error.term = "Runs", data=Frf7Bike.dat)
round(yates.effects(Frf7Bike.aov, error.term="Runs", data=Frf7Bike.dat), 2)
#
# second fraction
#
Frf7Bike2.dat <- Frf7Bike.dat
attach(Frf7Bike2.dat)
Frf7Bike2.dat$Gear <- factor(-mpone(Seat)*mpone(Dynamo), labels = mp)
detach(Frf7Bike2.dat)
Frf7Bike2.dat$Time <- as.vector(c(47, 74, 84, 62, 53, 78, 87,60))
#
# combine fractions
#
Frf7Bike.Both.dat <- rbind(Frf7Bike.dat,Frf7Bike2.dat)
Frf7Bike.Both.dat <- data.frame(Block = factor(rep(1:2, each=8)), 
                                Frf7Bike.Both.dat)
Frf7Bike.Both.dat
# 
# analyse
#
Frf7Bike.Both.aov <- aov(Time ~ Block + (Seat + Dynamo + Handbars + Gear + Raincoat + Brekkie + Tyres)^2 + 
                                   Error(Block/Runs), Frf7Bike.Both.dat)
summary(Frf7Bike.Both.aov)
qqnorm.yeffects(Frf7Bike.Both.aov, error.term = "Block:Runs", 
                data=Frf7Bike.Both.dat)
round(yates.effects(Frf7Bike.Both.aov, error.term="Block:Runs", 
                    data=Frf7Bike.Both.dat), 2)
#
# re-do analysis for just fitted model followed by diagnostic checking
#
Frf7Bike.Both.Fit.aov <- aov(Time ~ Block + Dynamo + Gear + Error(Block/Runs), Frf7Bike.Both.dat)
summary(Frf7Bike.Both.Fit.aov)
tukey.1df(Frf7Bike.Both.Fit.aov, Frf7Bike.Both.dat, error.term="Block:Runs")
res <- resid.errors(Frf7Bike.Both.Fit.aov)
fit <- fitted.errors(Frf7Bike.Both.Fit.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
plot(as.numeric(Frf7Bike.Both.dat$Seat), res, pch=16)
plot(as.numeric(Frf7Bike.Both.dat$Dynamo), res, pch=16)
plot(as.numeric(Frf7Bike.Both.dat$Handbars), res, pch=16)
plot(as.numeric(Frf7Bike.Both.dat$Gear), res, pch=16)
plot(as.numeric(Frf7Bike.Both.dat$Raincoat), res, pch=16)
plot(as.numeric(Frf7Bike.Both.dat$Brekkie), res, pch=16)
plot(as.numeric(Frf7Bike.Both.dat$Tyres), res, pch=16)

