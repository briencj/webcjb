mp <- c("-", "+")
#
# randomized layout for first fraction
#
fnames <- list(Seat = mp, Dynamo = mp, Handbars = mp)
Frf7Bike.ran <- fac.gen(generate = fnames, order = "yates")
attach(Frf7Bike.ran)
Frf7Bike.ran$Gear <- factor(mpone(Seat)*mpone(Dynamo), labels = mp)
Frf7Bike.ran$Raincoat <- factor(mpone(Seat)*mpone(Handbars), labels = mp)
Frf7Bike.ran$Brekkie <- factor(mpone(Dynamo)*mpone(Handbars), labels = mp)
Frf7Bike.ran$Tyres <- factor(mpone(Seat)*mpone(Dynamo)*mpone(Handbars), labels = mp)
detach(Frf7Bike.ran)
Frf7Bike.unit <- list(Runs = 8)                                                           
Frf7Bike.lay <- fac.layout(unrandomized = Frf7Bike.unit, 
                           randomized = Frf7Bike.ran)
Frf7Bike.lay
#
# second and combined fractions
#
Frf7Bike2.ran <- Frf7Bike.ran
attach(Frf7Bike2.ran)
Frf7Bike2.ran$Gear <- factor(-mpone(Seat)*mpone(Dynamo), labels = mp)
detach(Frf7Bike2.ran)
Frf7Bike2.lay <- fac.layout(unrandomized = Frf7Bike.unit, 
                            randomized = Frf7Bike2.ran)
Frf7Bike.Both.lay <- rbind(Frf7Bike.lay,Frf7Bike2.lay)
Frf7Bike.Both.lay <- data.frame(Block = factor(rep(1:2, each=8)), 
                                Frf7Bike.Both.lay)
Frf7Bike.Both.lay
