library(dae)
load("Fac2Swine.dat.rda")
attach(Fac2Swine.dat)
Fac2Swine.dat
interaction.plot(Antibiotic, Vitamin, Wt.Gain, lwd=4)
Fac2Swine.aov <- aov(Wt.Gain ~ Antibiotic * Vitamin + Error(Swine), Fac2Swine.dat)
summary(Fac2Swine.aov)
#
# Diagnostic checking
#
res <- resid.errors(Fac2Swine.aov)
fit <- fitted.errors(Fac2Swine.aov)
data.frame(Swine,Antibiotic,Vitamin,Wt.Gain,res,fit)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
plot(as.numeric(Antibiotic), res, pch = 16)
plot(as.numeric(Vitamin), res, pch = 16)
#
# multiple comparisons
#
Fac2Swine.tab <- model.tables(Fac2Swine.aov, type="means")
Fac2Swine.tab$tables$"Antibiotic:Vitamin"
q <- qtukey(0.95, 4, 8)
q
#
# reanalysis for one-cell interaction model
#

Fac2Swine.dat$Both <- factor(1 + as.numeric(Antibiotic == "40" & Vitamin == "5"))
Fac2Swine.dat$Treats <- fac.combine(list(Antibiotic, Vitamin))
attach(Fac2Swine.dat)
Fac2Swine.dat
Fac2Swine.aov <- aov(Wt.Gain ~ Both/Treats + Error(Swine), Fac2Swine.dat)
summary(Fac2Swine.aov)
#
# multiple comparisons
#
Fac2Swine.NoError.aov <- aov(Wt.Gain ~ Treats, Fac2Swine.dat)
Fac2Swine.mca <- multicomp(Fac2Swine.NoError.aov, focus = "Treats")
plot(Fac2Swine.mca)
Fac2Swine.mca

