load("Fac4Ball.dat.rda")
Fac4Ball.dat
#
# analysis
#
Fac4Ball.aov <- aov(Velocity ~ Charge * Project * Propell * Weapon + 
                               Error(Day/Tests), Fac4Ball.dat)
summary(Fac4Ball.aov)
qqyeffects(Fac4Ball.aov, error.term = "Day:Tests", data=Fac4Ball.dat)
round(yates.effects(Fac4Ball.aov, error.term="Day:Tests", data=Fac4Ball.dat), 2)
Fac4Ball.Fit.aov <- aov(Velocity ~ Day + Charge + Weapon + Project * Propell + 
                               Error(Day/Tests), Fac4Ball.dat)
summary(Fac4Ball.Fit.aov)
#
# Diagnostic checking
#
tukey.1df(Fac4Ball.Fit.aov, data=Fac4Ball.dat, error.term="Day:Tests")
res <- resid.errors(Fac4Ball.Fit.aov)
fit <- fitted.errors(Fac4Ball.Fit.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
attach(Fac4Ball.dat)
plot(as.numeric(Charge), res, pch=16)
plot(as.numeric(Project), res, pch=16)
plot(as.numeric(Propell), res, pch=16)
plot(as.numeric(Weapon), res, pch=16)
#
# treatment differences
#
interaction.plot(Project, Propell, Velocity, lwd=4)
Fac4Ball.means <- model.tables(Fac4Ball.Fit.aov, type="means")
Fac4Ball.means$tables$"Grand mean"
Fac4Ball.means$tables$"Charge"
Fac4Ball.means$tables$"Weapon"
Fac4Ball.means$tables$"Project:Propell"
q <- qtukey(0.95, 4, 9)
q
