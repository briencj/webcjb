#
#Match data from old layout with new layout
#
load("SPLProd.dat.rda")
SPLProd.dat <- data.frame(SPLProd.lay[order(SPLProd.lay$Factories, 
                                            SPLProd.lay$Methods, 
                                            SPLProd.lay$Sources),],
                          Prodn = SPLProd.dat$Prodn)
SPLProd.dat[SPLProd.dat$Units,] <- SPLProd.dat
SPLProd.dat
#
# analyze
#
attach(SPLProd.dat)
interaction.plot(Methods, Sources, Prodn, lwd = 4)
SPLProd.aov <- aov(Prodn ~ Factories + Methods * Sources + 
                           Error(Factories/Areas/Parts), SPLProd.dat)
summary(SPLProd.aov)
#Compute Factories and Areas[Factories] Fs and p-values
Factories.F <- 424.07/315.7
Factories.p <- 1-pf(Factories.F, 3, 6)
Factories.Areas.F <- 315.7/136.94
Factories.Areas.p <- 1-pf(Factories.Areas.F, 6, 18)
data.frame(Factories.F,Factories.p,Factories.Areas.F,Factories.Areas.p)
#
# Diagnostic checking
#
tukey.1df(SPLProd.aov, SPLProd.dat, "Factories:Areas:Parts")
res <- resid.errors(SPLProd.aov)
fit <- fitted.errors(SPLProd.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
plot(as.numeric(Methods), res, pch=16)
plot(as.numeric(Sources), res, pch=16)
#
# tables of means
#
SPLProd.means <- model.tables(SPLProd.aov, type="means")
SPLProd.means
qtukey(0.95, 3, 6)
qtukey(0.95, 3, 18)
