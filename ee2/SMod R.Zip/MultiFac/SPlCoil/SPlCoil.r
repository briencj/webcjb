SPlCoil.dat <- read.csv("SPlCoil.dat.csv", header=TRUE, colClasses=c(rep("factor", 4),"numeric"))
save(SPlCoil.dat, file="SPlCoil.dat.rda")
load("SPlCoil.dat.rda")
attach(SPlCoil.dat)
SPlCoil.aov <- aov(Diameter ~ Stock * Type + Error(Type/Machine/Run), SPlCoil.dat)
summary(SPlCoil.aov)

