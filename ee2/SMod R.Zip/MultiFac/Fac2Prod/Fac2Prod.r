library(dae)
load("Fac2Prod.dat.rda")
attach(Fac2Prod.dat)
Fac2Prod.dat
interaction.plot(Machine, Operator, No.Units, lwd=4)
Fac2Prod.aov <- aov(No.Units ~ Machine * Operator + Error(Period/Day), Fac2Prod.dat)
summary(Fac2Prod.aov)
#Compute Period F and p
Period.F <- 9.025/4.50
Period.p <- 1-pf(Period.F, 1, 19)
data.frame(Period.F,Period.p)
#
# recalculate main effect F and p-values
#
MSq <- c(7.85,251.22)
df.num <- c(4,3)
Fvalue <- MSq/6.43
pvalue <- 1-pf(Fvalue, df.num, 12)
data.frame(MSq,df.num,Fvalue,pvalue)
#
# Diagnostic checking
#
res <- resid.errors(Fac2Prod.aov)
fit <- fitted.errors(Fac2Prod.aov)
data.frame(Period,Day,Machine,Operator,No.Units,res,fit)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
plot(as.numeric(Period), res, pch = 16)
plot(as.numeric(Machine), res, pch = 16)
plot(as.numeric(Operator), res, pch = 16)
tukey.1df(Fac2Prod.aov, Fac2Prod.dat, error.term="Period:Day")

