#
# set up data.frame and analyse
#
mp <- c("-", "+")
fnames <- list(Feed = mp, Catal = mp, Agitation = mp, Temp = mp, Conc = mp)
Fac5Reac.Treats <- fac.gen(generate = fnames, order="yates")
Fac5Reac.dat <- data.frame(Runs = factor(1:32), Fac5Reac.Treats)
remove("Fac5Reac.Treats")
Fac5Reac.dat$Reacted <- c(61,53,63,61,53,56,54,61,69,61,94,93,66,60,95,98,
                          56,63,70,65,59,55,67,65,44,45,78,77,49,42,81,82)
Fac5Reac.dat
Fac5Reac.aov <- aov(Reacted ~ Feed * Catal * Agitation * Temp * Conc + Error(Runs), Fac5Reac.dat)
summary(Fac5Reac.aov)
qqnorm.yeffects(Fac5Reac.aov, error.term="Runs", data=Fac5Reac.dat)
round(yates.effects(Fac5Reac.aov, error.term="Runs", data=Fac5Reac.dat), 2)
Fac5Reac.Fit.aov <- aov(Reacted ~ Temp * (Catal + Conc) + Error(Runs), Fac5Reac.dat)
summary(Fac5Reac.Fit.aov)
#
# Diagnostic checking
#
tukey.1df(Fac5Reac.Fit.aov, Fac5Reac.dat, error.term="Runs")
res <- resid.errors(Fac5Reac.Fit.aov)
fit <- fitted.errors(Fac5Reac.Fit.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
plot(as.numeric(Feed), res, pch=16)
plot(as.numeric(Catal), res, pch=16)
plot(as.numeric(Agitation), res, pch=16)
plot(as.numeric(Temp), res, pch=16)
plot(as.numeric(Conc), res, pch=16)
#
# treatment differences
#
interaction.plot(Temp, Catal, Reacted, lwd=4)
interaction.plot(Temp, Conc, Reacted, lwd=4)
Fac5Reac.means <- model.tables(Fac5Reac.Fit.aov, type="means")
Fac5Reac.means$tables$"Temp:Catal"
Fac5Reac.means$tables$"Temp:Conc"
q <- qtukey(0.95, 4, 26)
q