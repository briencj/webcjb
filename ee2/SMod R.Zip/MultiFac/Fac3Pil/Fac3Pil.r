#
#obtain randomized layout
#
n <- 16
mp <- c("-", "+")
Fac3Pilot.ran <- fac.gen(generate = list(Te = mp, C = mp, K = mp), each = 2, 
                         order="yates")
Fac3Pilot.unit <- list(Tests = n)
Fac3Pilot.lay <- fac.layout(unrandomized = Fac3Pilot.unit, 
                            randomized = Fac3Pilot.ran, seed = 897)
#sort treats into Yates order
Fac3Pilot.lay <- Fac3Pilot.lay[Fac3Pilot.lay$Permutation,] 
Fac3Pilot.lay
#add Yield 
Fac3Pilot.dat <- data.frame(Fac3Pilot.lay, 
                            Yield = c(59, 61, 74, 70, 50, 58, 69, 67, 
                                      50, 54, 81, 85, 46, 44, 79, 81))
Fac3Pilot.dat
#re-sort into randomized order
Fac3Pilot.dat <- Fac3Pilot.dat[Fac3Pilot.dat$Units,]
attach(Fac3Pilot.dat)
#analyse
interaction.ABC.plot(Yield, Te, C, K, data=Fac3Pilot.dat,
                     title="Effect of Temperature(Te), Concentration(C) and Catalyst(K) on Yield")
Fac3Pilot.aov <- aov(Yield ~ Te * C * K + Error(Tests), Fac3Pilot.dat)
summary(Fac3Pilot.aov)
round(yates.effects(Fac3Pilot.aov, error.term = "Tests", data=Fac3Pilot.dat), 2)
#
# Diagnostic checking
#
res <- resid.errors(Fac3Pilot.aov)
fit <- fitted.errors(Fac3Pilot.aov)
data.frame(Te,C,K,Yield,res,fit)
plot(fit, res, pch=16)
plot(as.numeric(Te), res, pch=16)
plot(as.numeric(C), res, pch=16)
plot(as.numeric(K), res, pch=16)
qqnorm(res, pch=16)
qqline(res)
#
# treatment differences
#
Fac3Pilot.means <- model.tables(Fac3Pilot.aov, type="means")
Fac3Pilot.means$tables$"Grand mean"
Fac3Pilot.means$tables$"Te:K"
Fac3Pilot.means$tables$"C"
q <- qtukey(0.95, 4, 8)
q

