#example comes from Wu and Hamada (2000) ex. 37 p.92
Fac2Muzzle.Hole.Area.dat <- read.csv("Fac2Muzzle.Hole.Area.dat.csv", header=TRUE, 
                                       colClasses=c(rep("factor", 3),rep("numeric", 4)))
save(Fac2Muzzle.Hole.Area.dat, file="Fac2Muzzle.Hole.Area.dat.rda")
load("Fac2Muzzle.Hole.Area.dat.rda")
attach(Fac2Muzzle.Hole.Area.dat)
Fac2Muzzle.Hole.Area.dat
interaction.plot(Vent.Vol, O.Ring, Velocity.03, lwd=4)
#
# Set up to fit polynomials
#
t <- 4
Vent.Vol.lev <- c(0.29, 0.4, 0.59, 0.91)
Fac2Muzzle.Hole.Area.dat$Vent.Vol <- ordered(Fac2Muzzle.Hole.Area.dat$Vent.Vol, levels=Vent.Vol.lev)
contrasts(Fac2Muzzle.Hole.Area.dat$Vent.Vol) <- contr.poly(t, scores=Vent.Vol.lev)
Fac2Muzzle.Hole.Area.aov <- aov(Velocity.03 ~ Vent.Vol * O.Ring + Error(Test), Fac2Muzzle.Hole.Area.dat)
summary(Fac2Muzzle.Hole.Area.aov)
summary(Fac2Muzzle.Hole.Area.aov, split = list(Vent.Vol = list(L=1, Q=2, Dev=3)))
#
# Diagnostic checking
#
res <- resid.errors(Fac2Muzzle.Hole.Area.aov)
fit <- fitted.errors(Fac2Muzzle.Hole.Area.aov)
plot(fit, res, pch=16)
plot(as.numeric(O.Ring), res, pch=16)
plot(as.numeric(Vent.Vol), res, pch=16)
qqnorm(res, pch=16)
qqline(res)
tukey.1df(Fac2Muzzle.Hole.Area.aov, Fac2Muzzle.Hole.Area.dat, error.term="Test")
#
# get fitted equation using power terms
#
VV <- as.numeric(as.vector(Vent.Vol))
Fac2Muzzle.lm <- lm(Velocity.03 ~ -1+ O.Ring + VV:O.Ring)
coef(Fac2Muzzle.lm)