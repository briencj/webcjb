#example comes from Wu and Hamada (2000) ex. 37 p.92
load("Fac2Muzzle.dat.rda")
attach(Fac2Muzzle.dat)
Fac2Muzzle.dat
interaction.plot(Vent.Vol, Hole.Area, Velocity, lwd=4)
interaction.plot(Hole.Area, Vent.Vol, Velocity, lwd=4)
#
# Set up to fit polynomials
#
Vent.Vol.lev <- c(0.29, 0.4, 0.59, 0.91)
Fac2Muzzle.dat$Vent.Vol <- ordered(Fac2Muzzle.dat$Vent.Vol, levels=Vent.Vol.lev)
contrasts(Fac2Muzzle.dat$Vent.Vol) <- contr.poly(4, scores=Vent.Vol.lev)
contrasts(Fac2Muzzle.dat$Vent.Vol)
Hole.Area.lev <- c(0.016, 0.03, 0.048, 0.062)
Fac2Muzzle.dat$Hole.Area <- ordered(Fac2Muzzle.dat$Hole.Area, levels=Hole.Area.lev)
contrasts(Fac2Muzzle.dat$Hole.Area) <- contr.poly(4, scores=Hole.Area.lev)
contrasts(Fac2Muzzle.dat$Hole.Area)
Fac2Muzzle.aov <- aov(Velocity ~ Vent.Vol * Hole.Area + Error(Test), Fac2Muzzle.dat)
summary(Fac2Muzzle.aov)
summary(Fac2Muzzle.aov, split = list(
        Vent.Vol = list(L=1, Q=2, Dev=3), 
        Hole.Area = list(L=1, Q= 2, Dev=3),
        "Vent.Vol:Hole.Area" = list(L.L=1, L.Q=2, Q.L=4, Q.Q=5, Dev=c(3,6:9))))
summary(Fac2Muzzle.aov, split = list(Vent.Vol = list(L=1, Q=2, Dev=3), 
                                     Hole.Area = list(L=1, Q= 2, Dev=3)))
V.H.Dev.SS <- 21.072 + 40.318 + 7.876 + 45.763 + 12.165
V.H.Dev.MS <- V.H.Dev.SS/5
V.H.Dev.F <- V.H.Dev.MS/21.243
V.H.Dev.p <- 1 - pf(V.H.Dev.F,5,16)
data.frame(V.H.Dev.SS, V.H.Dev.MS, V.H.Dev.F, V.H.Dev.p)
#
# Diagnostic checking
#
library(DAE, lib.loc="d:\\analyses\\SPlus6")
res <- resid.errors(Fac2Muzzle.aov)
fit <- fitted.errors(Fac2Muzzle.aov)
data.frame(Day,Test,Vent.Vol,Hole.Area,Velocity,res,fit)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
tukey.1df(Fac2Muzzle.aov, Fac2Muzzle.dat, error.term="Test")
#
# get fitted equation using power terms
#
Cu <- as.numeric(as.vector(Vent.Vol))
Cu2 <- Cu * Cu
Te <- as.numeric(as.vector(Hole.Area))
Te2 <- Te * Te
Te3 <- Te2 * Te
LinLin <- Cu * Te
LinQuad <- LinLin * Te
Fac2Muzzle.lm <- lm(Velocity ~ Cu + Cu2 + Te + Te2 +Te3 + LinLin + LinQuad)
coef(Fac2Muzzle.lm)
#
# get fitted surface using orthogonal polynomials
#
Fac2Muzzle.lm <- lm(Velocity ~ poly(Cu, 2) + poly(Te,3) + poly(Cu, 1) * poly(Te, 2), singular.ok=T)
coef(Fac2Muzzle.lm)
Fac2Muzzle.grid <- list(Cu = seq(min(Cu), max(Cu), length = 40), 
                      Te = seq(min(Te), max(Te), length = 40))
Fac2Muzzle.surf <- expand.grid(Fac2Muzzle.grid)
Fac2Muzzle.surf$Velocity <- as.vector(predict(Fac2Muzzle.lm, Fac2Muzzle.surf))
wireframe(Velocity ~ Cu*Te, data= Fac2Muzzle.surf, drape=TRUE)

#following does not apear to work
#
# get fitted equation and surface plot based on including power terms
#
Cu <- as.numeric(as.vector(Vent.Vol))
Cu2 <- Cu * Cu
Te <- as.numeric(as.vector(Hole.Area))
Te2 <- Te * Te ; Te3 <- Te2 * Te
LinLin <- Cu * Te ; LinQuad <- LinLin * Te
Fac2Muzzle.lm <- lm(Velocity ~ Cu + Cu2 + Te + Te2 +Te3 + LinLin + LinQuad)
coef(Fac2Muzzle.lm)
Fac2Muzzle.grid <- list(Cu = seq(min(Cu), max(Cu), length = 40), 
                      Te = seq(min(Te), max(Te), length = 40))
Pred.grid <- expand.grid(Fac2Muzzle.grid)
Pred.grid$Cu2 <- Pred.grid$Cu*Pred.grid$Cu
Pred.grid$Te2 <- Pred.grid$Te*Pred.grid$Te
Pred.grid$Te3 <- Pred.grid$Te2*Pred.grid$Te
Pred.grid$LinLin <- Pred.grid$Cu*Pred.grid$Te
Pred.grid$LinQuad <- Pred.grid$LinLin*Pred.grid$Te
Pred.grid$Velocity <- as.vector(predict(Fac2Muzzle.lm, Pred.grid))
persp(Fac2Muzzle.grid$Cu, Fac2Muzzle.grid$Te, matrix(Pred.grid$Velocity, 40, 40))
#make sure that columns of Pred.grid are in same order as coefficients if next expression used
#Pred.grid$"(Intercept)" <- rep(1, 1600)
#Fac2Muzzle.pred <- as.matrix(Pred.grid, 1600, 8, byrow=T) %*% as.matrix(coef(Fac2Muzzle.lm), 8, 1)
#
# plotting surface based on use of poly in model (cannot get coefficients on the natural scale)
#
Cu <- as.numeric(as.vector(Vent.Vol))
Te <- as.numeric(as.vector(Hole.Area))
Fac2Muzzle.lm <- lm(Velocity ~ poly(Cu, 2) + poly(Te,3) + poly(Cu, 1) * poly(Te, 2), singular.ok=T)
coef(Fac2Muzzle.lm)
Fac2Muzzle.grid <- list(Cu = seq(min(Cu), max(Cu), length = 40), 
                      Te = seq(min(Te), max(Te), length = 40))
Fac2Muzzle.surf <- expand.grid(Fac2Muzzle.grid)
Fac2Muzzle.pred <- predict(Fac2Muzzle.lm, Fac2Muzzle.surf)
Fac2Muzzle.surf$Velocity <- as.vector(Fac2Muzzle.pred)
# now use the 3D Plot Pallete to plot the predicted values
persp(Fac2Muzzle.grid$Cu, Fac2Muzzle.grid$Te, as.matrix(Fac2Muzzle.pred, 40, 40))
#tried to get coeffs from orthogonal polys but appears to be impossible
poly(Cu,2)
poly(Te,3)
poly.both <- poly(Cu, Te, 3)
poly.both
poly.all <- poly.both[,c(1,2,4,5,6,7,9)]
attributes(poly.all)[["degree"]] <- attributes(poly.both)[["degree"]][c(1,2,4,5,6,7,9)]
poly.all
poly.transform(poly.all, coef(Fac2Muzzle.lm))

