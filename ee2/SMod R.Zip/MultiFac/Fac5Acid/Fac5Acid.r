mp <- c("-", "+")
fnames <- list(Solvent = mp, Stir = mp, Conc = mp, Vol = mp, Rate = mp)
Fac5Acid.Treats <- fac.gen(generate = fnames, order="yates")
Fac5Acid.dat <- data.frame(Runs = factor(1:32), Fac5Acid.Treats)
remove("Fac5Acid.Treats")
Fac5Acid.dat$ResAcid <- c(9,3,11,8,10,9,13,7,3,5,7,7,5,6,10,7,
                          8,4,9,8,6,6,16,6,6,4,7,5,10,10,13,6)
Fac5Acid.dat
#
# analysis
#
Fac5Acid.aov <- aov(ResAcid ~ Conc * Rate * Vol * Stir * Solvent + Error(Runs), 
                    Fac5Acid.dat)
summary(Fac5Acid.aov)
qqnorm.yeffects(Fac5Acid.aov, error.term = "Runs", data=Fac5Acid.dat)
round(yates.effects(Fac5Acid.aov, error.term="Runs", data=Fac5Acid.dat), 2)
Fac5Acid.Fit.aov <- aov(ResAcid ~ Conc * Stir * Solvent + Error(Runs), 
                        Fac5Acid.dat)
summary(Fac5Acid.Fit.aov)
#
# Diagnostic checking
#
tukey.1df(Fac5Acid.Fit.aov, data=Fac5Acid.dat, error.term="Runs")
res <- resid.errors(Fac5Acid.Fit.aov)
fit <- fitted.errors(Fac5Acid.Fit.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
attach(Fac5Acid.dat)
plot(as.numeric(Conc), res, pch=16)
plot(as.numeric(Rate), res, pch=16)
plot(as.numeric(Vol), res, pch=16)
plot(as.numeric(Stir), res, pch=16)
plot(as.numeric(Solvent), res, pch=16)
#
# treatment differences
#
interaction.ABC.plot(ResAcid, Stir, Solvent, Conc, data=Fac5Acid.dat, 
                     title="Effect of Conc, Volume and Solvent on Residual Acidity")
Fac5Acid.means <- model.tables(Fac5Acid.Fit.aov, type="means")
Fac5Acid.means$tables$"Conc:Stir:Solvent"
q <- qtukey(0.95, 8, 24)
q