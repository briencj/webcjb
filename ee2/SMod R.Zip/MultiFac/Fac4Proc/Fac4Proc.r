#
# set up data frame and obtain initial analysis
#
mp <- c("-", "+")
fnames <- list(Catal = mp, Temp = mp, Press = mp, Conc = mp)
Fac4Proc.Treats <- fac.gen(generate = fnames, order="yates")
Fac4Proc.dat <- data.frame(Runs = factor(1:16), Fac4Proc.Treats)
remove("Fac4Proc.Treats")
Fac4Proc.dat$Conv <- c(71,61,90,82,68,61,87,80,61,50,89,83,59,51,85,78)
attach(Fac4Proc.dat)
Fac4Proc.dat
interaction.plot(Catal, Temp, Conv, lwd=4)
interaction.plot(Catal, Press, Conv, lwd=4)
interaction.plot(Catal, Conc, Conv, lwd=4)
interaction.plot(Temp, Press, Conv, lwd=4)
interaction.plot(Temp, Conc, Conv, lwd=4)
interaction.plot(Press, Conc, Conv, lwd=4)
Fac4Proc.aov <- aov(Conv ~ Catal * Temp * Press * Conc + Error(Runs), Fac4Proc.dat)
summary(Fac4Proc.aov)
round(yates.effects(Fac4Proc.aov, error.term="Runs", data=Fac4Proc.dat), 2)
# Perform analysis assuming 3- & 4-factor interactions negligible
Fac4Proc.TwoFac.aov <- aov(Conv ~ (Catal + Temp + Press + Conc)^2 + Error(Runs), Fac4Proc.dat)
summary(Fac4Proc.TwoFac.aov)
#
#Yates effects probability plot
#
qqyeffects(Fac4Proc.aov, error.term="Runs", data=Fac4Proc.dat)
#
# Diagnostic checking
#
Fac4Proc.Fit.aov <- aov(Conv ~ Temp * Conc + Catal + Press + Error(Runs), Fac4Proc.dat)
summary(Fac4Proc.Fit.aov)
tukey.1df(Fac4Proc.Fit.aov, Fac4Proc.dat, error.term="Runs")
res <- resid.errors(Fac4Proc.Fit.aov)
fit <- fitted.errors(Fac4Proc.Fit.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
plot(as.numeric(Temp), res, pch=16)
plot(as.numeric(Conc), res, pch=16)
plot(as.numeric(Catal), res, pch=16)
plot(as.numeric(Press), res, pch=16)
#
# treatment differences
#
Fac4Proc.means <- model.tables(Fac4Proc.aov, type="means")
Fac4Proc.means$tables$"Grand mean"
Fac4Proc.means$tables$"Temp:Conc"
Fac4Proc.means$tables$"Catal"
Fac4Proc.means$tables$"Press"
interaction.plot(Temp, Conc, Conv)
q <- qtukey(0.95, 4, 10)
q

