Fac4Proc.Conc1.dat <- Fac4Proc.dat[1:8, ]
interaction.ABC.plot(Conv, Temp, Catal, Press, data=Fac4Proc.Conc1.dat)
Fac4Proc.Conc2.dat <- Fac4Proc.dat[9:16, ]
interaction.ABC.plot(Conv, Temp, Catal, Press, data=Fac4Proc.Conc2.dat)