load("SPLGrass.dat.rda")
attach(SPLGrass.dat)
SPLGrass.dat
interaction.ABC.plot(Main.Grass, x.factor=Period, trace.factor=Summer, 
                     groups.factor=Spring, data=SPLGrass.dat, 
                     title="Effect of Period, Spring and Summer on Main Grass")
Period.lev <- c(3, 9, 18)
SPLGrass.dat$Period <- ordered(SPLGrass.dat$Period, levels=Period.lev)
contrasts(SPLGrass.dat$Period) <- contr.poly(3, scores=Period.lev)
contrasts(SPLGrass.dat$Period)
SPLGrass.aov <- aov(Main.Grass ~ Rows + Columns + Period * Spring * Summer + Error((Rows*Columns)/(SubRows*SubColumns)), SPLGrass.dat, proj=T)
SPLGrass.aov <- aov(Main.Grass ~ Period * Spring * Summer + 
                       Error((Rows*Columns)/(SubRows*SubColumns)), SPLGrass.dat)
summary(SPLGrass.aov)
summary(SPLGrass.aov, split = list(Period = list(L = 1, Q = 2)))
summary(SPLGrass.aov, split = list(Period = list(L = 1, Q = 2),
                                   "Period:Spring" = list(L = 1, Q = 2),
                                   "Period:Summer" = list(L = 1, Q = 2),
                                   "Period:Spring:Summer" = list(L = 1, Q = 2)))

#
# Diagnostic checking
#
tukey.1df(SPLGrass.aov, SPLGrass.dat, "Rows:Columns:SubRows:SubColumns")
res <- resid.errors(SPLGrass.aov)
fit <- fitted.errors(SPLGrass.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
plot(as.numeric(Period), res, pch=16)
plot(as.numeric(Spring), res, pch=16)
plot(as.numeric(Summer), res, pch=16)
interaction.plot(Period, Spring, Main.Grass, lty = c(1,4), lwd = 4)
interaction.plot(Period, Summer, Main.Grass, lty = c(1,4), lwd = 4)
interaction.plot(Spring, Summer, Main.Grass, lty = c(1,4), lwd = 4)
#
# Fitted equation
#
Pe <- as.numeric(as.vector(Period))
SPLGrass.lm <- lm(Main.Grass ~ Spring/Pe)
coef(SPLGrass.lm)
#
# tables of means
#
SPLGrass.means <- model.tables(SPLGrass.aov, type="means")
SPLGrass.means$tables$Summer
SPLGrass.means

