#example comes from Wu and Hamada (2000) ex. 37 p.92
Fac2Drill.dat <- read.csv("Fac2Drill.csv")
Fac2Drill.dat <- data.frame(Run = factor(1:16), Rate = factor(Fac2Drill.dat$rate), 
                            Speed = factor(Fac2Drill.dat$speed), Force = Fac2Drill.dat$force)
attach(Fac2Drill.dat)
Fac2Drill.dat
interaction.plot(Rate, Speed, Force, lwd=4)
interaction.plot(Speed, Rate, Force, lwd=4)
#
# Set up to fit polynomials
#
Rate.lev <- c(0.015, 0.03, 0.045, 0.06)
Fac2Drill.dat$Rate <- ordered(Fac2Drill.dat$Rate, levels=Rate.lev)
contrasts(Fac2Drill.dat$Rate) <- contr.poly(4, scores=Rate.lev)
contrasts(Fac2Drill.dat$Rate)
Speed.lev <- c(125, 200)
Fac2Drill.dat$Speed <- ordered(Fac2Drill.dat$Speed, levels=Speed.lev)
contrasts(Fac2Drill.dat$Speed) <- contr.poly(2, scores=Speed.lev)
contrasts(Fac2Drill.dat$Speed)
Fac2Drill.aov <- aov(Force ~ Rate * Speed + Error(Run), Fac2Drill.dat)
summary(Fac2Drill.aov)
summary(Fac2Drill.aov, split = list(Rate = list(L=1, Q=2, Dev=3), Speed = list(L=1)))
summary(Fac2Drill.aov, split = list(Rate = list(L=1, Dev=2:3), Speed = list(L=1),
                                    "Rate:Speed" = list(L.L=1, Dev.L=2:3)))
#
# Diagnostic checking
#
res <- resid.errors(Fac2Drill.aov)
fit <- fitted.errors(Fac2Drill.aov)
data.frame(Day,Test,Rate,Speed,Force,res,fit)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
tukey.1df(Fac2Drill.aov, Fac2Drill.dat, error.term="Run")
