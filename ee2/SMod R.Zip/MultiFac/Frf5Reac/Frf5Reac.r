#
# set up data frame and analyse
#
mp <- c("-", "+")
fnames <- list(Feed = mp, Catal = mp, Agitation = mp, Temp = mp)
Frf5Reac.Treats <- fac.gen(generate = fnames, order="yates")
attach(Frf5Reac.Treats)
Frf5Reac.Treats$Conc <- factor(mpone(Feed)*mpone(Catal)*mpone(Agitation)*mpone(Temp), labels = mp)
detach(Frf5Reac.Treats)
Frf5Reac.dat <- data.frame(Runs = factor(1:16), Frf5Reac.Treats)
remove("Frf5Reac.Treats")
Frf5Reac.dat$Reacted <- c(56,53,63,65,53,55,67,61,69,45,78,93,49,60,95,82)
Frf5Reac.dat
Frf5Reac.aov <- aov(Reacted ~ Feed * Catal * Agitation * Temp * Conc + Error(Runs), Frf5Reac.dat)
summary(Frf5Reac.aov)
qqnorm.yeffects(Frf5Reac.aov, error.term = "Runs", data=Frf5Reac.dat)
round(yates.effects(Frf5Reac.aov, error.term="Runs", data=Frf5Reac.dat), 2)
Frf5Reac.Fit.aov <- aov(Reacted ~ Temp * (Catal + Conc) + Error(Runs), Frf5Reac.dat)
summary(Frf5Reac.Fit.aov)
#
# Diagnostic checking
#
tukey.1df(Frf5Reac.Fit.aov, Frf5Reac.dat, error.term="Runs")
res <- resid.errors(Frf5Reac.Fit.aov)
fit <- fitted.errors(Frf5Reac.Fit.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
attach(Frf5Reac.dat)
plot(as.numeric(Feed), res, pch=16)
plot(as.numeric(Catal), res, pch=16)
plot(as.numeric(Agitation), res, pch=16)
plot(as.numeric(Temp), res, pch=16)
plot(as.numeric(Conc), res, pch=16)
#
# treatment differences
#
interaction.plot(Temp, Catal, Reacted, lwd=4)
interaction.plot(Temp, Conc, Reacted, lwd=4)
Frf5Reac.means <- model.tables(Frf5Reac.Fit.aov, type="means")
Frf5Reac.means$tables$"Temp:Catal"
Frf5Reac.means$tables$"Temp:Conc"

