#
# produce randomized layout
#
b <- 3
t <- 4
n <- b*t
Standard.Order <- factor(1:n)
Random.Order <- order(rep(runif(b), each=t), runif(n))
RCBD.Fac2Plane.unit <- list(Blocks=b, Run=t)
RCBD.Fac2Plane.nest <- list(Run = "Blocks")
RCBD.Fac2Plane.ran <- fac.gen(list(Model = c("A","B"), Paper = c("L","H")), times = 3)
RCBD.Fac2Plane.lay <- fac.layout(unrandomized = RCBD.Fac2Plane.unit, 
                           nested.factors = RCBD.Fac2Plane.nest,
                           randomized = RCBD.Fac2Plane.ran, seed = 911)
remove("RCBD.Fac2Plane.ran", "RCBD.Fac2Plane.unit", "RCBD.Fac2Plane.nest")
RCBD.Fac2Plane.lay
#
# add data
#
RCBD.Fac2Plane.dat <- RCBD.Fac2Plane.lay
RCBD.Fac2Plane.dat$Time <- c(2.35,2.00,1.86,1.17, 1.45,1.11,0.72,3.12, 1.61,2.34,1.11,1.22)
RCBD.Fac2Plane.dat
# analysis
attach(RCBD.Fac2Plane.dat)
interaction.plot(Model, Paper, Time, lwd=4)
boxplot(split(Time, Model), style.bxp="old", xlab="Model", ylab="Survival time (10 hours)", 
                                                                                medchar=T, medpch=8)
boxplot(split(Time, Paper), style.bxp="old", xlab="Paperment", ylab="Survival time (10 hours)", 
                                                                                medchar=T, medpch=8)
RCBD.Fac2Plane.aov <- aov(Time ~ Blocks + Model * Paper + Error(Blocks/Run), RCBD.Fac2Plane.dat)
summary(RCBD.Fac2Plane.aov)
#Compute Block F and p
Block.F <- 0.091033/0.26566
Block.p <- 1-pf(Block.F, 2, 6)
data.frame(Block.F,Block.p)
#
# Diagnostic checking
#
res <- resid.errors(RCBD.Fac2Plane.aov)
fit <- fitted.errors(RCBD.Fac2Plane.aov)
plot(fit, res, pch=16)
plot(as.numeric(Model), res, pch=16)
plot(as.numeric(Paper), res, pch=16)
qqnorm(res, pch=16)
qqline(res)
tukey.1df(RCBD.Fac2Plane.aov, RCBD.Fac2Plane.dat, error.term="Blocks:Run")
#
# multiple comparisons
#
RCBD.Fac2Plane.NoError.aov <- aov(Time ~ Blocks + Model * Paper, RCBD.Fac2Plane.dat)
RCBD.Fac2Plane.mca <- multicomp(RCBD.Fac2Plane.NoError.aov, focus = "Paper")
RCBD.Fac2Plane.mca
#
# Plotting
#
RCBD.Fac2Plane.tab <- model.tables(RCBD.Fac2Plane.aov, type="means")
RCBD.Fac2Plane.Model.Means <- data.frame(Model = levels(Model), 
                                       Time = as.vector(RCBD.Fac2Plane.tab$tables$Model))
barchart(Time ~ Model, ylim=c(0,2.5), xlab="Plane model", 
         ylab="Time (secs)", data=RCBD.Fac2Plane.Model.Means)
RCBD.Fac2Plane.Paper.Means <- data.frame(Paper = levels(Paper), 
                                       Time = as.vector(RCBD.Fac2Plane.tab$tables$Paper))
barchart(Time ~ Paper, ylim=c(0,2.5), xlab="Paper type", 
         ylab="Time (secs)", data=RCBD.Fac2Plane.Paper.Means)

s.e.d <- sqrt(0.26566*2/6)
s.e.d