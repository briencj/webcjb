#
# set up data frame
#
mp <- c("-", "+")
fnames <- list(A = mp, B = mp, C = mp, D = mp)
Frf8SimC.Treats <- fac.gen(generate = fnames, order = "yates")
attach(Frf8SimC.Treats)
Frf8SimC.Treats$E <- factor(mpone(A)*mpone(B)*mpone(C), labels = mp)
Frf8SimC.Treats$FF <- factor(mpone(A)*mpone(B)*mpone(D), labels = mp)
Frf8SimC.Treats$G <- factor(mpone(A)*mpone(C)*mpone(D), labels = mp)
Frf8SimC.Treats$H <- factor(mpone(B)*mpone(C)*mpone(D), labels = mp)
detach(Frf8SimC.Treats)
Frf8SimC.dat <- data.frame(Runs = factor(1:16), Frf8SimC.Treats)
remove("Frf8SimC.Treats")
Frf8SimC.dat$Time <- c(65.81,58.49,62.51,60.19,60.22,59.20,66.58,61.68,59.01,53.71,62.43,60.77,
60.44,57.48,63.08,58.32)
Frf8SimC.dat
#
# analyse
#
Frf8SimC.aov <- aov(Time ~ (A + B + C + D + E + FF + G + H)^2 + Error(Runs), Frf8SimC.dat)
summary(Frf8SimC.aov)
qqnorm.yeffects(Frf8SimC.aov, error.term = "Runs", data=Frf8SimC.dat)
round(yates.effects(Frf8SimC.aov, error.term="Runs", data=Frf8SimC.dat), 2)
Frf8SimC.Fit.aov <- aov(Time ~ A*FF + B + D + E + H + Error(Runs), Frf8SimC.dat)
summary(Frf8SimC.Fit.aov)
Frf8SimC.Fit.aov <- aov(Time ~ A + B + D + E + H + Error(Runs), Frf8SimC.dat)
summary(Frf8SimC.Fit.aov)
#
# Diagnostic checking
#
tukey.1df(Frf8SimC.Fit.aov, data=Frf8SimC.dat, error.term="Runs")
res <- resid.errors(Frf8SimC.Fit.aov)
fit <- fitted.errors(Frf8SimC.Fit.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
attach(Frf8SimC.dat)
plot(as.numeric(A), res, pch=16)
plot(as.numeric(B), res, pch=16)
plot(as.numeric(C), res, pch=16)
plot(as.numeric(D), res, pch=16)
plot(as.numeric(E), res, pch=16)
plot(as.numeric(FF), res, pch=16)
plot(as.numeric(G), res, pch=16)
plot(as.numeric(H), res, pch=16)
#
# treatment differences
#
Frf8SimC.means <- model.tables(Frf8SimC.Fit.aov, type="means")
Frf8SimC.means$tables$"B"
Frf8SimC.means$tables$"C"

