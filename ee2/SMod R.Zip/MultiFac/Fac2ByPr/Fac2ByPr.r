library(dae)
load("Fac2ByPr.dat.rda")
attach(Fac2ByPr.dat)
Fac2ByPr.dat
interaction.ABC.plot(Yield, Catalyst, Pressure, Labs, data=Fac2ByPr.dat, 
                     title="Effect of Catalyst, Pressure and Labs on Yield")
Fac2ByPr.aov <- aov(Yield ~ Catalyst * Pressure * Labs + Error(Labs/Runs), Fac2ByPr.dat)
summary(Fac2ByPr.aov)
#Compute Labs F and p
Labs.F <- 12.042/550.8
Labs.p <- 1-pf(Labs.F, 1, 16)
data.frame(Labs.F,Labs.p)
Fac2ByPr.NoError.aov <- aov(Yield ~ Catalyst * Pressure * Labs , Fac2ByPr.dat)
#
# Diagnostic checking
#
res <- resid.errors(Fac2ByPr.aov)
fit <- fitted.errors(Fac2ByPr.aov)
data.frame(Labs,Runs,Catalyst,Pressure,Yield,res,fit)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
plot(as.numeric(Labs), res, pch = 16)
plot(as.numeric(Catalyst), res, pch = 16)
plot(as.numeric(Pressure), res, pch = 16)
tukey.1df(Fac2ByPr.aov, Fac2ByPr.dat, error.term="Labs:Runs")


# use Data > Restructure > Unstack to put data for labs 1 and 2 
# into separate columns in a new data.frame, say Fac2ByPr.Labs.dat
attach(Fac2ByPr.Labs.dat)
interaction.plot(X1.Catalyst, X1.Pressure, X1.Yield, lwd=4)
interaction.plot(X2.Catalyst, X2.Pressure, X2.Yield, lwd=4)
#this interaction plot not used because cannot make the lines thicker - lwd not a legal argument
menuInteractionPlot(data = Fac2ByPr.dat, dependent = "Yield", independent = "Labs,Pressure,Catalyst", 
   na.rm = T, both.var.orders = F, fun = mean, rows = 2, columns = 2)
