load("Fac2Pois.dat.rda")
Fac2Pois.dat <- fac.gen(generate = list(Poison = 3, 4, Treat=4))
Fac2Pois.dat <- data.frame(Animals = factor(1:48), Fac2Pois.dat)
Fac2Pois.dat$Surv.Time <-
                  c(0.31,0.82,0.43,0.45,0.45,1.10,0.45,0.71,0.46,0.88,0.63,0.66,
                    0.43,0.72,0.76,0.62,0.36,0.92,0.44,0.56,0.29,0.61,0.35,1.02,
                    0.40,0.49,0.31,0.71,0.23,1.24,0.40,0.38,0.22,0.30,0.23,0.30,
                    0.21,0.37,0.25,0.36,0.18,0.38,0.24,0.31,0.23,0.29,0.22,0.33)
attach(Fac2Pois.dat)
Fac2Pois.dat
interaction.plot(Poison, Treat, Surv.Time, lwd=4)
boxplot(split(Surv.Time, Poison), xlab="Poison", ylab="Survival time (10 hours)")
boxplot(split(Surv.Time, Treat), xlab="Treatment", ylab="Survival time (10 hours)")
Fac2Pois.aov <- aov(Surv.Time ~ Poison * Treat + Error(Animals), Fac2Pois.dat)
summary(Fac2Pois.aov)
#
# Diagnostic checking
#
res <- resid.errors(Fac2Pois.aov)
fit <- fitted.errors(Fac2Pois.aov)
data.frame(Animals,Poison,Treat,Surv.Time,res,fit)
plot(fit, res, pch=16)
plot(as.numeric(Poison), res, pch=16)
plot(as.numeric(Treat), res, pch=16)
qqnorm(res, pch=16)
qqline(res)
Fac2Pois.NoError.aov <- aov(Surv.Time ~ Poison * Treat, Fac2Pois.dat)
library(MASS)
boxcox(Fac2Pois.NoError.aov, lambda=seq(from = -2.5, to = 2.5, len=20), plotit=T)
#
# re-analysis
#
detach(Fac2Pois.dat)
Fac2Pois.dat$Death.Rate <- 1/Fac2Pois.dat$Surv.Time
attach(Fac2Pois.dat)
interaction.plot(Poison, Treat, Death.Rate, lwd=4)
Fac2Pois.DR.aov <- aov(Death.Rate ~ Poison * Treat + Error(Animals), Fac2Pois.dat)
summary(Fac2Pois.DR.aov)
res <- resid.errors(Fac2Pois.DR.aov)
fit <- fitted.errors(Fac2Pois.DR.aov)
plot(fit, res, pch=16)
plot(as.numeric(Poison), res, pch=16)
plot(as.numeric(Treat), res, pch=16)
qqnorm(res, pch=16)
qqline(res)
#
# multiple comparisons
#
model.tables(Fac2Pois.DR.aov, type="means")
q.PT <- qtukey(0.95, 12, 36)
q.PT
q.P <- qtukey(0.95, 3, 36)
q.P
q.T <- qtukey(0.95, 4, 36)
q.T
#
# Plotting means
#
Fac2Pois.DR.tab <- model.tables(Fac2Pois.DR.aov, type="means")
Fac2Pois.DR.Poison.Means <- 
              data.frame(Poison = levels(Poison), 
                         Death.Rate = as.vector(Fac2Pois.DR.tab$tables$Poison))
barchart(Death.Rate ~ Poison, main="Fitted values for Death rate", ylim=c(0,4), 
              data=Fac2Pois.DR.Poison.Means)
Fac2Pois.DR.Treat.Means <- 
              data.frame(Treatment = levels(Treat), 
                         Death.Rate = as.vector(Fac2Pois.DR.tab$tables$Treat))
barchart(Death.Rate ~ Treat, main="Fitted values for Death rate", ylim=c(0,4), 
              data=Fac2Pois.DR.Treat.Means)
