Fac2Anode.dat <- read.csv("Fac2Anode.dat.csv", colClasses = c(rep("factor", 3), "numeric"))
save(Fac2Anode.dat, file="Fac2Anode.dat.rda")
attach(Fac2Anode.dat)
Fac2Anode.dat
load(file="Fac2Anode.dat.rda")
attach(Fac2Anode.dat)
interaction.plot(Temp, Position, Density, lwd=4)
#
# Set up to fit polynomials
#
Temp.lev <- c(800, 825, 850)
Fac2Anode.dat$Temp <- ordered(Fac2Anode.dat$Temp, levels=Temp.lev)
contrasts(Fac2Anode.dat$Temp) <- contr.poly(3, scores=Temp.lev)
Fac2Anode.aov <- aov(Density ~ Position * Temp + Error(Run), Fac2Anode.dat)
summary(Fac2Anode.aov)
summary(Fac2Anode.aov, split = list(Temp = list(L = 1, Q = 2)))
summary(Fac2Anode.aov, split = list(Temp = list(L = 1, Q = 2), 
                                    "Position:Temp" = list(L = 1, Q = 2)))
#
# Diagnostic checking
#
res <- resid.errors(Fac2Anode.aov)
fit <- fitted.errors(Fac2Anode.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
plot(as.numeric(Position), res, pch = 16)
plot(as.numeric(Temp), res, pch = 16)
#
# get fitted equation using power terms
#
Te <- as.numeric(as.vector(Temp))
Te2 <- Te * Te
Fac2Anode.lm <- lm(Density ~ Te + Te2)
Fac2Anode.lm <- lm(Density ~ -1 + Position + Te + Te2)
coef(Fac2Anode.lm)
