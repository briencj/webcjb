load("SPLPigm.dat.rda")
attach(SPLPigm.dat)
SPLPigm.dat
interaction.plot(Mill, Time, Reflect, lwd=4, lty = c(1,4), lwd=4)
interaction.plot(Mill, Time, Reflect, lwd=4)
SPLPigm.aov <- aov(Reflect ~ Liquid + Mill * Time + 
                   Error(Liquid/Solution/HalfSoln), SPLPigm.dat)
summary(SPLPigm.aov)
#
# Diagnostic checking
#
tukey.1df(SPLPigm.aov, SPLPigm.dat, "Liquid:Solution:HalfSoln")
res <- resid.errors(SPLPigm.aov)
fit <- fitted.errors(SPLPigm.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
plot(as.numeric(Mill), res, pch=16)
plot(as.numeric(Time), res, pch=16)
#
# tables of means
#
SPLPigm.means <- model.tables(SPLPigm.aov, type="means")
SPLPigm.means
qtukey(0.95, 4, 9)
qtukey(0.95, 4, 9) / sqrt(2) * 0.18447
#
# analysis with Liquid interactions
#
SPLPigm.Liq.aov <- aov(Reflect ~ Mill * Time * Liquid + Error(Liquid/Solution/HalfSoln), 
                        SPLPigm.dat)
summary(SPLPigm.Liq.aov)

