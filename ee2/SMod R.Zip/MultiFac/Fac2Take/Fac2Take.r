library(dae)
load("Fac2Take.dat.rda")
attach(Fac2Take.dat)
Fac2Take.dat
interaction.plot(A, B, Take, lwd=4)
boxplot(split(Take, A), xlab="A", ylab="Take")
boxplot(split(Take, B), xlab="B", ylab="Take"8)
Fac2Take.aov <- aov(Take ~ Blocks + A * B + Error(Blocks/Plots), Fac2Take.dat)
summary(Fac2Take.aov)
#
# recompute for missing value
#
MSq <- c(73.729, 4795.6, 1387.6, 1139.1, 2.8797)
Res <- c(rep(819.6/8, 4), 816.6828/7)
df.num <- c(3,rep(1,4))
df.den <- c(rep(8, 4),7)
Fvalue <- MSq/Res
pvalue <- 1-pf(Fvalue, df.num, df.den)
data.frame(MSq,Res,df.num,df.den,Fvalue,pvalue)
#
# Diagnostic checking
#
res <- resid.errors(Fac2Take.aov)
fit <- fitted.errors(Fac2Take.aov)
data.frame(Blocks,Plots,A,B,Take,res,fit)
plot(fit, res, pch=16)
plot(as.numeric(A), res, pch=16)
plot(as.numeric(B), res, pch=16)
qqnorm(res, pch=16)
qqline(res)
tukey.1df(Fac2Take.aov, Fac2Take.dat, error.term = "Blocks:Plots")
#
# multiple comparisons
#
Fac2Take.tab <- model.tables(Fac2Take.aov, type="means")
Fac2Take.tab$tables$"A:B"
q <- qtukey(0.95, 4, 8)
q
#
# reanalysis for one-cell interaction model
#
Fac2Take.dat$Cell.1.1 <- factor(1 + as.numeric(A != "1" | B != "1"))
Fac2Take.dat$Treats <- fac.combine(list(A, B))
detach(Fac2Take.dat)
attach(Fac2Take.dat)
Fac2Take.dat
Fac2Take.aov <- aov(Take ~ Blocks + Cell.1.1/Treats + Error(Blocks/Plots), Fac2Take.dat)
summary(Fac2Take.aov)
#
# recompute for missing value
#
MSq <- c(73.729,6556.7,382.8)
Res <- rep(819.6/8, 3)
df.num <- c(3, 1, 2)
Fvalue <- MSq/Res
pvalue <- 1-pf(Fvalue, df.num, 8)
data.frame(MSq,Res,df.num,Fvalue,pvalue)

