#install.packages(repos=NULL, pkgs="path\\dae_0.1-1.zip")
install.packages(repos=NULL, pkgs="C:\\clarice\\Chris\\Course2007\\R-prog\\dae_0.1-1.zip")
# in R change directory to path
library(dae)

#
# CRD
#
n <- 18
CRDFac2.unit <- list(Seedling = n)
CRDFac2.ran <- fac.gen(list(N = c(0, 30, 60), P = c(0, 20)), times = 3)
CRDFac2.lay <- fac.layout(unrandomized = CRDFac2.unit, 
                          randomized = CRDFac2.ran, seed = 105)
remove("CRDFac2.ran")
CRDFac2.lay  #use the last three columns to give to the scientist

#
# RCBD
#
b <- 3
t <- 6
n <- b*t
RCBDFac2.unit <- list(Blocks=b, Seedling=t)
RCBDFac2.nest <- list(Seedling = "Blocks")
RCBDFac2.ran <- fac.gen(list(N = c(0, 30, 60), P = c(0, 20)), times = 3)
RCBDFac2.lay <- fac.layout(unrandomized = RCBDFac2.unit, 
                           nested.factors = RCBDFac2.nest,
                           randomized = RCBDFac2.ran, seed = 555)
remove("RCBDFac2.ran", "RCBDFac2.unit", "RCBDFac2.nest")
RCBDFac2.lay

#
# LS
#
t <- 6
n <- t*t
Treats <- c(1,2,3,4,5,6, 2,1,6,5,3,4, 3,6,2,1,4,5, 
                  4,3,5,2,6,1, 5,4,1,6,2,3, 6,5,4,3,1,2)
LSFac2.ran <- fac.divide(Treats, list(N=c(0,30,60), P=c(0, 20)))
LSFac2.unit <- list(Rows=t, Columns=t)
LSFac2.lay <- fac.layout(unrandomized = LSFac2.unit, 
                         randomized = LSFac2.ran, seed = 559)
remove("Treats", "LSFac2.unit", "LSFac2.ran")
LSFac2.lay
#
# sample size
#
no.reps(multiple=1, df.num=2, df.denom=expression(5*(r-1)), delta=10, sigma=7.5, power=0.80)
