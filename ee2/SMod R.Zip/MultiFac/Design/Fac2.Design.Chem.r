#
# sample size
#
no.reps(multiple=3, df.num=3, df.denom=expression(12*(r-1)), delta=0.25, sigma=0.1, power=0.9)
rm <- 3
power.exp(rm=rm, df.num=6, df.denom=12*(rm-1), delta=0.25, sigma=0.1)
no.reps(multiple=1, df.num=6, df.denom=expression(12*(r-1)), delta=0.25, sigma=0.1, power=0.9)
#
# CRD
#
n <- 84
fnames <- list(Temperature = 1:4, Pressure = 1:3)
CRDFac2.Chem.ran <- fac.gen(generate = fnames, times = 7)
CRDFac2.Chem.unit <- list(Run = n)
CRDFac2.Chem.lay <- fac.layout(unrandomized = CRDFac2.Chem.unit, 
                               randomized = CRDFac2.Chem.ran, 
                               seed = 312)
CRDFac2.Chem.lay

