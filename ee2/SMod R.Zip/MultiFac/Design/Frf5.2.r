#
# set up randomized factors
#
mp <- c("-", "+")
Frf5.2.ran <- fac.gen(generate = list(A = mp, B = mp, C = mp), order="yates")
attach(Frf5.2.ran)
Frf5.2.ran$D <- factor(mpone(A)*mpone(B), labels = mp)
Frf5.2.ran$E <- factor(mpone(A)*mpone(C), labels = mp)
detach(Frf5.2.ran)
#
# randomize
#
n <- 8
Frf5.2.unit <- list(Runs = n)
Frf5.2.lay <- fac.layout(unrandomized = Frf5.2.unit, randomized = Frf5.2.ran,
                         seed = 124)
Frf5.2.lay

