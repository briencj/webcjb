library(dae)
#
# standard split-plot
#
# set up treatment factors
#
r <- 4
a <- 3
b <- 3
fnames <- list(Sources = c("A","B","C"), Methods = c(1:a))
SPLProd.Treats <- fac.gen(levels = c(b,a), factor.names = fnames, 
                           replications = r, order="yates")
#
# randomize
#
set.seed(1025)
n <- r*a*b
Standard.Order <- factor(1:n)
Random.Order <- order(rep(runif(r), each=a*b), 
                      rep(runif(r*a), each=b), 
                      runif(n))
SPLProd.Design <- fac.divide(Random.Order, 
                             factor.names=list(Factories=r, Areas=c("I","II","III"), Parts=b))
SPLProd.Design <- data.frame(Standard.Order, Random.Order, SPLProd.Design, SPLProd.Treats)
remove("Standard.Order", "Random.Order", "SPLProd.Treats")
SPLProd.Design[SPLProd.Design$"Random.Order",] <- SPLProd.Design
SPLProd.Design
SpLProd <- SPLProd.Design