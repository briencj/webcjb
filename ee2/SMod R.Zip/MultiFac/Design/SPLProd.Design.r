#
# standard split-plot
#
r <- 4
a <- 3
b <- 3
fnames <- list(Methods = c(1:a), Sources = c("A","B","C"))
SPLProd.ran <- fac.gen(generate = fnames, times = r)
SPLProd.unit <- list(Factories=r, Areas=c("I","II","III"), Parts=b)
SPLProd.nest <- list(Areas = "Factories", Parts = c("Factories", "Areas"))
SPLProd.lay <- fac.layout(unrandomized = SPLProd.unit, 
                          nested.factors = SPLProd.nest, 
                          randomized = SPLProd.ran, seed = 1025)
SPLProd.lay

