#
# 3 factors in two blocks
#
# set up treatment factors
#
mp <- c("-", "+")
Fac3Conf.2Blocks.ran <- fac.gen(generate = list(A = mp, B = mp, C = mp), order="yates")
attach(Fac3Conf.2Blocks.ran)
Blocks <- factor(mpone(A)*mpone(B)*mpone(C), labels=c("1", "2"))
detach(Fac3Conf.2Blocks.ran)
Fac3Conf.2Blocks.ran <- Fac3Conf.2Blocks.ran[order(Blocks),]
remove("Blocks")
#
# randomize
#
b <- 2
m <- 4
n <- b*m
Fac3Conf.2Blocks.nest <- list(Runs = "Blocks")
Fac3Conf.2Blocks.unit <- list(Blocks=b, Runs=m)
Fac3Conf.2Blocks.lay <- fac.layout(unrandomized = Fac3Conf.2Blocks.unit,
                                   nested.factors = Fac3Conf.2Blocks.nest,
                                   randomized = Fac3Conf.2Blocks.ran, seed = 395)
Fac3Conf.2Blocks.lay
#
# repeats of 3 factors in two blocks
#
#
# set up treatment factors
#
mp <- c("-", "+")
Fac3Conf.2Blocks.Reps.ran <- fac.gen(generate = list(A = mp, B = mp, C = mp), 
                                     times = 2, order="yates")
attach(Fac3Conf.2Blocks.Reps.ran)
Reps = factor(rep(1:2, each=8))
Blocks <- factor(mpone(A)*mpone(B)*mpone(C), labels=c("1", "2"))
detach(Fac3Conf.2Blocks.Reps.ran)
Fac3Conf.2Blocks.Reps.ran <- Fac3Conf.2Blocks.Reps.ran[order(Reps, Blocks),]
remove("Reps","Blocks")
#
# randomize
#
set.seed(911)
b <- 4
m <- 4
n <- b * m
Fac3Conf.2Blocks.Reps.nest <- list(Runs = "Blocks")
Fac3Conf.2Blocks.Reps.unit <- list(Blocks=b, Runs=m)
Fac3Conf.2Blocks.Reps.lay <- fac.layout(unrandomized = Fac3Conf.2Blocks.Reps.unit,
                                 nested.factors = Fac3Conf.2Blocks.Reps.nest,
                                 randomized = Fac3Conf.2Blocks.Reps.ran, seed = 911)
Fac3Conf.2Blocks.Reps.lay
#
# repeats of 3 factors in four blocks
#
#
# set up treatment factors
#
Fac3Conf.4Blocks.Reps.ran <- fac.gen(generate = list(A = mp, B = mp, C = mp), 
                                     times = 2, order="yates")
attach(Fac3Conf.4Blocks.Reps.ran)
Reps = factor(rep(1:2, each=8))
B1 <- factor(mpone(A)*mpone(B), labels=c("1", "2"))
B2 <- factor(mpone(A)*mpone(C), labels=c("1", "2"))
Blocks <- fac.combine(list(B1,B2))
detach(Fac3Conf.4Blocks.Reps.ran)
Fac3Conf.4Blocks.Reps.ran <- Fac3Conf.4Blocks.Reps.ran[order(Reps,Blocks),]
remove("Reps","B1", "B2", "Blocks")
#
# randomize
#
set.seed(111)
b <- 8
m <- 2
n <- b*m
Fac3Conf.4Blocks.Reps.nest <- list(Runs = "Blocks")
Fac3Conf.4Blocks.Reps.unit <- list(Blocks=b, Runs=m)
Fac3Conf.4Blocks.Reps.lay <- fac.layout(unrandomized = Fac3Conf.4Blocks.Reps.unit,
                                        nested.factors = Fac3Conf.4Blocks.Reps.nest,
                                        randomized = Fac3Conf.4Blocks.Reps.ran, 
                                        seed = 111)
Fac3Conf.4Blocks.Reps.lay



