#
# split-plot
#
r <- 3
a <- 6
b <- 4
n <- r*a*b
fnames <- list(Propogation = 1:3, Nutrient = 1:2, Harvests = 1:b)
SPLCeler.ran <- fac.gen(generate = fnames, times = r)
Random.Order <- order(rep(runif(r*a), each=b), runif(n))
SPLCeler.unit <- list(MainPlots=r*a, Subplots=b)
SPLCeler.nest <- list(Subplots = "MainPlots")
SPLCeler.lay <- fac.layout(unrandomized = SPLCeler.unit, 
                           nested.factors = SPLCeler.nest, 
                           randomized = SPLCeler.ran, seed = 445)
SPLCeler.lay

