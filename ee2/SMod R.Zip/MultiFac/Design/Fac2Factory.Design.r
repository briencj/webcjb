b <- 3
t <- 8
n <- b*t
Fac2Factory.unit <- list(Factories=b, Tests=t)
Fac2Factory.nest <- list(Tests = "Factories")
Fac2Factory.ran <- fac.gen(list(Lots = 3, Portions = 4, Methods = 2))
Fac2Factory.lay <- fac.layout(unrandomized = Fac2Factory.unit,
                              nested.factors = Fac2Factory.nest,
                              randomized = Fac2Factory.ran, seed = 1015)
Fac2Factory.lay
# add a column y with random normal data and analyze
Fac2Factory.dat <- Fac2Factory.lay
Fac2Factory.dat$y <- rnorm(n)
Fac2Factory.aov <- aov(y ~ (Lots/Portions)*Methods + Error(Factories/Tests), Fac2Factory.dat)
summary(Fac2Factory.aov)

