#
# Unreplicated two-level factorial
#
n <- 8
mp <- c("-", "+")
Fac3.2Level.Unrep.ran <- fac.gen(list(A = mp, B = mp, C = mp), order="yates")
Fac3.2Level.Unrep.unit <- list(Runs = n)
Fac3.2Level.Unrep.lay <- fac.layout(unrandomized = Fac3.2Level.Unrep.unit,
                                    randomized = Fac3.2Level.Unrep.ran, seed=333)
remove("Fac3.2Level.Unrep.ran")
Fac3.2Level.Unrep.lay

