#install.packages(repos=NULL, pkgs="path\\dae_0.1-1.zip")
install.packages(repos=NULL, pkgs="C:\\clarice\\Chris\\Course2007\\R-prog\\dae_0.1-1.zip")

library(dae)

#
# CRD
#
# set up treatment factors
#
fnames <- list(N = c(0, 30, 60), P = c(0, 20))
CRDFac2.Treats <- fac.gen(levels = c(3, 2), factor.names = fnames,replications = 3,order= "yates")
#
# randomize
#
set.seed(105)
n <- 18
Standard.Order <- factor(1:n)
Seedling <- order(runif(n))
CRDFac2.Design <- data.frame(Standard.Order, Seedling, CRDFac2.Treats)
remove("Standard.Order", "Seedling", "CRDFac2.Treats")
CRDFac2.Design[CRDFac2.Design$"Seedling",] <- CRDFac2.Design
CRDFac2.Design  #use the last three columns to give to the scientist