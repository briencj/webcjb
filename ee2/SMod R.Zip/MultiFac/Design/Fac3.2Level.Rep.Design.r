#
# Replicated two-level factorial
#
n <- 16
mp <- c("-", "+")
Fac3.2Level.Rep.ran <- fac.gen(generate = list(Te = mp, C = mp, K = mp), each = 2, 
                         order="yates")
Fac3.2Level.Rep.unit <- list(Runs = n)
Fac3.2Level.Rep.lay <- fac.layout(unrandomized = Fac3.2Level.Rep.unit, 
                            randomized = Fac3.2Level.Rep.ran, seed = 625)
Fac3.2Level.Rep.lay


