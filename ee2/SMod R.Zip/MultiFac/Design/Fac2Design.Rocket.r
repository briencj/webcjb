b <- 5
t <- 9
n <- b*t
Fac2Rocket.unit <- list(Days=b, Firing=t)
Fac2Rocket.nest <- list(Firing = "Days")
Fac2Rocket.ran <- fac.gen(list(Temp = 3, SRange = 3), times = b)
Fac2Rocket.lay <- fac.layout(unrandomized = Fac2Rocket.unit,
                           nested.factors = Fac2Rocket.nest,
                           randomized = Fac2Rocket.ran, seed = 725)
remove("Fac2Rocket.ran", "Fac2Rocket.unit", "Fac2Rocket.nest")
Fac2Rocket.lay
