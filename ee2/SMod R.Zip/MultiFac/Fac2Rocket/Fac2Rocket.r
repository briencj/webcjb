Fac2Rocket.dat <- fac.gen(generate=list(Days=3, Volley=9, Rocket=3))
Fac2Rocket.Treat <- fac.gen(generate=list(Temp=3, SRange=3), each=3, times=3)
Fac2Rocket.dat <- data.frame(Fac2Rocket.dat, Fac2Rocket.Treat)
Fac2Rocket.dat$Error <- c(-10,-13,14,-15,-17,7,-21,-23,0,
                          -5,-9,21,-14,15,-11,-18,5,-10,
                          11,-5,22,-9,-3,20,13,-9,13,
                          -22,0,-5,-25,-5,-11,-26,-8,-10,
                          -17,6,0,-3,-1,-20,-8,5,-10,
                          -10,10,6,8,-2,-15,-5,-18,-3,
                          -9,7,12,-15,2,5,-15,-5,0,
                          -4,13,20,14,5,-10,0,-13,3,
                          1,20,24,14,18,-2,-8,3,12)
Fac2Rocket.aov <- aov(Error ~ Temp*SRange + Error(Days/Volley/Rocket), Fac2Rocket.dat)
summary(Fac2Rocket.aov)

attach(Fac2Rocket.dat)
Fac2Rocket.mean.dat <- fac.gen(generate=list(Days=3, Volley=9))
Fac2Rocket.mean.Treat <- fac.gen(generate=list(Temp=3, SRange=3), times=3)
Error.mean <- as.vector(tapply(Error, list(Days, Volley), mean))
Fac2Rocket.mean.dat <- data.frame(Fac2Rocket.mean.dat, Fac2Rocket.mean.Treat,
                                  Error= Error.mean)
Fac2Rocket.mean.aov <- aov(Error ~ Temp*SRange + Error(Days/Volley), Fac2Rocket.mean.dat)
summary(Fac2Rocket.mean.aov)
model.tables((Fac2Rocket.mean.aov), type="means")