#see ssc file for how data frame constructed
load("Frf8Heli.2003.dat.rda")
Frf8Heli.2003.dat
#
# analyse
#
Frf8Heli.2003.aov <- aov(Time ~ (Paper.Type + Wing.Length + Body.Length + Body.Width 
                            + Clip + Fold + Body.Tape + Wing.Tape)^2 + Error(Runs), Frf8Heli.2003.dat)
Frf8Heli.2003.aov <- aov(Time.Giang ~ (Paper.Type + Wing.Length + Body.Length + Body.Width 
                            + Clip + Fold + Body.Tape + Wing.Tape)^2 + Error(Runs), Frf8Heli.2003.dat)
Frf8Heli.2003.aov <- aov(Time.Allen ~ (Paper.Type + Wing.Length + Body.Length + Body.Width 
                            + Clip + Fold + Body.Tape + Wing.Tape)^2 + Error(Runs), Frf8Heli.2003.dat)
summary(Frf8Heli.2003.aov)
qqnorm.yeffects(Frf8Heli.2003.aov, error.term = "Runs", data=Frf8Heli.2003.dat)
round(yates.effects(Frf8Heli.2003.aov, error.term="Runs", data=Frf8Heli.2003.dat), 2)
Frf8Heli.2003.Fit.aov <- aov(Time ~ Paper.Type+Wing.Tape + Error(Runs), 
                                                              Frf8Heli.2003.dat)
summary(Frf8Heli.2003.Fit.aov)
#
# Diagnostic checking
#
tukey.1df(Frf8Heli.2003.Fit.aov, data = Frf8Heli.2003.dat, error.term="Runs")
res <- resid.errors(Frf8Heli.2003.Fit.aov)
fit <- fitted.errors(Frf8Heli.2003.Fit.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
attach(Frf8Heli.2003.dat)
plot(as.numeric(Paper.Type), res, pch=16)
plot(as.numeric(Wing.Length), res, pch=16)
plot(as.numeric(Body.Length), res, pch=16)
plot(as.numeric(Body.Width), res, pch=16)
plot(as.numeric(Clip), res, pch=16)
plot(as.numeric(Fold), res, pch=16)
plot(as.numeric(Body.Tape), res, pch=16)
plot(as.numeric(Wing.Tape), res, pch=16)
#
# treatment differences
#
Frf8Heli.2003.means <- model.tables(Frf8Heli.2003.Fit.aov, type="means")
Frf8Heli.2003.means$tables$"Grand mean"
Frf8Heli.2003.means$tables$"Paper.Type"
Frf8Heli.2003.means$tables$"Wing.Tape"


interaction.plot(Paper.Type, Fold, Time)
interaction.plot(Paper.Type, Wing.Tape, Time)
interaction.plot(Paper.Type, Body.Length, Time)
Frf8Heli.2003.means <- model.tables(Frf8Heli.2003.Fit.NoError.aov, type="means")
Frf8Heli.2003.means$tables$"Grand mean"
Frf8Heli.2003.means$tables$"Paper.Type:Fold"
Frf8Heli.2003.means$tables$"Paper.Type:Wing.Tape"
Frf8Heli.2003.dat$PaperFold <- fac.combine(list(Paper.Type,Fold))
Frf8Heli.2003.dat$PaperWingT <- fac.combine(list(Paper.Type,Wing.Tape))
attach(Frf8Heli.2003.dat)
Frf8Heli.2003.dat
Frf8Heli.2003.Fit.NoError.aov <- aov(Time ~ PaperFold + PaperWingT + Body.Length + Wing.Length, Frf8Heli.2003.dat)
Frf8Heli.2003.Fit.NoError.aov <- aov(Time ~ PaperFold + PaperWingT, Frf8Heli.2003.dat)
summary(Frf8Heli.2003.Fit.NoError.aov)
Frf8Heli.2003.PaperFold.mca <- multicomp(Frf8Heli.2003.Fit.NoError.aov, focus = "PaperFold")
Frf8Heli.2003.PaperFold.mca
Frf8Heli.2003.PaperWingT.mca <- multicomp(Frf8Heli.2003.Fit.NoError.aov, focus = "PaperWingT")
Frf8Heli.2003.PaperWingT.mca
Frf8Heli.2003.PaperBodyLen.mca <- multicomp(Frf8Heli.2003.Fit.NoError.aov, focus = "PaperBodyLen")
Frf8Heli.2003.PaperBodyLen.mca
#
# Analyze time recorder diffs
#
Frf8Heli.2003.Recorders.dat <- rbind(Frf8Heli.2003.dat, Frf8Heli.2003.dat)
Frf8Heli.2003.Recorders.aov <- aov(Time ~ (Paper.Type + Wing.Length + Body.Length + Body.Width 
                            + Clip + Fold + Body.Tape + Wing.Tape)^2*Recorder + Error(Runs*Recorder), Frf8Heli.2003.Recorders.dat)
summary(Frf8Heli.2003.Recorders.aov)
qqnorm(Frf8Heli.2003.Recorders.aov$Runs, label=T, omit=16:36, pch=16)
qqnorm(Frf8Heli.2003.Recorders.aov$"Runs:Recorder", label=T, omit=16:36, pch=16)
Frf8Heli.2003.Fit.Recorders.aov <- aov(Time ~ (Paper.Type * Fold + Wing.Tape)*Recorder + Error(Runs*Recorder), 
                                             Frf8Heli.2003.Recorders.dat)
summary(Frf8Heli.2003.Fit.Recorders.aov)
