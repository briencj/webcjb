set.seed(2003)
Frf8Heli.Treats <- Frf8Heli.lay
save(Frf8Heli.Treats, file="Frf8Heli.Treats.rda")
load("Frf8Heli.Treats.rda")
Frf8Heli.Treats
Frf8Heli.unit <- list(Runs = 16)
Frf8Heli.lay <- fac.layout(unrandomized = Frf8Heli.unit, 
                           randomized = Frf8Heli.Treats, seed = 2003)
Frf8Heli.lay


