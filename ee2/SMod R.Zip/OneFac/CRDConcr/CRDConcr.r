CRDConcr.dat <- data.frame(Strength = 
                            c(1690,1550,1625,1725,1530,1580,1445,1450,1550,1545,
                              1745,1645,1510,1430,1565,1685,1545,1527,1445,1520))
save(CRDConcr.dat, file="CRDConcr.dat.rda")
#add factors Batch and Coal.Percent to data frame
load("CRDConcr.dat.rda")
CRDConcr.dat$Batch <- factor(1:20)
CRDConcr.dat$Coal.Percent <- factor(rep(c(0,0.05,0.1,0.5,1), times=4))
attach(CRDConcr.dat)
CRDConcr.dat
#
# initial analysis
#
library(dae)
boxplot(split(Strength, Coal.Percent), xlab="Coal Percentage", ylab="Strength")
CRDConcr.aov <- aov(Strength ~ Coal.Percent, CRDConcr.dat)
CRDConcr.aov <- aov(Strength ~ Coal.Percent + Error(Batch), CRDConcr.dat)
summary(CRDConcr.aov)
#
# plots for diagnostic checking
#
res <- resid.errors(CRDConcr.aov)
fit <- fitted.errors(CRDConcr.aov)
plot(fit, res, pch = 16)
qqnorm(res, pch = 16)
qqline(res)
#
# fit polynomials
#
t <- 5
Coal.Percent.lev <- c(0,0.05,0.1,0.5,1)
CRDConcr.dat$Coal.Percent <- ordered(CRDConcr.dat$Coal.Percent, levels=Coal.Percent.lev)
contrasts(CRDConcr.dat$Coal.Percent) <- contr.poly(t, scores=Coal.Percent.lev)
contrasts(CRDConcr.dat$Coal.Percent)
CRDConcr.aov <- aov(Strength ~ Coal.Percent + Error(Batch), CRDConcr.dat)
summary(CRDConcr.aov, split = list(Coal.Percent = list(L = 1, Q = 2, Dev = 3:4)))
#
#get equation of fitted quadratic
#
CP <- as.vector(Coal.Percent)
CP <- as.numeric(CP)
CP2 <- CP*CP
CRDConcr.lm <- lm(Strength ~ CP + CP2)
coef(CRDConcr.lm)
#
# plot means and fitted line
#
CRDConcr.tab <- model.tables(CRDConcr.aov, type="means")
Coal.Percent.Mean <- CRDConcr.tab$tables$Coal.Percent
plot(x=Coal.Percent.lev, y=Coal.Percent.Mean, ylim=c(1500,1700), 
     xlab="Coal (%)", ylab="Strength")
CRDConcr.coef <- coef(CRDConcr.lm)
coalx <- seq(0, 1, 0.01)
Coal.Percent.Fit <- CRDConcr.coef[[1]] + CRDConcr.coef[[2]]*coalx +
                                         CRDConcr.coef[[3]]*coalx*coalx
lines(x=coalx, y=Coal.Percent.Fit, type="l")
#
# fit orthogonal contrasts
#
contrasts(CRDConcr.dat$Coal.Percent)
contrasts(CRDConcr.dat$Coal.Percent) <- contr.helmert(5)
contrasts(CRDConcr.dat$Coal.Percent) <- matrix(c(4,-1,-1,-1,-1), nrow=5, ncol=1)
contrasts(CRDConcr.dat$Coal.Percent)                      7
CRDConcr.aov <- aov(Strength ~ Coal.Percent + Error(Batch), CRDConcr.dat)
summary(CRDConcr.aov, split = list(Coal.Percent = list(NonevsRest = 1, Dev=2:4)))
coef(CRDConcr.aov)

