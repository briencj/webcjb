RCBDLight.dat <- read.csv("RCBDLight.dat.csv", header=TRUE, colClasses=c(rep("factor", times=3), "numeric"))
save(RCBDLight.dat, file="RCBDLight.dat.rda")
load("RCBDLight.dat.rda")
attach(RCBDLight.dat)
RCBDLight.dat
boxplot(split(Reading, Day), xlab="Day", ylab="Reading")
boxplot(split(Reading, Coater), xlab="Coater", ylab="Reading")
RCBDLight.aov <- aov(Reading ~ Day + Coater + Error(Day/Test), RCBDLight.dat)
summary(RCBDLight.aov)
RCBDLight.DayRandom.aov <- aov(Reading ~ Coater + Error(Day/Test), RCBDLight.dat)
summary(RCBDLight.DayRandom.aov)
#Compute Day F and p
Day.F <- 0.1033/0.09
Day.p <- 1-pf(Day.F, 2, 6)
data.frame(Day.F,Day.p)
#
# Diagnostic checking
#
res <- resid.errors(RCBDLight.aov)
fit <- fitted.errors(RCBDLight.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
tukey.1df(RCBDLight.aov, RCBDLight.dat, error.term="Day:Test")
#
# multiple comparisons
#
model.tables(RCBDLight.aov, type="means")
q <- qtukey(0.95, 4, 6)
q
#
# Plotting Treat means
#
RCBDLight.tab <- model.tables(RCBDLight.aov, type="means")
RCBDLight.Coater.Mean <- data.frame(Coater.lev = levels(Coater), 
                                  Coater.Mean = as.vector(RCBDLight.tab$tables$Coater))
barchart(Coater.Mean ~ Coater.lev, ylim=c(0,6), xlab="Coater", ylab="Light box reading", 
         main="Reading means for different Coater types", data=RCBDLight.Coater.Mean)


