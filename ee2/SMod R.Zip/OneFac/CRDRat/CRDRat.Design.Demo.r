data.frame(fac.gen(CRDRat.unit), Diet)
CRDRat.lay[CRDRat.lay$Permutation,]
set.seed(215)
n <- 6
Standard.Order <- factor(1:n)
Ran <- runif(n)
Rat <-order(Ran)
data.frame(Standard.Order,Ran,Rat)
rep(c("A","B","C"), times = c(3,2,1))
CRDRat.Design

