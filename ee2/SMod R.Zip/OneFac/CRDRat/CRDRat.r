library(dae)

load("CRDRat.dat.rda")
attach(CRDRat.dat)
boxplot(split(LiverWt, Diet))
#
# Regression analysis
#
Rat.lm<- lm(LiverWt ~ Diet, CRDRat.dat)
summary(Rat.lm)
anova(Rat.lm)
res.lm <- residuals(Rat.lm)
fit.lm <- fitted(Rat.lm)
#
# AOV without Error
#
Rat.NoError.aov <- aov(LiverWt ~ Diet, CRDRat.dat)
summary(Rat.NoError.aov)
model.tables(Rat.NoError.aov, type="means", se=T)
res.aov <- residuals(Rat.aov)
fit.aov <- fitted(Rat.aov)
plot(fit.aov, res.aov)
#
# AOV with Error
#
Rat.aov <- aov(LiverWt ~ Diet + Error(Rat), CRDRat.dat)
summary(Rat.aov)
model.tables(Rat.aov, type="means")
formula(Rat.aov)
res.aov <- resid.errors(Rat.aov, error.term = "Rat")   #five residuals from Rat stratum
fit.aov <- fitted.errors(Rat.aov, error.term = "Rat")  #and five fitted values 
res.aov <- residuals(Rat.aov[[2]]) #five residuals from Rat (or [[2]]) stratum
fit.aov <- fitted(Rat.aov[[2]])    #and five fitted values 
model.tables(Rat.aov, type="means")
Rat.proj <- proj(Rat.aov)  #project effects and SSq into two strata (length 6 for all)
Rat.proj$"Rat"[,"Residuals"]
res.aov <- Rat.proj$"Rat"[,"Residuals"]
fit.aov <- Rat.proj$"(Intercept)"[,"(Intercept)"] + Rat.proj$"Rat"[,"Diet"]
fit.aov <- Rat.proj[[1]][,1] + Rat.proj$"Rat"[,"Diet"] #alternative syntax
res.aov; fit.aov
plot(fit.aov, res.aov)
Rat.aov
fit.lm; fit.aov
#
# Checking regression calculations
#
X <- matrix(c(1,1,1,1,1,1, -1,-1,-1,1,1,0, -1,-1,-1,-1,-1,2), nrow=6, ncol=3)
XX <- t(X)%*%X
XXinv <- solve(XX)
XXXT <- XXinv%*%t(X)
theta <- XXXT %*% LiverWt
X; XXinv; XXXT; 1/XXXT; theta
coef(Rat.aov); coef(Rat.lm)
contrasts(Diet)
contrasts(Diet) %*% coef(Rat.aov)[-1]

