#
# Obtaining randomized layout for a CRD
#
n <- 6
CRDRat.unit <- list(Rat = n)
Diet <- factor(rep(c("A","B","C"), times = c(3,2,1)))
CRDRat.lay <- fac.layout(unrandomized=CRDRat.unit, randomized=Diet, seed=695)
CRDRat.lay
#remove Diet object in workspace to avoid using it by mistake
remove(Diet)