load("RCBDComponent.dat.rda")
RCBDComponent.dat <- fac.gen(list(Oven = 5, Run =4))
RCBDComponent.dat$Temperature <- factor(rep(c(200,300,400,500), times = 5))
RCBDComponent.dat$Life <- c(340,324,307,274,361,338,312,281,346,328,
                           298,276,358,332,315,285,343,321,294,269)
attach(RCBDComponent.dat)
boxplot(split(Life, Oven), xlab="Oven", ylab="Component life (hrs)")
boxplot(split(Life, Temperature), xlab="Oven", ylab="Component life (hrs)")
#
# Set up to fit polynomials
#
Temperature.lev <- c(200,300,400,500)
RCBDComponent.dat$Temperature <- ordered(RCBDComponent.dat$Temperature, 
                                         levels=Temperature.lev)
contrasts(RCBDComponent.dat$Temperature) <- contr.poly(4, scores=Temperature.lev)
contrasts(RCBDComponent.dat$Temperature)
RCBDComponent.aov <- aov(Life ~ Temperature + Error(Oven/Run), RCBDComponent.dat)
summary(RCBDComponent.aov)
summary(RCBDComponent.aov, split = list(Temperature = list(L = 1, Q = 2, Dev=3)))
CF <- sum(RCBDComponent.dat$Life)^2/20
#Compute Oven F and p
Oven.F <- 211.33/13.3
Oven.p<- 1-pf(Oven.F, 4, 12)
data.frame(Oven.F,Oven.p)
#
# Diagnostic checking
#
res <- resid.errors(RCBDComponent.aov)
fit <- fitted.errors(RCBDComponent.aov)
data.frame(Oven,Run,Temperature,Life,res,fit)
plot(fit, res, pch=16)
qqnorm(res, pch = 16)
qqline(res)
tukey.1df(RCBDComponent.aov, RCBDComponent.dat, error.term="Oven:Run")
#
# get fitted equation
#
Te <- as.vector(Temperature)
Te <- as.numeric(Te)
Te2  <- Te * Te
RCBDComponent.lm <- lm(Life ~ Te + Te2)
coef(RCBDComponent.lm)
#
# plot means and fitted line
#
RCBDComponent.tab <- model.tables(RCBDComponent.aov, type="means")
Temperature.Mean <- RCBDComponent.tab$tables$Temperature
plot(x=Temperature.lev, y=Temperature.Mean, xlab="Temperature", ylab="Wear")
RCBDComponent.coef <- coef(RCBDComponent.lm)
tempx <- seq(200, 500, 5)
Temperature.Fit <- RCBDComponent.coef[[1]] + RCBDComponent.coef[[2]]*tempx +
                                         RCBDComponent.coef[[3]]*tempx*tempx
lines(x=tempx, y=Temperature.Fit, type="l")


