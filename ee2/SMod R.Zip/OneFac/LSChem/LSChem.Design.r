t <- 5
n <- t*t
LSChem.unit <- list(Days=t, Batches=t)
Ingredients <- factor(c(1,2,3,4,5, 2,3,4,5,1, 3,4,5,1,2, 4,5,1,2,3, 5,1,2,3,4),
                 labels=c("A","B","C","D","E"))
LSChem.lay <- fac.layout(unrandomized=LSChem.unit, randomized=Ingredients, seed=985)
remove("Ingredients")
LSChem.lay
