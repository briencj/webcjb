library(dae)
r <- 5
c <- 4
YS.unr <- list(Rows = r, Cols = c)
YS.ran <- data.frame( Treat = factor(c(1:4, 2:4,5, 3:5,1, 4,5,1,2, 5,1:3)))
YS.lay <- fac.layout(unrand = YS.unr, rand = YS.ran, seed=2346)

YS.dat <- data.frame(YS.lay, y = rnorm(r*c))
YS.aov <- aov(y ~ Treat + Error(Rows*Cols), YS.dat)
summary(YS.aov)