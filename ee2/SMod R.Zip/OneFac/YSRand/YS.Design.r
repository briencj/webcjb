library(dae)
#
# Youden squares
#
r <- 2
k <- 3
t <- 5
n <- r*t*k
Standard.Order <- factor(1:n)
Random.Order <- order(rep(runif(r), each=t*k), rep(runif(r*t), each = k), 
                   c(rep(runif(k), times = t), rep(runif(k), times = t)))
YoudenSq.unr <- list(Squares=r, Rows=t, Cols=k)
YoudenSq.nest <- list(Rows = "Squares", Cols = "Squares")
YoudenSq.ran <- data.frame(Treats = factor(c(1,2,3, 2,1,5, 3,4,2, 4,5,1, 5,3,4,
                   1,2,4, 2,3,5, 3,4,1, 4,5,2, 5,1,3)))
YoudenSq.lay <- fac.layout(unrandomized = YoudenSq.unr, 
                           nested.factors = YoudenSq.nest, 
                           randomized = YoudenSq.ran, seed=1012)
attach(YoudenSq.lay)
YoudenSq.lay
#
# Analysis of random data
#
YoudenSq.dat <- data.frame(YoudenSq.lay, Data <- rnorm(n))
YoudenSq.aov <- aov(Data ~ Treats + Error(Squares/(Rows*Cols)), YoudenSq.dat)
summary(YoudenSq.aov)

