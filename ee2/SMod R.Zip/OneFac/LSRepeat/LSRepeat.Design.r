library(dae)
r <- 2
t <- 4
n <- r*t*t
LSRepeat.unit <- list(Occasion=r, Drivers=t, Cars=t)
Additives <- factor(rep(c(1,2,3,4, 4,3,2,1, 2,1,4,3, 3,4,1,2), times=r), 
                         labels=c("A","B","C","D"))

#
# Sets of Latin squares - case 1
#
LSRepeat1.lay <- fac.layout(unrandomized=LSRepeat.unit, 
                            randomized=Additives, seed=914)
LSRepeat1.lay
#
# Sets of Latin squares - case 2
#
LSRepeat2.nest <- list(Drivers="Occasion")
LSRepeat2.lay <- fac.layout(unrandomized=LSRepeat.unit, 
              nested.factors=LSRepeat2.nest, randomized=Additives, seed=149)
LSRepeat2.lay
#
# Sets of Latin squares - case 2b
#
LSRepeat2b.nest <- list(Cars="Occasion")
LSRepeat2b.lay <- fac.layout(unrandomized=LSRepeat.unit, 
              nested.factors=LSRepeat2b.nest, randomized=Additives, seed=194)
LSRepeat2b.lay
#
# Sets of Latin squares - case 3
#
LSRepeat3.nest <- list(Cars="Occasion", Drivers="Occasion")
LSRepeat3.lay <- fac.layout(unrandomized=LSRepeat.unit, 
              nested.factors=LSRepeat3.nest, randomized=Additives, seed=419)
LSRepeat3.lay

remove(Additives)
#
# Analysis of random data - case 1
#
LSRepeat1.dat <- data.frame(LSRepeat1.lay, Data=rnorm(n))
LSRepeat1.aov <- aov(Data ~ Additives + Error(Occasion*Drivers*Cars), LSRepeat1.dat)
summary(LSRepeat1.aov)
#
# Analysis of random data - case 2
#
LSRepeat2.dat <- data.frame(LSRepeat2.lay, Data = rnorm(n))
LSRepeat2.aov <- aov(Data ~ Additives + Error((Occasion/Drivers)*Cars), LSRepeat2.dat)
summary(LSRepeat2.aov)
#
# Analysis of random data - case 2b
#
LSRepeat2b.dat <- data.frame(LSRepeat2b.lay, Data = rnorm(n))
LSRepeat2b.aov <- aov(Data ~ Additives + Error((Occasion/Cars)*Drivers), LSRepeat2b.dat)
summary(LSRepeat2b.aov)
#
# Analysis of random data - case 3
#
LSRepeat3.dat <- data.frame(LSRepeat3.lay, Data = rnorm(n))
LSRepeat3.aov <- aov(Data ~ Additives + Error(Occasion/(Drivers*Cars)), LSRepeat3.dat)
summary(LSRepeat3.aov)

