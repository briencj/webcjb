r <- 2
t <- 4
n <- r*t*t
LSRepeat1.dat <- fac.gen(generate = list(Occasion=r, Drivers=t, Cars=t))
LSRepeat1.dat$Additives <- factor(c(1,2,3,4,3,4,1,2,4,3,2,1,2,1,4,3,
                                    1,2,3,4,3,4,1,2,4,3,2,1,2,1,4,3),
                                   labels = c("A", "B", "C", "D"))
LSRepeat1.dat <- data.frame(LSRepeat1.dat, Data=rnorm(n))
LSRepeat1.aov <- aov(Data ~ Additives + Error(Occasion*Drivers*Cars), LSRepeat1.dat)
summary(LSRepeat1.aov)
