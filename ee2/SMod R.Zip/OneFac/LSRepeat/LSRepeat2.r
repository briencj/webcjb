#
# Analysis of random data - case 2
#
LSRepeat2.dat <- data.frame(LSRepeat2.lay, Data = rnorm(n))
attach(LSRepeat2.dat)
LSRepeat2.dat
boxplot(split(Data, Occasion), xlab="Occasion", ylab="Data")
boxplot(split(Data, Drivers), xlab="Drivers", ylab="Data")
boxplot(split(Data, Cars), xlab="Cars", ylab="Data")
boxplot(split(Data, Additives), xlab="Additives", ylab="Data")
LSRepeat2.aov <- aov(Data ~ Occasion/Drivers + Occasion*Cars + Additives + 
                                       Error((Occasion/Drivers)*Cars), LSRepeat2.dat)
summary(LSRepeat2.aov)
#
# Diagnostic checking
#
res <- resid.errors(LSRepeat2.aov)
fit <- fitted.errors(LSRepeat2.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
tukey.1df(LSRepeat2.aov, LSRepeat2.dat, error.term = "Occasion:Drivers:Cars")
#
# multiple comparisons
#
model.tables(LSRepeat2.aov, type="means")
q <- qtukey(0.95, 4, 15)
q
#
# Plotting Treat means
#
LSRepeat2.tab <- model.tables(LSRepeat2.aov, type="means")
LSRepeat2.Adds.Mean <- data.frame(Adds.lev = levels(Additives), 
                        Adds.Mean = as.vector(LSRepeat2.tab$tables$Additives))
LSRepeat2.Adds.Mean <- LSRepeat2.Adds.Mean[order(LSRepeat2.Adds.Mean$Adds.Mean),]
#use factor to order bars
LSRepeat2.Adds.Mean$Adds.lev <- factor(LSRepeat2.Adds.Mean$Adds.lev, 
                                    levels=LSRepeat2.Adds.Mean$Adds.lev)
barchart(Adds.Mean ~ Adds.lev, xlab="Additives", 
         ylab="NO Reduction", main="Fitted values for Nitrous Oxide Reduction", 
         data=LSRepeat2.Adds.Mean)
