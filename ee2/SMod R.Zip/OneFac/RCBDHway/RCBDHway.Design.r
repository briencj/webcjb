library(dae)
b <- 3
t <- 4
n <- b*t
RCBDHway.unit <- list(Location=b, Strips=t)
RCBDHway.nest <- list(Strips="Location")
Type <- factor(rep(1:t, times=b), labels=c("A","B","C","D"))
RCBDHway.lay <- fac.layout(unrandomized=RCBDHway.unit, 
                           nested.factors=RCBDHway.nest,
                           randomized=Type, seed=832)
remove("Type")
RCBDHway.lay

