library(dae)
RCBDHway.dat <- data.frame(RCBDHway.lay, 
            Wear=c(40.2,50.0,38.0,49.7,48.5,32.8,39.3,42.7,51.9,53.5,51.1,46.3))
attach(RCBDHway.dat)
boxplot(split(Wear, Location), xlab="Location", ylab="Wear in first year")
boxplot(split(Wear, Type), xlab="Type", ylab="Wear in first year")
RCBDHway.NoError.aov <- aov(Wear ~ Location + Type, RCBDHway.dat)
RCBDHway.aov <- aov(Wear ~ Location + Type + Error(Location/Strips), RCBDHway.dat)
summary(RCBDHway.aov)
#Compute Location F and p
Location.F <- 99.726/11.784
Location.p <- 1-pf(Location.F, 2, 6)
data.frame(Location.F,Location.p)
tukey.1df(RCBDHway.aov, RCBDHway.dat, error.term="Location:Strips")
#
# Diagnostic checking
#
res <- resid.errors(RCBDHway.aov)
fit <- fitted.errors(RCBDHway.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
#have not converted rest to R
#
# multiple comparisons
#
RCBDHway.NoError.aov <- aov(Wear ~ Location + Type, RCBDHway.dat)
RCBDHway.mca <- multicomp(RCBDHway.NoError.aov, focus = "Type")
plot(RCBDHway.mca)
RCBDHway.mca
#
# Plotting
#
title("Fitted values for Wear")
RCBDHway.tab <- model.tables(RCBDHway.aov, type="means")
Location.Mean <- RCBDHway.tab$tables$Location
Type.Mean <- RCBDHway.tab$tables$Type
RCBDHway.Means <- data.sheet(Location.Mean,Type.Mean)
#then use 2D-Graphs to produce bar charts


