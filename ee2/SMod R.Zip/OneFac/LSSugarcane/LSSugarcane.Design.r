# load first fac.functions.r
t <- 5
n <- t * t
Standard.Order <- factor(1:n)
Random.Order <- order(rep(runif(t), each = t), rep(runif(t), times = t))
SugarcaneLS.Design <- fac.divide(Random.Order, list(Rows = t, Columns = t))
Varieties <- factor(c("A", "B", "C", "D", "E",
"C", "D", "E", "A", "B", "E", "A", "B", "C", "D",
"B", "C", "D", "E", "A", "D", "E", "A", "B", "C"),
labels =c("A", "B", "C", "D", "E"))
SugarcaneLS.Design <- data.frame(Standard.Order, Random.Order, SugarcaneLS.Design,
Varieties)
remove(c("Standard.Order", "Random.Order", "Varieties"))
SugarcaneLS.Design[SugarcaneLS.Design$"Random.Order",] <- SugarcaneLS.Design
SugarcaneLS.Design