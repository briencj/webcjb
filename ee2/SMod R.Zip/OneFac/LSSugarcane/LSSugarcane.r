#install.packages(repos=NULL, pkgs="path\\dae.zip")
install.packages(repos=NULL, pkgs="C:\\clarice\\Chris\\Course2007\\R-prog\\dae.zip")
# change directory  to path
library(dae)
# or load the function: diagnostic.checking.r
library(car)

LSSugarcane.dat <- data.frame(Rows=factor(rep(c(1,2,3,4,5), times=c(5,5,5,5,5))),
Columns = factor(rep(c(1,2,3,4,5), times=5)))
LSSugarcane.dat$Treats <- factor(c("D","A","B","C","E","C","E","A","B","D",
"E","B","C","D","A","B","D","E","A","C","A","C","D","E","B"))
LSSugarcane.dat$Yields <- c(432,518,458,583,331,724,478,524,550,400,
489,384,556,297,420,494,500,313,486,501,515,660,438,394,318)
LSSugarcane.dat
attach(LSSugarcane.dat)

# boxplots
par(mfrow=c(1,3))
boxplot(split(Yields, Rows), style.bxp = "old", xlab = "Rows", ylab
= "Yields", medchar = T, medpch = 8)
boxplot(split(Yields, Columns), style.bxp = "old", xlab = "Columns", ylab =
"Yields", medchar = T, medpch = 8)
boxplot(split(Yields, Treats), style.bxp = "old", xlab = "Treatments",
ylab = "Yields", medchar = T, medpch = 8)
par(mfrow=c(1,1))

# Variety means, variances and standard erros
v <- tapply(Yields, Treats,var)
data.frame(Mean= tapply(Yields, Treats,mean),
Variance=v,StandardError= sqrt(v))
rm(v)

# ANOVA using aov without error term
LSSugarcane.NoError.aov <- aov(Yields ~ Rows + Columns + Treats, LSSugarcane.dat)
summary(LSSugarcane.NoError.aov)

# ANOVA using aov with error term
LSSugarcane.aov <- aov(Yields ~ Rows + Columns + Treats + Error(Rows * Columns), LSSugarcane.dat)
summary(LSSugarcane.aov)

#Compute Drivers and Cars Fs and p-values
Rows.F <- 7620/2843
Rows.p <- 1 - pf(Rows.F, 4, 12)
Columns.F <- 13910/2843
Columns.p <- 1 - pf(Columns.F, 4, 12)
data.frame(Rows.F, Rows.p, Columns.F, Columns.p)

# ANOVA using lm
LSSugarcane.lm <- lm(Yields ~ Rows + Columns + Treats, LSSugarcane.dat)
anova(LSSugarcane.lm)

# Diagnostic checking
fit<-fitted(LSSugarcane.lm)
res<-residuals(LSSugarcane.lm)
data.frame(Rows, Columns, Treats, Yields, res, fit)
par(mfrow=c(1,2))
plot(fit, res, pch = 16)
qqnorm(res, pch = 16)
qqline(res)
par(mfrow=c(1,1))
# normal-plot with simulation envelope
library(car)
qq.plot(LSSugarcane.lm,simulate=TRUE,reps=999) #click on the point, use ESC in R to esc

# Test of nonadditivity - Tukey
# directly from the package diagnostic.checking.r
tukey.1df(LSSugarcane.aov, LSSugarcane.dat, error.term = "Rows:Columns")
# or using lm
LSSugarcane.lm <- lm(Yields ~ Rows + Columns + Treats)
anova(LSSugarcane.lm , test="F")
LP2 <-  (predict(LSSugarcane.lm ))^2
LSSugarcane.lm2 <-update(LSSugarcane.lm, .~. +LP2)
anova(LSSugarcane.lm ,LSSugarcane.lm2, test="F")

# Multiple comparisons - Tukey's HSD procedure
model.tables(LSSugarcane.aov, type="means", se=T)
q <- qtukey(0.95, 5, 12)
q
w <- qtukey(0.95, 5, 12)*summary(LSSugarcane.lm)$sigma/sqrt(5)
w
summary(LSSugarcane.aov  <- aov(Yields ~ Rows + Columns + Treats))
TukeyHSD(LSSugarcane.aov , "Treats", ordered = TRUE)
plot(TukeyHSD(LSSugarcane.aov , "Treats"))

detach(LSSugarcane.dat)
search()