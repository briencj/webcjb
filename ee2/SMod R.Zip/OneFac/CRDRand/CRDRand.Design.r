#
# Obtaining randomized layout for a CRD
#
n <- 21
CRDRand.unit <- list(Run = n)
Treatment <- factor(rep(1:7, times = 3))
CRDRand.lay <- fac.layout(unrandomized=CRDRand.unit, randomized=Treatment, seed=911)
CRDRand.lay
#remove Treatment object in workspace to avoid using it by mistake
remove(Treatment)

