#set up data.frame with factors Students and Dose; 
# then add response variable Taps.
CRDCaff.dat <- data.frame(Students = factor(1:30), 
                          Dose = factor(rep(c(0,100,200), times=10)))
CRDCaff.dat$Taps <- 
       c(242,248,246,245,246,248,244,245,250,248,247,252,247,248,248,
         248,250,250,242,247,246,244,246,248,246,243,245,242,244,250)
CRDCaff.dat
#
# initial analysis
#
library(dae)
attach(CRDCaff.dat)
boxplot(split(Taps, Dose), xlab="Dose", ylab="Number of taps")
Caffeine.aov <- aov(Taps ~ Dose + Error(Students), CRDCaff.dat)
summary(Caffeine.aov)
#
# plots for diagnostic checking
#
res <- residuals(Caffeine.aov)
fit <- fitted(Caffeine.aov)
res <- resid.errors(Caffeine.aov)
fit <- fitted.errors(Caffeine.aov)
data.frame(Students,Dose,Taps,res,fit)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
#
# multiple comparisons
#
model.tables(Caffeine.aov, type="means")
q <- qtukey(0.95, 3, 27)
q
#
# fit orthogonal contrasts
#
contrasts(CRDCaff.dat$Dose)
oldClass(CRDCaff.dat$Dose) <- "factor"         # needed if factor converted to ordered
contrasts(CRDCaff.dat$Dose) <- matrix(c(0,-1,1,-2,1,1), nrow=3, ncol=2)
contrasts(CRDCaff.dat$Dose)
Caffeine.aov <- aov(Taps ~ Dose + Error(Students), CRDCaff.dat)
summary(Caffeine.aov, split = list(Dose 
    = list(Caff100.200 = 1, None.Rest = 2)))
coef(Caffeine.aov)
#
# fit polynomials
#
t <- 3
Dose.lev <- c(0,100,200)
CRDCaff.dat$Dose <- ordered(CRDCaff.dat$Dose, levels=Dose.lev)
contrasts(CRDCaff.dat$Dose) <- contr.poly(t, scores=Dose.lev)
contrasts(CRDCaff.dat$Dose)
Caffeine.aov <- aov(Taps ~ Dose + Error(Students), CRDCaff.dat)
summary(Caffeine.aov, split = list(Dose = list(L = 1, Q = 2)))
summary(Caffeine.aov, split = list(Dose = list(L = 1)))
coef(Caffeine.aov)
#
#get fitted equation
#
D <- as.vector(Dose)
D <- as.numeric(D)
Caffeine.lm <- lm(Taps ~ D)
coef(Caffeine.lm)
#
# plot means and fitted line
#
Caffeine.tab <- model.tables(Caffeine.aov, type="means")
Dose.Mean <- Caffeine.tab$tables$Dose
plot(x=Dose.lev, y=Dose.Mean, xlab="Dose", ylab="No. Taps")
Caffeine.coef <- coef(Caffeine.lm)
dosex <- seq(0, 200, 1)
Dose.Fit <- Caffeine.coef[[1]] + Caffeine.coef[[2]]*dosex
lines(x=dosex, y=Dose.Fit, type="l")
#easy, but not generalizable, method of fitting line
Caffeine.tab <- model.tables(Caffeine.aov, type="means")
CRDCaff.Means <- data.frame(Dose = Dose.lev, Taps = as.vector(Caffeine.tab$tables$Dose))
plot(CRDCaff.Means)
abline(coef(Caffeine.lm))
#doing quadratic regression
D2 <- D*D
Caffeine.lm <- lm(Taps ~ D + D2)
#plot means and fitted quadratic
Caffeine.tab <- model.tables(Caffeine.aov, type="means")
Dose.Mean <- Caffeine.tab$tables$Dose
plot(x=Dose.lev, y=Dose.Mean, xlab="Dose", ylab="No. Taps")
Caffeine.coef <- coef(Caffeine.lm)
dosex <- seq(0, 200, 1)
Dose.Fit <- Caffeine.coef[[1]] + Caffeine.coef[[2]]*dosex +
                                 Caffeine.coef[[3]]*dosex*dosex
lines(x=dosex, y=Dose.Fit, type="l")
# Misc
D <- ordered(c(rep(c(0,100,200), 10)))
D
names(Caffeine.tab)
names(Caffeine.coef)

