#set up data.frame with factors Students and Dose and response variable Taps
CRDCaff.dat <- data.frame(Students = factor(1:30), Dose = factor(rep(c(0,100,200), times=10)))
CRDCaff.dat$Taps <- 
       c(242,248,246,245,246,248,244,245,250,248,247,252,247,248,248,
         248,250,250,242,247,246,244,246,248,246,243,245,242,244,250)
#
# initial analysis
#
attach(CRDCaff.dat)
CRDCaff.dat
boxplot(split(Taps, Dose), xlab="Dose", ylab="Number of taps")
Caffeine.aov <- aov(Taps ~ Dose + Error(Students), CRDCaff.dat)
summary(Caffeine.aov)
#
# plots for diagnostic checking
#
#load the functions from the bottom: resid.errors and fitted.errors
res <- resid.errors(Caffeine.aov)
fit <- fitted.errors(Caffeine.aov)
data.frame(Students,Dose,Taps,res,fit)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
#
# multiple comparisons
#
model.tables(Caffeine.aov, type="means", se=T)
q <- qtukey(0.95, 3, 27)
q
summary(Caffeine.NoError.aov <- aov(Taps ~ Dose))
TukeyHSD(Caffeine.NoError.aov, "Dose", ordered = TRUE)
plot(TukeyHSD(Caffeine.NoError.aov, "Dose"))
#
# fit polynomials
#
Dose.lev <- c(0,100,200)
contrasts(CRDCaff.dat$Dose) <- contr.poly(Dose.lev)
contrasts(CRDCaff.dat$Dose)
Caffeine.aov <- aov(Taps ~ Dose + Error(Students), CRDCaff.dat)
summary(Caffeine.aov, split = list(Dose = list(L = 1, Q = 2)))
summary(Caffeine.aov, split = list(Dose = list(L = 1)))
#
#
#
plot(c(0,200), c(240,255), type="n", xlab="Dose", ylab="Numbers of taps")
d <- rep(c(0,100,200), times=10)
points(d,Taps)
x<-seq(0,200,0.2)
lines(x, (predict(lm(Taps ~ I(d)),data.frame(d=x))),lty=1, col="red")
lines(x, (predict(lm(Taps ~ I(d)+I(d^2)),data.frame(d=x))),lty=2, col="blue")
legend(0.60, 255, c("linear", "quadratic"),lty=c(1,2), col=c("red","blue"))
title(sub="Figure 2. Adjusted curves and fitted values")


"resid.errors" <- function(aov.obj, error.term=NULL)
{
	res <- 0
	if (inherits(aov.obj, what="aovlist"))
	{	aov.proj <- proj(aov.obj)
		if (is.null(error.term))
			res <- aov.proj[[length(aov.obj)]][,"Residuals"]
		else
			res <- aov.proj[[error.term]][,"Residuals"]
	}
	else
		res <- residuals(aov.obj)
	res <- res
}

"fitted.errors" <- function(aov.obj, error.term=NULL)
{
	if (inherits(aov.obj, what="aovlist"))
	{	aov.proj <- proj(aov.obj)
		if (is.null(error.term))
			no.strata <- length(aov.obj)
		else
			no.strata <- which(names(aov.proj) == error.term)
		fit <- aov.proj[["(Intercept)"]][,1]
		for (i in 2:no.strata)
		{	nterms <- ncol(aov.proj[[i]])
			if (dimnames(aov.proj[[i]])[[2]][nterms] == "Residuals") nterms <- nterms-1
			if (nterms > 0)
				if (nterms == 1)
					fit <- aov.proj[[i]][,1:nterms]
				else
					fit <- fit + rowSums(aov.proj[[i]][,1:nterms])
		}
	}
	else
		fit <- fitted(aov.obj)
	fit <- fit
}
