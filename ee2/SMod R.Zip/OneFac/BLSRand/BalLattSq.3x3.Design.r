#
# Balanced lattice squares
#
k <- 3
r <- (k+1)/2
t <- k*k
BalLattSq.unit <- list(Squares=r, Rows=k, Cols=k)
BalLattSq.nest <- list(Rows = "Squares", Cols = "Squares")
Treats <- factor(c(1,2,3, 4,5,6, 7,8,9, 1,6,8, 9,2,4, 5,7,3))
BalLattSq.lay <- fac.layout(unrandomized = BalLattSq.unit, 
                            nested.factors = BalLattSq.nest, 
                            randomized = Treats, seed = 419)
remove("Treats")
BalLattSq.lay
#
# Analysis of random data
#
n <- r*t
BalLattSq.dat <- data.frame(BalLattSq.lay)
BalLattSq.dat$Data <- rnorm(n)
BalLattSq.aov <- aov(Data ~ Treats + Error(Squares/(Rows*Cols)), BalLattSq.dat)
summary(BalLattSq.aov)

