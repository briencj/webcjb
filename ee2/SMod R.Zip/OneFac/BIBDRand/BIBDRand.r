b <- 4
k <- 3
t <- 4
BIBD.unit <- list(Blocks=b, Plots=k)
BIBD.nest <- list(Plots = "Blocks")
Treat <- factor(c(1,2,3, 1,2,4, 1,3,4, 2,3,4), labels=c("A","B","C","D"))
data.frame(fac.gen(BIBD.unit), Treat) #basic systematic arrangement
BIBD.lay <- fac.layout(unrandomized = BIBD.unit, nested.factors = BIBD.nest,
                          randomized = Treat, seed = 987)
remove("Treats")
BIBD.lay

