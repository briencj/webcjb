#Sets of Latin squares from Cochran & Cox p.135
#see also CARRYCC.GS5
LSCows.dat <- fac.gen(generate=list(Weeks=3, Herds=2, Cows=3))
LSCows.dat$Supplements <- factor(c(1,2,3,1,2,3, 2,3,1,3,1,2, 3,1,2,2,3,1),
                                 labels = c("A","B","C"))
LSCows.dat$Prodn <- c(38,109,124,86,75,101,
                      25,86,72,76,35,63,
                      15,39,27,46,34,1)
LSCows.aov <- aov(Prodn ~ Herds*Weeks + Supplements + Error((Herds/Cows)*Weeks),
                  LSCows.dat)
summary(LSCows.aov)
