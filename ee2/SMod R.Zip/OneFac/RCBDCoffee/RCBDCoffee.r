library(dae)

#set up data.frame with factors Plots, Blocks and Doses and response variable Yields
RCBDFac2Coffee.dat <- data.frame(Blocks=factor(rep(c(1:6), each=8)),
Plots = factor(rep(c(1:8), times=6)), Treatments = factor(rep(c(1:8), times=6)),
N = factor(rep(rep(c(0,30,60,90), each=2), times=6)),K = factor(rep(c(0,60), times=24)))
RCBDFac2Coffee.dat$Yields <- c(
31.8,25.6, 36.2,37.1, 35.3,51.5, 43.8,47.0,
40.5,32.4, 37.8,53.0, 39.0,66.1, 37.7,49.9,
35.7,39.6, 40.9,36.4, 36.0,51.7, 43.3,50.9,
25.7,48.9, 44.8,43.0, 35.5,52.0, 41.8,49.1,
37.2,30.6, 42.4,29.7, 28.2,56.5, 31.9,51.7,
45.3,33.7, 38.4,30.4, 42.4,58.2, 37.7,39.6)
RCBDFac2Coffee.dat
attach(RCBDFac2Coffee.dat)

# boxplots
par(mfrow=c(1,2))
boxplot(split(Yields, Blocks), style.bxp = "old", xlab = "Blocks", ylab
= "Yields", medchar = T, medpch = 8)
boxplot(Yields~N*K, style.bxp = "old", xlab="Treatments", ylab="Yields", medchar = T, medpch = 8)
par(mfrow=c(1,1))

# Treatments means, variances and standard erros
v <- tapply(Yields, Treatments,var)
data.frame(Mean= tapply(Yields, Treatments,mean),Variance=v,StandardError= sqrt(v))
rm(v)

interaction.plot(N, K, Yields, lwd = 2)
interaction.plot(K, N, Yields, lwd = 2)
N.lev <- c(0,30,60,90)
contrasts(RCBDFac2Coffee.dat$N) <- contr.poly(N.lev)
K.lev <- c(0,60)
contrasts(RCBDFac2Coffee.dat$K) <- contr.poly(K.lev)
RCBDFac2Coffee.aov <- aov(Yields ~ Blocks+N*K + Error(Blocks/Plots), RCBDFac2Coffee.dat)
summary(RCBDFac2Coffee.aov, split = list(N = list(L = 1, Q = 2, Dev = 1),
K = list(L = 1)))

detach(RCBDFac2Coffee.dat)
search()