#for response variable only data file
Impact <- c(20, 23, 21, 23, 26, 24, 26, 23, 20, 24, 28, 27, 22, 28, 23, 29, 27, 25, 28, 21, 
            33, 34, 25, 26, 27, 33, 25, 32, 25, 34, 33, 29, 31, 29, 27, 25, 26, 26, 33, 32)
CRDForm.dat <- data.frame(Impact)
remove("Impact")
load("CRDForm.dat.rda")
#add factors Students and Format to Data window
CRDForm.dat <- data.frame(Viewer = factor(1:40),
                   Format = factor(rep(1:4, each=10), labels=c("A","B","C","D")),
                   CRDForm.dat)
attach(CRDForm.dat)
CRDForm.dat
#
# initial analyses
#
library(dae)
boxplot(split(Impact, Format), xlab="Format", ylab="Impact")
TV.lm <- lm(Impact ~ Format, CRDForm.dat)
anova(TV.lm)
TV.aov <- aov(Impact ~ Format + Error(Viewer), CRDForm.dat)
summary(TV.aov)
#
# plots for diagnostic checking
#
res <- resid.errors(TV.aov)
fit <- fitted.errors(TV.aov)
plot(fit, res, pch = 16)
qqnorm(res, pch = 16)
qqline(res)
#
# multiple comparisons
#
model.tables(TV.aov, type="means")
q <- qtukey(0.95, 4, 36)
q

