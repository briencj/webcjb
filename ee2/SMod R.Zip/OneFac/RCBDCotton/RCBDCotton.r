RCBDCotton.dat <- fac.gen(list(Blocks = 13, Runs = 6))
RCBDCotton.dat$Treatment <- factor(rep(1:6, times=13), label = c("A","B","C","D","E","F"))
RCBDCotton.dat$Breakage <- c(6.0,6.4,2.3,3.3,3.7,4.2,9.7,8.3,3.3,6.4,6.4,4.6,
                             7.4,7.9,7.3,4.1,8.3,5.0,11.5,8.8,10.6,6.9,3.3,4.1,
                             17.9,10.1,7.9,6.0,7.8,5.5,11.9,11.5,5.5,7.4,5.9,3.2,
                             10.2,8.7,7.8,6.0,8.3,10.1,7.8,9.7,5.0,7.3,5.1,4.2,
                             10.6,8.3,7.8,7.8,6.0,5.1,17.5,9.2,6.4,7.4,3.7,4.6,
                             10.6,9.2,8.3,7.3,11.5,11.5,10.6,10.1,9.2,10.1,13.8,5.0,
                             8.7,12.4,12.0,7.8,8.3,6.4)
save(RCBDCotton.dat, file="RCBDCotton.dat.rda")

#analysis
RCBDCotton.aov <- aov(Breakage ~ Treatment + Error(Blocks/Runs), RCBDCotton.dat)
summary(RCBDCotton.aov)
#Compute Blocks F and p
Blocks.F <- 14.763 / 5.107
Blocks.p <- 1-pf(Blocks.F, 12, 60)
data.frame(Blocks.F,Blocks.p)


#diagnostic checking
res <- resid.errors(RCBDCotton.aov)
fit <- fitted.errors(RCBDCotton.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)

#treatment comparisons
model.tables( RCBDCotton.aov, type="means")
q <- qtukey(0.95, 6, 60)
q