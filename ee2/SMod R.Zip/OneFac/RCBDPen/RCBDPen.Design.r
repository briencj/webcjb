library(dae)
b <- 5
t <- 4
n <- b*t
RCBDPen.unit <- list(Blend=b, Flask=t)
RCBDPen.nest <- list(Flask = "Blend")
Treat <- factor(rep(1:t, times=b), labels=c("A","B","C","D"))
data.frame(fac.gen(RCBDPen.unit), Treat) #basic systematic arrangement
RCBDPen.lay <- fac.layout(unrandomized = RCBDPen.unit, nested.factors = RCBDPen.nest,
                          randomized = Treat, seed = 311)
RCBDPen.lay
RCBDPen.lay[RCBDPen.lay$Permutation,]
remove("Treat")
