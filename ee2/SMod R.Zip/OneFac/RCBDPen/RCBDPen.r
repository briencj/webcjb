RCBDPen.dat <- data.frame(Blend=factor(rep(c(1,2,3,4,5), times=c(4,4,4,4,4))),
Flask = factor(rep(c(1,2,3,4), times=5)),
Treat = factor(rep(c("A","B","C","D"), times=5)))
RCBDPen.dat$Yield <- c(89,88,97,94,84,77,92,79,81,87,87,85,87,92,89,84,79,81,80,88)
RCBDPen.dat
attach(RCBDPen.dat)
library(dae)
boxplot(split(Yield, Blend), xlab="Blend", ylab="Yield")
boxplot(split(Yield, Treat), xlab="Treatment", ylab="Yield")
RCBDPen.NoError.aov <- aov(Yield ~ Blend + Treat, RCBDPen.dat)
summary(RCBDPen.NoError.aov)
RCBDPen.aov <- aov(Yield ~ Blend + Treat + Error(Blend/Flask), RCBDPen.dat)
summary(RCBDPen.aov)
RCBDPen.BlendRandom.aov <- aov(Yield ~ Treat + Error(Blend/Flask), RCBDPen.dat)
summary(RCBDPen.BlendRandom.aov)
#Compute Blend F and p
Blend.F <- 66/18.833
Blend.p <- 1-pf(Blend.F, 4, 12)
data.frame(Blend.F,Blend.p)
terms <- RCBDPen.aov$terms
terms
#
# Diagnostic checking
#
res <- resid.errors(RCBDPen.aov)
fit <- fitted.errors(RCBDPen.aov)
data.frame(Blend,Flask,Treat,Yield,res,fit)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
tukey.1df(RCBDPen.aov, RCBDPen.dat, error.term="Blend:Flask")
tukey.1df(RCBDPen.BlendRandom.aov, RCBDPen.dat, error.term="Blend:Flask")
#
# Plotting Treat means
#
RCBDPen.tab <- model.tables(RCBDPen.aov, type="means")
RCBDPen.Treat.Mean <- data.frame(Treat.lev = levels(Treat), 
                                  Treat.Mean = as.vector(RCBDPen.tab$tables$Treat))
barchart(Treat.Mean ~ Treat.lev, ylim=c(0,90), xlab="Treatment", 
         ylab="Yield (%)", main="Fitted values for Yield", data=RCBDPen.Treat.Mean)
RCBDPen.Blend.Mean <- data.frame(Blend.lev = levels(Blend), 
                                  Blend.Mean = as.vector(RCBDPen.tab$tables$Blend))

