variety<-factor(rep(c("A","B","C"),c(4,4,4)))
y<-c(12.7,18.0,18.2,17.1,
20.0,21.1,20.0,28.0,
23.1,24.2,26.4,16.3)
mean(y[1:4])  #mean for variety 1
var(y[1:4])   #variance for variety 1
mean(y[5:8])  #mean for variety 2
var(y[5:8])   #variance for variety 2
mean(y[9:12]) #mean for variety 3
var(y[9:12])  #variance for variety 3

## Other way to get mean, variance, standard errors
v <- tapply(y,variety,var)
data.frame(Mean= tapply(y,variety,mean),
Variance=v,StandardError= sqrt(v))
rm(v)

stripchart(y~variety, pch="*", cex=2.0)   #a dot plot
boxplot(y~variety)