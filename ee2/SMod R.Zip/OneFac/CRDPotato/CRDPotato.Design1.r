set.seed(320)  #a random value between 0 and 1023
b <- 4
t <- 3
n <- b*t
Standard.Order <- factor(1:n)
Standard.Order
Variety <- factor(rep(c(1:t), each=b), labels=c("A","B","C"))
Variety
Plot <- order(r<-runif(n))  # generates 12 random numbers and use the order
                            # of them as the number for a Plot
r
Plot
CRDPotato.Design <- data.frame(Standard.Order,Plot,Variety)
CRDPotato.Design
remove("Standard.Order", "Plot", "Variety")
CRDPotato.Design[CRDPotato.Design$"Plot",] <- CRDPotato.Design  #sort according to Plot
CRDPotato.Design  #use the last two columns to give to the scientist