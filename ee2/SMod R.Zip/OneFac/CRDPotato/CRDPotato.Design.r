set.seed(311)
b <- 4
t <- 3
n <- b*t
Standard.Order <- factor(1:n)
Plot <- order(runif(n))
Variety <- factor(rep(c(1:t), each=b), labels=c("A","B","C"))
CRDPotato.Design <- data.frame(Standard.Order,Plot,Variety)
CRDPotato.Design
remove("Standard.Order", "Plot", "Variety")
CRDPotato.Design[CRDPotato.Design$"Plot",] <- CRDPotato.Design
CRDPotato.Design

