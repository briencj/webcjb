set.seed(310)
n <- 10   #number of Plots
Standard.Order <- factor(1:n)
Standard.Order
Variety <- factor(rep(c("A", "B", "C"), times = c(3, 4, 3)))
Variety
Plot <- order(r<-runif(n))  # generates 12 random numbers and use the order
                            # of them as the number for a Plot
r
Plot
CRDPotato.Design <- data.frame(Standard.Order,Plot,Variety)
CRDPotato.Design
remove("Standard.Order", "Plot", "Variety")
CRDPotato.Design[CRDPotato.Design$"Plot",] <- CRDPotato.Design #sort according to Plot
CRDPotato.Design  #use the last two columns to give to the scientist