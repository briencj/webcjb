library(dae)
b <- 2
t <- 4
g <- 3
u <- t*g
n <- b*u
GRCBDWheat.unit <- list(Blocks=b, Plots=u)
GRCBDWheat.nest <- list(Plots="Blocks")
Treat <- factor(rep(1:t, times=b*g), labels=c("A","B","C","D"))
data.frame(fac.gen(GRCBDWheat.unit), Treat)
GRCBDWheat.lay <- fac.layout(unrandomized=GRCBDWheat.unit, nested.factors=GRCBDWheat.nest, 
                        randomized=Treat, seed=399)
GRCBDWheat.lay