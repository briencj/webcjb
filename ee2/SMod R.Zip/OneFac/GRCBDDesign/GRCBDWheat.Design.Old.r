#load fac.function.r
set.seed(399)
b <- 2
t <- 4
s <- 3
u <- s * t
n <- b * u
Standard.Order <- factor(1:n)
Standard.Order
Random.Order <- order(rep(runif(b), each = u), runif(n))
Random.Order
GRCBD.Design <- fac.divide(Random.Order, factor.names = list(Blocks = b, Plots=u))
Treat <- factor(rep(1:t, times = b * s), labels = c("A", "B", "C", "D"))
GRCBD.Design <- data.frame(Standard.Order,Random.Order, GRCBD.Design,Treat)
remove("Standard.Order","Random.Order", "Treat")
GRCBD.Design[GRCBD.Design$"Random.Order",] <- GRCBD.Design
GRCBD.Design #use the last three columns to give to the scientist