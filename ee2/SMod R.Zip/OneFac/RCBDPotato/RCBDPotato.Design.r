# load first fac.functions.r
set.seed(311)  #a random value between 0 and 1023
b <- 4
t <- 3
n <- b*t
Standard.Order <- factor(1:n)
Standard.Order
Variety <- factor(rep(1:t, times=b), labels=c("A","B","C"))
Variety
Random.Order <- order(rb<-rep(runif(b), each = t), rn<-runif(n))
rb
rn
Random.Order
RCBDPotato.Design <- fac.divide(Random.Order, factor.names=list(Block=b, Plot=t))
RCBDPotato.Design <- data.frame(Standard.Order,Random.Order,RCBDPotato.Design,Variety)
remove("Standard.Order", "Random.Order", "Variety")
RCBDPotato.Design[RCBDPotato.Design$"Random.Order",] <- RCBDPotato.Design
RCBDPotato.Design  #use the last three columns to give to the scientist
