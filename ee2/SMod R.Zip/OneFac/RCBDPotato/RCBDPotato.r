#install.packages(repos=NULL, pkgs="path\\dae.zip")
install.packages(repos=NULL, pkgs="C:\\clarice\\Chris\\Course2007\\R-prog\\dae.zip")
# change directory  to path
library(dae)
# or load the function: diagnostic.checking.r

#set up data.frame with factors Plots, Blocks and Varieties and response variable Yield
RCBDPotato.dat <- data.frame(Blocks=factor(rep(c(1:4), each=8)),
Plots = factor(rep(c(1:8), times=4)),
Varieties = factor(rep(c("A","B","C","D","E","F","G","H"), times=4)))
RCBDPotato.dat$Yields <- c(9.2,21.1,22.6,15.4,12.7,20.0,23.1,18.0,
13.4,27.0,29.9,11.9,18.0,21.1,24.2,24.6,11.0,26.4,24.2,10.1,18.2,20.0,26.4,24.0,
9.2,25.7,25.1,12.3,17.1,28.0,16.3,24.6)
RCBDPotato.dat
attach(RCBDPotato.dat)
RCBDMaize.dat <- data.frame(Blocks=factor(rep(1:4, each=5)),
Plots = factor(rep(1:5, times=4)),
Doses = factor(rep(c(0,25,50,75,100), times=4)))

# boxplots
par(mfrow=c(1,2))
boxplot(split(Yields, Blocks), style.bxp = "old", xlab = "Blocks", ylab
= "Yields", medchar = T, medpch = 8)
boxplot(split(Yields, Varieties), style.bxp = "old", xlab = "Varieties", ylab =
"Yields", medchar = T, medpch = 8)
par(mfrow=c(1,1))

# Variety means, variances and standard errors
v <- tapply(Yields, Varieties,var)
data.frame(Mean= tapply(Yields, Varieties,mean),Variance=v,StandardError= sqrt(v))
rm(v)

## ANOVA  using aov with error term
RCBDPotato.aov <- aov(Yields ~ Blocks + Varieties + Error(Blocks/Plots), RCBDPotato.dat)
summary(RCBDPotato.aov)
#Compute Block F and p
Block.F <- 16.843/8.55
Block.p <- 1 - pf(Blend.F, 3, 21)
data.frame(Block.F, Block.p)

## ANOVA  using aov without error term
RCBDPotato.NoError.aov <- aov(Yields ~ Blocks + Varieties, RCBDPotato.dat)
summary(RCBDPotato.NoError.aov)

# Diagnostic checking
res <- resid.errors(RCBDPotato.aov)
fit <- fitted.errors(RCBDPotato.aov)
data.frame(Blocks, Plots, Varieties, Yields, res, fit)
plot(fit, res, pch = 16)
qqnorm(res, pch = 16)
qqline(res)

# Test of nonadditivity - Tukey
# directly from the package diagnostic.checking.r
tukey.1df(RCBDPotato.aov, RCBDPotato.dat, error.term = "Blocks:Plots")
# or using lm
RCBDPotato.lm <- lm(Yields ~ Blocks + Varieties)
anova(RCBDPotato.lm , test="F")
LP2 <-  (predict(RCBDPotato.lm ))^2
RCBDPotato.lm2 <-update(RCBDPotato.lm, .~. +LP2)
anova(RCBDPotato.lm ,RCBDPotato.lm2, test="F")

# Multiple comparisons - Tukey's HSD procedure
model.tables(RCBDPotato.aov, type="means", se=T)
q <- qtukey(0.95, 8, 21)
q
w <- qtukey(0.95, 8, 21)*summary(RCBDPotato.lm)$sigma/sqrt(4)
w
summary(RCBDPotato.aov <- aov(Yields ~ Blocks+Varieties))
TukeyHSD(RCBDPotato.aov, "Varieties", ordered = TRUE)
plot(TukeyHSD(RCBDPotato.aov, "Varieties"))

detach(RCBDPotato.dat)
search()