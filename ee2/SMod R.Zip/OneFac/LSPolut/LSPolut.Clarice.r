LSPolut.dat <- data.frame(Drivers=factor(rep(c(1,2,3,4), times=c(4,4,4,4))),
Cars = factor(rep(c(1,2,3,4), times=4)))
LSPolut.dat$Additives <- factor(c("A","D","B","C","D","A","C",
"B","B","C","A","D","C","B","D","A"))
LSPolut.dat$Reduct.NO <- c(21,20,26,25,23,20,26,27,15,16,16,13,17,20,20,15)

attach(LSPolut.dat)

# library(DAE, lib.loc = "z:")
par(mfrow=c(1,3))
boxplot(split(Reduct.NO, Drivers), style.bxp = "old", xlab = "Drivers", ylab
= "Reduction in NO", medchar = T, medpch = 8)
boxplot(split(Reduct.NO, Cars), style.bxp = "old", xlab = "Cars", ylab =
"Reduction in NO", medchar = T, medpch = 8)
boxplot(split(Reduct.NO, Additives), style.bxp = "old", xlab = "Additives",
ylab = "Reduction in NO", medchar = T, medpch = 8)
par(mfrow=c(1,1))

v <- tapply(Reduct.NO, Additives,var)
data.frame(Mean= tapply(Reduct.NO, Additives,mean),
Variance=v,StandardError= sqrt(v))
rm(v)

LSPolut.aov <- aov(Reduct.NO ~ Drivers + Cars +
Additives + Error(Drivers * Cars), LSPolut.dat)

summary(LSPolut.aov)

#Compute Drivers and Cars Fs and p-values
Drivers.F <- 72/2.66667
Drivers.p <- 1 - pf(Drivers.F, 3, 6)
Cars.F <- 8/2.66667
Cars.p <- 1 - pf(Cars.F, 3, 6)
data.frame(Drivers.F, Drivers.p, Cars.F, Cars.p)

#
# Diagnostic checking
#
#load the functions from the bottom: resid.errors and fitted.errors
#

res <- resid.errors(LSPolut.aov)
fit <- fitted.errors(LSPolut.aov)
data.frame(Drivers, Cars, Additives, Reduct.NO, res, fit)
par(mfrow=c(1,2))
plot(fit, res, pch = 16)
qqnorm(res, pch = 16)
qqline(res)
par(mfrow=c(1,1))

# Test of nonadditivity - Tukey
#
LSPolut.NoError.aov <- lm(Reduct.NO ~ Drivers + Cars + Additives)
anova(LSPolut.NoError.aov, test="F")

LP2 <-  (predict(mod1))^2
mod2<-update(mod1 , .~. + LP2)
anova(mod1,mod2, test="F")

# multiple comparisons
#
model.tables(LSPolut.aov, type="means", se=T)
q <- qtukey(0.95, 3, 27)
q
summary(LSPolut.aov  <- aov(Reduct.NO ~ Drivers + Cars + Additives))
TukeyHSD(LSPolut.aov , "Additives", ordered = TRUE)
plot(TukeyHSD(LSPolut.aov , "Additives"))


#functions
"resid.errors" <- function(aov.obj, error.term=NULL)
{
	res <- 0
	if (inherits(aov.obj, what="aovlist"))
	{	aov.proj <- proj(aov.obj)
		if (is.null(error.term))
			res <- aov.proj[[length(aov.obj)]][,"Residuals"]
		else
			res <- aov.proj[[error.term]][,"Residuals"]
	}
	else
		res <- residuals(aov.obj)
	res <- res
}

"fitted.errors" <- function(aov.obj, error.term=NULL)
{
	if (inherits(aov.obj, what="aovlist"))
	{	aov.proj <- proj(aov.obj)
		if (is.null(error.term))
			no.strata <- length(aov.obj)
		else
			no.strata <- which(names(aov.proj) == error.term)
		fit <- aov.proj[["(Intercept)"]][,1]
		for (i in 2:no.strata)
		{	nterms <- ncol(aov.proj[[i]])
			if (dimnames(aov.proj[[i]])[[2]][nterms] == "Residuals") nterms <- nterms-1
			if (nterms > 0)
				if (nterms == 1)
					fit <- aov.proj[[i]][,1:nterms]
				else
					fit <- fit + rowSums(aov.proj[[i]][,1:nterms])
		}
	}
	else
		fit <- fitted(aov.obj)
	fit <- fit
}



