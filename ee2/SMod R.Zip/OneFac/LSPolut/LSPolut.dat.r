#unrandomized Additives layout (see
Additives <- factor(c(1,2,3,4, 4,3,2,1, 2,4,1,3, 3,1,4,2), labels=c("A","B","C","D"))
#following data has cols 3 and 4 from BH2 interchanged as this is what was randomized
#in LSPolut.Design.r to produce LSPolut.lay
Reduct.NO <- c(21,26,25,20,23,26,27,20,15,13,16,16,17,15,20,20)
LSPolut.dat <- LSPolut.lay
LSPolut.dat$Reduct.NO[LSPolut.lay$Permutation] <- Reduct.NO
save(LSPolut.dat, file="LSPolut.dat.rda")
