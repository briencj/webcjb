library(dae)
load("LSPolut.dat.rda")
attach(LSPolut.dat)
LSPolut.dat
boxplot(split(Reduct.NO, Drivers), xlab="Drivers", ylab="Reduction in NO")
boxplot(split(Reduct.NO, Cars), xlab="Cars", ylab="Reduction in NO")
boxplot(split(Reduct.NO, Additives), xlab="Additives", ylab="Reduction in NO")
LSPolut.aov <- aov(Reduct.NO ~ Drivers + Cars + Additives + Error(Drivers*Cars), LSPolut.dat)
summary(LSPolut.aov)
#Compute Drivers and Cars Fs and p-values
Drivers.F <- 72/2.667
Drivers.p <- 1-pf(Drivers.F, 3, 6)
Cars.F <- 8/2.667
Cars.p <- 1-pf(Cars.F, 3, 6)
data.frame(Drivers.F,Drivers.p,Cars.F,Cars.p)
#
# Diagnostic checking
#
res <- resid.errors(LSPolut.aov)
fit <- fitted.errors(LSPolut.aov)
data.frame(Drivers,Cars,Additives,Reduct.NO,res,fit)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
tukey.1df(LSPolut.aov, LSPolut.dat, error.term = "Drivers:Cars")
#
# multiple comparisons
#
model.tables(LSPolut.aov, type="means")
q <- qtukey(0.95, 4, 6)
q
#
# Plotting Treat means
#
LSPolut.tab <- model.tables(LSPolut.aov, type="means")
LSPolut.Adds.Mean <- data.frame(Adds.lev = levels(Additives), 
                        Adds.Mean = as.vector(LSPolut.tab$tables$Additives))
LSPolut.Adds.Mean <- LSPolut.Adds.Mean[order(LSPolut.Adds.Mean$Adds.Mean),]
#use factor to order bars
LSPolut.Adds.Mean$Adds.lev <- factor(LSPolut.Adds.Mean$Adds.lev, 
                                    levels=LSPolut.Adds.Mean$Adds.lev)
barchart(Adds.Mean ~ Adds.lev, xlab="Additives", ylim=c(0,25), 
         ylab="NO Reduction", main="Fitted values for Nitrous Oxide Reduction", 
         data=LSPolut.Adds.Mean)


