library(dae)
t <- 4
n <- t*t
LSPolut.unit <- list(Drivers=t, Cars=t)
Additives <- factor(c(1,2,3,4, 4,3,2,1, 2,4,1,3, 3,1,4,2), labels=c("A","B","C","D"))
LSPolut.lay <- fac.layout(unrandomized=LSPolut.unit, randomized=Additives,
                          seed=941)
remove("Additives")
LSPolut.lay

