library(dae)
load("LSTurn.dat.rda")
attach(LSTurn.dat)
boxplot(split(Moisture, Size), xlab="Size", ylab="Moisture content")
boxplot(split(Moisture, Plant), xlab="Plant", ylab="Moisture content")
boxplot(split(Moisture, Time), xlab="Time", ylab="Moisture content")
LSTurn.aov <- aov(Moisture ~ Size + Time + Error(Size*Plant), LSTurn.dat)
summary(LSTurn.aov)
# Compute F and p for Size and Plant
Size.F <- 5.927/0.6740
Size.p <- 1-pf(Size.F, 4, 12)
Plant.F <- 7.2213/0.6740
Plant.p <- 1-pf(Plant.F, 4, 12)
data.frame(Size.F,Size.p,Plant.F,Plant.p)
#
# Diagnostic checking
#
res <- resid.errors(LSTurn.aov)
fit <- fitted.errors(LSTurn.aov)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
tukey.1df(LSTurn.aov, LSTurn.dat, error.term="Size:Plant")
#
# Analysis with Plant 5 Size 4 missing
#
LSTurn.Missing.dat <- LSTurn.dat
LSTurn.Missing.dat$Moisture[20] <- NA
Time.lev <- as.numeric(levels(LSTurn.Missing.dat$Time))
LSTurn.Missing.dat$Time <- ordered(LSTurn.Missing.dat$Time, levels=Time.lev)
contrasts(LSTurn.Missing.dat$Time) <- contr.poly(5, scores=Time.lev)
contrasts(LSTurn.Missing.dat$Time)
LSTurn.Missing.aov <- aov(LSTurn.Missing.dat$Moisture ~ Size + Plant + Time, LSTurn.Missing.dat)
summary(LSTurn.Missing.aov, split=list(Time=list(L = 1, Q = 2, Dev = 3:4)))
