#This is from Preec et al (1973) Table 1
#another version is in Analyses/Consult/Thao/Greenhouse/2 WithTreats/LS4 CC4x5
t <- 4
LC1 <-      c(1,2,3,4, 2,1,4,3, 3,4,1,2, 4,3,2,1)
LC1.ab <-   c(3,4,1,2, 4,3,2,1, 1,2,3,4, 2,1,4,3)
LC1.12 <-   c(2,1,4,3, 1,2,3,4, 4,3,2,1, 3,4,1,2)
LC1.ab12 <- c(4,3,2,1, 3,4,1,2, 2,1,4,3, 1,2,3,4)
Treat <- factor(c(LC1,LC1.12,LC1.ab,LC1.ab12))
LC.unit <- list(Rows = t, Cols = t, Lay = t)
#Case 1
LC.1.dat <- fac.layout(unrandomized = LC.unit, randomized = Treat)
LC.1.dat$y <- rnorm(t^3)
LC.1.aov <- aov(y ~ Treat + Error(Rows*Cols*Lay), LC.1.dat)
summary(LC.1.aov)

#Case 1a
Treat <- factor(c(LC1,LC1.12))
LC2 <-      c(1,4,2,3, 3,2,4,1, 4,1,3,2, 2,3,1,4)
Treat <- factor(c(LC1,LC2))
LC.1a.unit <- list(Rows = t, Cols = t, Lay = 2)
LC.1a.dat <- fac.layout(unrandomized = LC.1a.unit, randomized = Treat)
LC.1a.dat$y <- rnorm(2*t^2)
LC.1a.aov <- aov(y ~ Treat + Error(Rows*Cols*Lay), LC.1a.dat)
summary(LC.1a.aov)

#Case 2
LC.2.nest <- list(Rows = "Lay")
LC.2.dat <- fac.layout(unrandomized = LC.unit, nested.factors = LC.2.nest, 
                       randomized = Treat)
LC.2.dat$y <- rnorm(t^3)
LC.2.aov <- aov(y ~ Treat + Error((Lay/Rows)*Cols), LC.2.dat)
summary(LC.2.aov)

#Case 3
LC.3.nest <- list(Rows = "Lay", Cols = "Lay")
LC.3.dat <- fac.layout(unrandomized = LC.unit, nested.factors = LC.3.nest, 
                       randomized = Treat)
LC.3.dat$y <- rnorm(t^3)
LC.3.aov <- aov(y ~ Treat + Error(Lay/(Rows*Cols)), LC.3.dat)
summary(LC.3.aov)
