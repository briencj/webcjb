t <- 7
k <- 4
n <- k*t
YDNWear.unit <- list(Machines=t, Positions=k)
Fabrics <- factor(c(3,5,6,7, 4,6,7,1, 5,7,1,2, 6,1,2,3, 7,2,3,4, 1,3,4,5, 2,4,5,6), 
                 labels=c("A","B","C","D","E","F","G"))
YDNWear.lay <- fac.layout(unrandomized = YDNWear.unit, 
                          randomized = Fabrics, seed = 859)
remove("Fabrics")
YDNWear.lay

