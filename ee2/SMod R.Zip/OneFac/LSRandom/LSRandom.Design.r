t <- 6
n <- t*t
LSWine.unit <- list(Judges=t, Occasions=t)
Wines <- factor(c(1,2,3,4,5,6, 2,1,6,5,3,4, 3,6,2,1,4,5, 
                  4,3,5,2,6,1, 5,4,1,6,2,3, 6,5,4,3,1,2), 
                 labels=c("A","B","C","D","E","F"))
LSWine.lay <- fac.layout(unrandomized=LSWine.unit, randomized=Wines, seed=559)
remove("Wines")
LSWine.lay

