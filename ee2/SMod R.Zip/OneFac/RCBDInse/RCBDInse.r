load("RCBDInse.dat.rda")
attach(RCBDInse.dat)
library(dae)
boxplot(split(No.Curc, Blocks), xlab="Blocks", ylab="No. Curculios")
boxplot(split(No.Curc, Insecticide), xlab="Insecticide", ylab="No. Curculios")
#
# analysis including an orthogonal contrast
#
contrasts(RCBDInse.dat$Insecticide)
contrasts(RCBDInse.dat$Insecticide) <- matrix(c(-1,5,-1,-1,-1,-1), nrow=6, ncol=1)
contrasts(RCBDInse.dat$Insecticide)
RCBDInse.aov <- aov(No.Curc ~ Blocks + Insecticide + Error(Blocks/Plots), RCBDInse.dat)
summary(RCBDInse.aov)
summary(RCBDInse.aov, split = list(Insecticide = list(Check.Rest = 1, Dev=2:5)))
#Compute Blocks F and p
Blocks.F <- 648.49/197
Blocks.p <- 1-pf(Blocks.F, 3, 15)
data.frame(Blocks.F,Blocks.p)
coef(RCBDInse.aov)
#
# Diagnostic checking
#
res <- resid.errors(RCBDInse.aov)
fit <- fitted.errors(RCBDInse.aov)
data.frame(Blocks,Plots,Insecticide,No.Curc,res,fit)
plot(fit, res, pch=16)
qqnorm(res, pch=16)
qqline(res)
tukey.1df(RCBDInse.aov, RCBDInse.dat, error.term="Blocks:Plots")
#
# multiple comparisons
#
model.tables(RCBDInse.aov, type="means")
q <- qtukey(0.95, 6, 15)
q
#
# Plotting Treat means
#
RCBDInse.tab <- model.tables(RCBDInse.aov, type="means")
RCBDInse.Inse.Mean <- data.frame(Inse.lev = levels(Insecticide), 
                        Inse.Mean = as.vector(RCBDInse.tab$tables$Insecticide))
RCBDInse.Inse.Mean <- RCBDInse.Inse.Mean[order(RCBDInse.Inse.Mean$Inse.Mean, 
                                               decreasing=TRUE),]
#use factor to order bars
RCBDInse.Inse.Mean$Inse.lev <-factor(RCBDInse.Inse.Mean$Inse.lev, 
                                           levels=RCBDInse.Inse.Mean$Inse.lev)
barchart(Inse.Mean ~ Inse.lev, xlab="Insecticide", 
         ylab="No. Curculios", main="Fitted values for No. Curculios", 
         data=RCBDInse.Inse.Mean)


