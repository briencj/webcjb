library(dae)
library(MASS)
# set up data.frame with factors Plots, Treat, A, B and response variable Days
# incomplete data set
CRDLilium.dat <- data.frame(Plots = factor(1:48),
Hormone = factor(rep(c(1:2), times=c(24,24))),
Temp = factor(rep(c(rep(c(1:3), times=c(8,8,8))), times=2)))
CRDLilium.dat$Days <-
c(49,54,52,49,48,48,47,46,44,42,52,44,46,47,52,49,59,50,50,49,46,51,53,56,
53,47,66,49,49,51,51,53,69,50,53,54,47,44,47,49,50,54,53,57,45,49,56,71)
CRDLilium.dat$Treat <- fac.combine(list(CRDLilium.dat$Hormone,CRDLilium.dat$Temp))

attach(CRDLilium.dat)
CRDLilium.dat
# initial analysis
#
boxplot(split(Days, Treat), xlab="Treatments", ylab="Days")
boxplot(Days~Temp*Hormone, xlab="Treatments", ylab="Days")
boxplot(log(Days)~Temp*Hormone, xlab="Treatments", ylab="Days")

## mean, variance, standard errors
v <- tapply(Days, Treat,var)
data.frame(Mean= tapply(Days, Treat,mean),
Variance=v,StandardError= sqrt(v))
rm(v)

## ANOVA
Lilium.aov <- aov(Days ~ Treat + Error(Plots), CRDLilium.dat)
summary(Lilium.aov)
model.tables(Lilium.aov, type="means", se=T)

# plots for diagnostic checking
Lilium.lm <- lm(Days ~ Treat)
fit<-fitted(Lilium.lm)
res<-residuals(Lilium.lm)
res_standard<-rstandard(Lilium.lm)
res_student<-rstudent(Lilium.lm)
data.frame(Plots,Treat,Days,res,res_standard,res_student,fit)
par(mfrow=c(3,1))
plot(fit, res, pch=16)
plot(fit, res_standard, pch=16)
plot(fit, res_student, pch=16)

qqnorm(res, pch=16)
qqline(res)
qqnorm(res_standard, pch=16)
qqline(res_standard)
qqnorm(res_student, pch=16)
qqline(res_student)
par(mfrow=c(1,1))

plot(fit, res_student, pch=16)
identify(fit, res_student)   #click on the point, use ESC  in R to esc

library(car)
qq.plot(Lilium.lm,simulate=TRUE,reps=999)

par(mfrow=c(2,1))
# Normal plot with simulated envelope - using rstudent
res_student<-sort(res_student<-rstudent(Lilium.lm))
env<-quantile(res_student,c(.05,0.5,.95))
for (i in 1:999){
y.<-rnorm(rep(1,length(Lilium.lm$fit)), Lilium.lm$fit,summary(Lilium.lm)$sigma)
res_student<-cbind(res_student,sort(res_student<-rstudent(lm(y.~Treat,family=gaussian()))))}
for (i in 1:nrow(res_student)){
env<-cbind(env,quantile(res_student[i,],c(.05,0.5,.95)))}
matplot(qnorm((1:nrow(res_student))/(nrow(res_student)+1)),cbind(t(env[,-1]),res_student[,1]),
col=c(1,1,1,1),pch=c(NULL,NULL,1),cex=.5,type=c("l","l","l","p"),lty=c(1,2,1,1),
xlab="quantile", ylab="residuals")

# Normal plot with simulated envelope - using ordinary residuals
res<-sort(summary(Lilium.lm)$resid)
env<-quantile(res,c(.05,0.5,.95))
for (i in 1:999){
y.<-rnorm(rep(1,length(Lilium.lm$fit)), Lilium.lm$fit,summary(Lilium.lm)$sigma)
res<-cbind(res,sort(summary(lm(y.~Treat,family=gaussian()))$resid))}
for (i in 1:nrow(res)){
env<-cbind(env,quantile(res[i,],c(.05,0.5,.95)))}
matplot(qnorm((1:nrow(res))/(nrow(res)+1)),cbind(t(env[,-1]),res[,1]),
col=c(1,1,1,1),pch=c(NULL,NULL,1),cex=.5,type=c("l","l","l","p"),lty=c(1,2,1,1),
xlab="quantile", ylab="residuals")
par(mfrow=c(1,1))

# multiple comparisons
#
model.tables(Lilium.aov, type="means", se=T)
q <- qtukey(0.95, 6, 44)
q
summary(Lilium.aov <- aov(Days ~ Treat))
TukeyHSD(Lilium.aov, "Treat", ordered = TRUE)
plot(TukeyHSD(Lilium.aov, "Treat"))

## Factorial
interaction.plot(Hormone,Temp, Days, lwd = 2)
interaction.plot(Temp,Hormone, Days, lwd = 2)

LiliumFac2.aov <- aov(Days ~ Hormone*Temp + Error(Plots), CRDLilium.dat)
summary(LiliumFac2.aov)
res <- resid.errors(LiliumFac2.aov)
fit <- fitted.errors(LiliumFac2.aov)
plot(fit, res, pch = 16)
plot(as.numeric(Hormone), res, pch = 16)
plot(as.numeric(Temp), res, pch = 16)
qqnorm(res, pch = 16)
qqline(res)

#Box-Cox transformation
LiliumFac2.NoError.aov <- aov(Days ~ Hormone*Temp, CRDLilium.dat)
boxcox(LiliumFac2.NoError.aov, lambda = seq(from = -6, to = 0, len = 20),
plotit = T)

TukeyHSD(LiliumFac2.NoError.aov, "Hormone", ordered = TRUE)
plot(TukeyHSD(LiliumFac2.NoError.aov, "Hormone"))

detach(CRDLilium.dat)
search()
