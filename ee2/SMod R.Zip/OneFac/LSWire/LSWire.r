Supplier <- factor(rep(1:8, each=8))
Machine <- factor(rep(1:8, times=8))
Lubricant <- factor(c(1:8, 2:8,1, 3:8,1,2, 4:8,1:3, 5:8,1:4, 6:8,1:5, 7,8,1:6, 8,1:7))
Efficiency <- c(87.9,89.1,88.6,87.2,85.1,88.9,87.7,87.2,
                88.4,89.9,89.7,88.4,89.2,85.9,88.7,87.2,
                88.1,88.8,88.8,86.2,85.7,89.0,83.4,88.1,
                89.5,89.1,88.2,85.4,81.0,87.2,89.5,88.5,
                88.0,88.8,86.5,90.2,84.3,90.0,89.6,89.2,
                88.1,87.0,90.0,87.0,85.1,88.5,88.7,88.4,
                87.7,89.1,87.6,85.8,84.2,89.0,88.9,89.0,
                89.9,87.0,89.1,87.6,88.6,88.5,87.0,86.7)
LSWire.dat <- data.frame(Supplier,Machine,Lubricant,Efficiency)
remove("Supplier","Machine","Lubricant","Efficiency")
save(LSWire.dat, file="LSWire.dat.rda")
attach(LSWire.dat)
boxplot(split(Efficiency, Supplier), xlab="Supplier", ylab="Efficiency")
boxplot(split(Efficiency, Machine), xlab="Machine", ylab="Efficiency")
boxplot(split(Efficiency, Lubricant), xlab="Lubricant", ylab="Efficiency")
LSWire.aov <- aov(Efficiency ~ Supplier + Lubricant + Error(Supplier*Machine), LSWire.dat)
summary(LSWire.aov)
# Compute F and p for Supplier and Machine
Supplier.F <- 1.4769/1.918
Supplier.p <- 1-pf(Supplier.F, 7, 42)
Machine.F <- 9.298/1.918
Machine.p <- 1-pf(Machine.F, 7, 42)
data.frame(Supplier.F,Supplier.p,Machine.F,Machine.p)
#
# Diagnostic checking
#
res <- resid.errors(LSWire.aov)
fit <- fitted.errors(LSWire.aov)
plot(fit, res, pch=16)
data.frame(LSWire.dat,res,fit)
qqnorm(res, pch=16)
qqline(res)
tukey.1df(LSWire.aov, LSWire.dat, error.term="Supplier:Machine")
#
# multiple comparisons
#
LSWire.tab <- model.tables(LSWire.aov, type="means")
LSWire.tab$tables$Lubricant
LSWire.Lub.Mean <- data.frame(Lub.lev = levels(Lubricant), 
                              Lub.Mean = as.vector(LSWire.tab$tables$Lubricant))
barchart(Lub.Mean ~ Lub.lev, ylim=c(0,90), xlab="Lubricant", 
         ylab="Efficiency", main="Fitted values for Efficiency", data=LSWire.Lub.Mean)
