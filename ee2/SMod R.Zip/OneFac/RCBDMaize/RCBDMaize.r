#install.packages(repos=NULL, pkgs="path\\dae.zip")
install.packages(repos=NULL, pkgs="C:\\clarice\\Chris\\Course2007\\R-prog\\dae.zip")
# change directory  to path
library(dae)
# or load the function: diagnostic.checking.r

#set up data.frame with factors Plots, Blocks and Doses and response variable Yields
RCBDMaize.dat <- data.frame(Blocks=factor(rep(c(1:4), each=5)),
Plots = factor(rep(c(1:5), times=4)),
Doses = factor(rep(c(0,25,50,75,100), times=4)))
RCBDMaize.dat$Yields <- c(3.38,7.15,10.07,9.55,9.14,5.77,9.78,9.73,8.95,10.17,
4.90,9.99,7.92,10.24,9.75,4.54,10.10,9.48,8.66,9.50)
RCBDMaize.dat
attach(RCBDMaize.dat)

# boxplots
par(mfrow=c(1,2))
boxplot(split(Yields, Blocks), style.bxp = "old", xlab = "Blocks", ylab
= "Yields", medchar = T, medpch = 8)
boxplot(split(Yields, Doses), style.bxp = "old", xlab = "Doses", ylab =
"Yields", medchar = T, medpch = 8)
par(mfrow=c(1,1))

# Doses means, variances and standard erros
v <- tapply(Yields, Doses,var)
data.frame(Mean= tapply(Yields, Doses,mean),Variance=v,StandardError= sqrt(v))
rm(v)

## ANOVA  using aov with error term
RCBDMaize.aov <- aov(Yields ~ Blocks + Doses + Error(Blocks/Plots), RCBDMaize.dat)
summary(RCBDMaize.aov)
#Compute Block F and p
Block.F <- 0.91162/0.909
Block.p <- 1 - pf(Block.F, 3, 12)
data.frame(Block.F, Block.p)

## ANOVA  using aov without error term
RCBDMaize.NoError.aov <- aov(Yields ~ Blocks + Doses, RCBDMaize.dat)
summary(RCBDMaize.NoError.aov)

# Diagnostic checking
res <- resid.errors(RCBDMaize.aov)
fit <- fitted.errors(RCBDMaize.aov)
data.frame(Blocks, Plots, Doses, Yields, res, fit)
plot(fit, res, pch = 16)
qqnorm(res, pch = 16)
qqline(res)

# Test of nonadditivity - Tukey
# directly from the package diagnostic.checking.r
tukey.1df(RCBDMaize.aov, RCBDMaize.dat, error.term = "Blocks:Plots")
# or using lm
RCBDMaize.lm <- lm(Yields ~ Blocks + Doses)
anova(RCBDMaize.lm , test="F")
LP2 <-  (predict(RCBDMaize.lm ))^2
RCBDMaize.lm2 <-update(RCBDMaize.lm, .~. +LP2)
anova(RCBDMaize.lm ,RCBDMaize.lm2, test="F")

# fitting polynomials
Dose.lev <- c(0,25,50,75,100)
contrasts(RCBDMaize.dat$Doses) <- contr.poly(Dose.lev)
contrasts(RCBDMaize.dat$Doses)
RCBDMaize.aov <- aov(Yields ~ Blocks + Doses + Error(Blocks/Plots), RCBDMaize.dat)
summary(RCBDMaize.aov, split = list(Doses = list(L = 1,  Q = 2, C=3, Dev=4)))

# ploting the observed values and fitted curve
plot(c(0,100), c(0,12), type="n", xlab="Dose", ylab="Yield")
d <- rep(c(0,25,50,75,100), times=4)
points(d,Yields)
x<-seq(0,100,0.2)
lines(x, (predict(lm(Yields ~ I(d)+I(d^2)+I(d^3)),data.frame(d=x))),lty=1, col="red")

detach(RCBDMaize.dat)
search()