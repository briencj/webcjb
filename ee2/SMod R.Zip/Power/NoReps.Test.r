library(dae)
rm <- 5
rm <- 15
rm <- 20
rm <- 19
rm <- 18
power.exp(rm=rm, df.num=3, df.denom=3*(rm-1), delta=5, sigma=sqrt(20))
power.exp(rm=15, df.num=3, df.denom=3*(rm-1), delta=5, sigma=sqrt(20), print=TRUE)
power.exp(rm=rm, df.num=3, df.denom=3*(rm-1), delta=5, sigma=sqrt(20), print=TRUE)
#Latin squares
rm <- 4
power.exp(rm=rm, df.num=rm-1, df.denom=(rm-1)*(rm-2), delta=7.5, sigma=sqrt(10))
power.exp(rm=8, df.num=3, df.denom=15, delta=7.5, sigma=sqrt(10))
power.diff(rm=rm, df.num=3, df.denom=expression(3*(rm-1)), delta=5, sigma=sqrt(20))
optimize(power.diff, interval=c(2,100), tol=0.1, keep.xy=T, 
                     df.num=3, df.denom=expression((df.num+1)*(r-1)), delta=5, sigma=sqrt(20))
optno <- optimize(power.diff, interval=c(2,100), tol=0.1, print=TRUE,  
				multiple=1, df.num=3, df.denom=expression(df.num*(r-1)), delta=4, sigma=1.5)
optno$minimum
optno$objective
optno$singularity
optno$interval
?no.reps
no.reps(df.num=2, df.denom=expression(3*(r-1)), delta=7.5, sigma=sqrt(12), power=0.9)
no.reps(df.num=2, delta=7.5, sigma=sqrt(12), power=0.9)

no.reps(multiple=1, df.num=3, df.denom=expression(3*(r-1)), delta=5, sigma=sqrt(20))
no.reps(multiple=1, df.num=3, df.denom=expression(df.num*(r-1)), delta=5, sigma=sqrt(20), 
        power=0.8, print=TRUE)
no.reps(multiple=1, df.num=3, df.denom=expression(df.num*(r-1)), delta=5, 
        sigma=sqrt(20), power=0.8)
no.reps(multiple=1, df.num=3, df.denom=expression(df.num*(r-1)), delta=5, sigma=sqrt(20), 
        power=0.8, print=FALSE)
no.reps(multiple=4, df.num=3, df.denom=expression(3*(r*multiple-1)), delta=5, sigma=sqrt(20), 
        power=0.8, print=TRUE)
n <- no.reps(multiple=1, df.num=3, df.denom=expression(3*(r-1)), delta=5, sigma=sqrt(20))
n$nreps
#
# Exam 2007
#
no.reps(multiple=3, df.num=4, df.denom=expression((3*3-1)*(r-1)), delta=5, sigma=sqrt(10), 
        power=0.8)
#
# Exam 2008
#
rm <- 5
power.exp(rm=5, df.num=4, df.denom=(rm-1)*(rm-2), delta=5, sigma=sqrt(4))

#
# Exam 2009
#
no.reps(multiple=1, df.num=4, df.denom=expression((3*3-1)*(r-1)), delta=7.5, sigma=sqrt(10), 
        power=0.8)


#
# ch X exercises
#
no.reps(multiple=1, df.num=3, df.denom=expression(df.num*(r-1)), delta=4, sigma=1.5, power=0.9, print=TRUE)
power.exp(rm=6, df.num=4, df.denom=4*(rm-1), delta=6, sigma=sqrt(3))
rm <- 6
power.exp(rm=rm, df.num=4, df.denom=4*(rm-1), delta=6, sigma=sqrt(3), print=TRUE)
#
# example that gives no. reps with slightly less power than required
#
rm <- 36
power.exp(rm=rm, df.num=3, df.denom=4*(rm-1), delta=5, sigma=sqrt(30))
no.reps(multiple=1, df.num=3, df.denom=expression(4*(r-1)), delta=5, sigma=sqrt(30), power=0.9)
no.reps(multiple=1, df.num=3, delta=5, sigma=sqrt(30), power=0.9, print=TRUE)