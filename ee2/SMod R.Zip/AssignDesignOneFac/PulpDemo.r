library(dae)
#
# Obtaining randomized layout for a CRD
#
set.seed(911)
n <- 9
Standard.Order <- factor(1:n)
Run <- order(runif(n))
Temperature <- factor(rep(c(75, 80, 85), times = 3))
PulpDemo.Design <- data.frame(Standard.Order,Run,Temperature)
PulpDemo.Design[PulpDemo.Design$"Run",] <- PulpDemo.Design
PulpDemo.Design
#get strength
Demo.strength <- strength(nodays=3, noruns=3, 
                   temperature=PulpDemo.Design$Temperature, ident=0123456)
Demo.strength
