Incomes.dat <- data.frame(Education = c(8,12,14,16,16,20), 
                          Income = c(8,15,16,20,25,40))
attach(Incomes.dat)
Income.lm <- lm(Income ~ Education, Incomes.dat)
summary(Income.lm)
Income.aov <- aov(Income ~ Education, Incomes.dat)
summary(Income.aov)
#Compute Q.M
X <- matrix(c(rep(1, each=6), Incomes.dat$Education), nrow=6)
Q.M <- t(X) %*% X
Q.M <- ginv(Q.M)
Q.M <- X %*% Q.M %*% t(X)
Q.M

Q.M %*% Incomes.dat$Income
fitted(Income.lm)

