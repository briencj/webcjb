load("Possum.dat.rda")
table(possum$Pop, possum$sex)
library(lattice)
xyplot(totlngth ~ age | sex*Pop, data=possum)
