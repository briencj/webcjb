plot((0:20)*pi/10, sin((0:20)*pi/10))
plot((1:50)*0.92, sin((1:50)*0.92))
oldpar <- par(mfrow=c(2,1))
par(oldpar)
data(package="base")
data(package="MASS")
elasticband <- data.frame(stretch=c(46,54,48,50,44,42,52),
                          distance=c(148,182,173,166,109,141,166))
attach(elasticband)
plot(stretch, distance)
detach(elasticband)

ACTpop <- data.frame(year=seq(1917, 1997, 10),
                     ACT=c(3,8,11,17,38,103,214,265,320))
attach(ACTpop)
plot(year, ACT, type="l")
detach(ACTpop)

p <- (0:100)/100
plot(p, sqrt(p*(1-p)), ylab=expression(sqrt(p(1-p))), type="l")

theta <- (1:50)*0.92
plot(theta, sin(theta), col=1:50, pch=16, cex=4)
points(theta, cos(theta), col=51:100, pch=15, cex=4)
palette()

#create rda file with data set
install.packages(pkgs="DAAG")
library(DAAG)
data(primates)
save(primates, file="Primates.dat.rda")
#do initial rough plot
load("Primates.dat.rda")
attach(primates)
plot(Bodywt, Brainwt, xlim=c(0, 300))
text(x=Bodywt, y=Brainwt, labels=row.names(primates), adj=0)
detach(primates)
#do the refined plot
attach(primates)
plot(x=Bodywt, y=Brainwt, pch=16, xlab="Body weight (kg)",
     ylab="Brain weight (g)", xlim=c(0, 300), 
     ylim=c(0, 1500))
chw <- par()$cxy[1]
chh <- par()$cxy[2]
text(x=Bodywt+chw, y=Brainwt+c(-0.1, 0, 0, 0.1, 0)*chh,
     labels=row.names(primates), adj=0)
detach(primates)


library(MASS)
data(possum)
save(possum, file="Possum.dat.rda")
load("Possum.dat.rda")
table(possum$Pop, possum$sex)
library(lattice)
xyplot(totlngth ~ age | sex*Pop, data=possum)

library(lattice)
par(ask=F)
example(xyplot)