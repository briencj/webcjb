Temp=scan()
19 15 35 52 35 33 30 57 49 26

save(Rocket.dat, file="Rocket.dat.rda")
load("Rocket.dat.rda")