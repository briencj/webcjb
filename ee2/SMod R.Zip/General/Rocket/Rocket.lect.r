Rocket.dat <- data.frame(Temp = c(19,15,35,52,35,33,30,57,49,26), 
                         Thrust = c(1.2,1.5,1.5,3.3,2.5,2.1,2.5,3.2,2.8,1.5))
attach(Rocket.dat)
plot(Thrust, Temp)
summary(Rocket.dat)
MnThrust <- mean(Thrust)
MnThrust
Deviation <- Thrust - mean(Thrust)
