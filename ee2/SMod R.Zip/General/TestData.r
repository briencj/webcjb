#in S-Plus
data.dump("TestData.dat", "TestData.dat.sdu", oldStyle = T)
#in R
library(foreign)
data.restore("TestData.dat.sdu")
rownames(TestData.dat) <- c("Eagle Summit 4","Ford Escort 4","Ford Festiva 4",
                            "Chevrolet Camaro V8","Dodge Daytona","Ford Mustang V8",
                            "Audi 80 4","Buick Skylark 4","Chevrolet Beretta 4")
save(TestData.dat, file="TestData.dat.rda")
attach(TestData.dat)
levels(Type.code)
Types <- TestData.dat$Type.code
levels(Types)
levels(Types) <- c("Small","Sporty","Compact")
load("TestData.dat.rda")
attach(TestData.dat)
tapply(Mileage, list(Type), mean)
Mileage.Mean <- aggregate(Mileage, list(Type), mean)