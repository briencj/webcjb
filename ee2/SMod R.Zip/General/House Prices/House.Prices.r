#Set working directory and load House.Prices.dat
load("House.Prices.dat.rda")
attach(House.Prices.dat)
pairs(House.Prices.dat, pch=16)

#Copy scatterplot matrix to clipboard

House.lm <- lm(Price ~ Age + Years, House.Prices.dat)
summary(House.lm)
residuals <- residuals(House.lm)
fitted <- fitted(House.lm)
windows()                   #opens new graphics window
plot(fitted, residuals, pch=16)

#Copy residuals-versus-fitted-values plot to clipboard

qqnorm(residuals, pch=16)
qqline(residuals)

#Copy qq plot to clipboard

detach(House.Prices.dat)
House.Prices.dat <- data.frame(House.Prices.dat,residuals,fitted)
remove("residuals","fitted")
