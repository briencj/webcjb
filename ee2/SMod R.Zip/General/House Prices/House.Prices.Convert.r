#use this in S-Plus
data.dump("House.Prices.dat", "House.Prices.dat.sdu", oldStyle = T)
#use this in R
library(foreign)
data.restore("d:/Analyses/Teach/LM/General/House.Prices/House.Prices.dat.sdu")
data.restore("House.Prices.dat.sdu")
save(House.Prices.dat, file="House.Prices.dat.rda")